﻿# modules\TinySocs.Installer.psm1
# Windows-first installer helpers for TinySocs

# Module version stamp (helps confirm which copy you imported)
$script:TinySocsInstallerVersion = '0.0.20251217-opensearch-persistfix'

# -- ProgramData layout -------------------------------------------------------
function Get-TinySocsDataRoot {
  $root = Join-Path $env:ProgramData "TinySocs"
  if (-not (Test-Path $root)) {
    try { New-Item -ItemType Directory -Force -Path $root | Out-Null } catch { }
  }
  return $root
}

function Join-TsPath {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)]
    [string] $Root,

    [Parameter(Mandatory)]
    [string[]] $Parts
  )

  $p = $Root
  foreach ($part in $Parts) {
    if ([string]::IsNullOrWhiteSpace($part)) { continue }
    $p = Join-Path -Path $p -ChildPath $part
  }
  return $p
}

function Invoke-TinySocsOpenSearchApi {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)]
    [ValidateSet("GET","POST","PUT","DELETE","PATCH","HEAD","OPTIONS")]
    [string]$Method,

    [Parameter(Mandatory)]
    [string]$Url,

    [string]$User,
    [string]$Pass,

    # If provided, sent as application/json
    [string]$BodyJson,

    # Secure default: verify TLS. Only disable explicitly.
    [switch]$SkipTlsVerify,

    # If provided and SkipTlsVerify is NOT set, pin trust to this CA file
    # (.cer/.crt/.pem all work with curl's --cacert)
    [string]$CaCertPath,

    # Practical hardening knobs
    [int]$TimeoutSeconds        = 30,
    [int]$ConnectTimeoutSeconds = 5,
    [int]$Retries               = 2,

    # Windows-only: private CA chains often have no CRL/OCSP; revocation checks can fail noisily.
    # Default: disable revocation for reliability on Windows local installs.
    [bool]$DisableRevocationCheck = $true,

    # If set, attempt ConvertFrom-Json on success
    [switch]$AsJson
  )

  # Find curl.exe
  $curl = Join-Path $env:WINDIR "System32\curl.exe"
  if (-not (Test-Path $curl -PathType Leaf)) {
    $curl = "curl.exe"
  }

  # Base args
  $args = @(
    "--silent", "--show-error",
    "--fail-with-body",
    "--location",
    "--connect-timeout", [string]$ConnectTimeoutSeconds,
    "--max-time",        [string]$TimeoutSeconds
  )

  # Retry behaviour (curl retries are useful when OpenSearch is mid-startup)
  if ($Retries -gt 0) {
    $args += @(
      "--retry",          [string]$Retries,
      "--retry-delay",    "1",
      "--retry-all-errors"
    )
  }

  # Windows revocation weirdness (esp. private CA + no CRL)
  if ($IsWindows -and $DisableRevocationCheck) {
    $args += @("--ssl-no-revoke")
  }

  # TLS policy
  if ($SkipTlsVerify.IsPresent) {
    $args += @("-k")
  } else {
    if (-not [string]::IsNullOrWhiteSpace($CaCertPath)) {
      if (-not (Test-Path $CaCertPath -PathType Leaf)) {
        throw "Invoke-TinySocsOpenSearchApi: CaCertPath not found: $CaCertPath"
      }
      $args += @("--cacert", $CaCertPath)
    }
  }

  # Method + URL
  $args += @("-X", $Method, $Url)

  # Basic auth
  if (-not [string]::IsNullOrWhiteSpace($User) -and -not [string]::IsNullOrWhiteSpace($Pass)) {
    $args += @("-u", "$User`:$Pass")
  }

  # Body handling (TEMP, then delete)
  $tmp = $null
  try {
    if (-not [string]::IsNullOrWhiteSpace($BodyJson)) {
      $tmp = Join-Path $env:TEMP ("tinysocs-os-body-{0}.json" -f ([guid]::NewGuid().ToString("N")))
      Set-Content -Path $tmp -Value $BodyJson -Encoding UTF8 -Force

      $args += @(
        "-H", "Content-Type: application/json",
        "--data-binary", ("@{0}" -f $tmp)
      )
    }

    # Execute and capture stderr+stdout
    $out = & $curl @args 2>&1
    $rc  = $LASTEXITCODE

    $txt = ($out | Out-String).Trim()

    if ($rc -ne 0) {
      throw "Invoke-TinySocsOpenSearchApi: curl failed (exit=$rc) $Method $Url :: $txt"
    }

    if ($AsJson.IsPresent) {
      if ([string]::IsNullOrWhiteSpace($txt)) { return $null }
      try { return ($txt | ConvertFrom-Json) } catch { return $txt }
    }

    return $txt
  }
  finally {
    if ($tmp -and (Test-Path $tmp -PathType Leaf)) {
      try { Remove-Item -Force -ErrorAction SilentlyContinue $tmp } catch { }
    }
  }
}

function Ensure-TinySocsWinlogbeatTemplate {
  [CmdletBinding()]
  param(
    [string]$SiemUrl = "https://127.0.0.1:9201",
    [string]$User,
    [string]$Pass,
    [switch]$SkipTlsVerify
  )

  $name = "tinysocs-winlog"
  $get  = "$SiemUrl/_index_template/$name"
  $put  = "$SiemUrl/_index_template/$name"

  $putBody = @"
{
  "index_patterns": ["winlogbeat-*"],
  "template": {
    "settings": {
      "number_of_shards": 1,
      "number_of_replicas": 0
    }
  },
  "priority": 500
}
"@

  try {
    try {
      $resp = Invoke-TinySocsOpenSearchApi -Method "GET" -Url $get -User $User -Pass $Pass -SkipTlsVerify:$SkipTlsVerify
      if ($resp -and ($resp -match '"name"\s*:\s*"' + [regex]::Escape($name) + '"')) {
        Write-TinySocsLog -Message "Index template $name already present." -Level "INFO"
        return
      }
    } catch { }

    $out = Invoke-TinySocsOpenSearchApi -Method "PUT" -Url $put -User $User -Pass $Pass -BodyJson $putBody -SkipTlsVerify:$SkipTlsVerify
    Write-TinySocsLog -Message "Ensured index template $name (replicas=0). Output: $out" -Level "INFO"
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed ensuring index template ${name}: $($_.Exception.Message)"
  }
}

function Write-TinySocsLog {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)][string]$Message,
    [ValidateSet('DEBUG','INFO','WARN','ERROR')][string]$Level = 'INFO'
  )

  $ts   = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff')
  $line = "{0} [{1}] {2}" -f $ts, $Level, $Message

  $logDir  = "C:\ProgramData\TinySocs\logs"
  $logFile = Join-Path $logDir "installer.log"

  try {
    if (-not (Test-Path -LiteralPath $logDir -PathType Container)) {
      New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    }

    # Best-effort: set sane ACLs on the log dir
    try { Ensure-TinySocsLogAcl -LogDir $logDir } catch { }

    # First attempt
    try {
      Add-Content -Path $logFile -Value $line -Encoding UTF8
      return
    } catch {
      # If we got access denied, try a hard reset once.
      $msg = $_.Exception.Message
      if ($msg -match 'Access.*denied|UnauthorizedAccess') {
        try {
          $sys = '*S-1-5-18'
          $adm = '*S-1-5-32-544'
          $usr = '*S-1-5-32-545'

          # Take ownership + reset + grant
          Invoke-TinySocsCmd ('takeown /F "{0}" /A /R /D Y >nul 2>&1' -f $logDir)
          Invoke-TinySocsCmd ('icacls "{0}" /reset /T /C >nul 2>&1' -f $logDir)
          Invoke-TinySocsCmd ('icacls "{0}" /inheritance:e /grant:r "{1}:(OI)(CI)F" "{2}:(OI)(CI)F" "{3}:(OI)(CI)M" /T /C >nul 2>&1' -f $logDir, $sys, $adm, $usr)

          # Retry
          Add-Content -Path $logFile -Value $line -Encoding UTF8
          return
        } catch { }
      }

      throw
    }
  }
  catch {
    # Fall back to a temp log rather than exploding the installer.
    try {
      $fallback = Join-Path $env:TEMP "tinysocs-installer-fallback.log"
      Add-Content -Path $fallback -Value $line -Encoding UTF8
    } catch { }
  }
}

function New-TinySocsPassword {
  [CmdletBinding()]
  param(
    [int]$Length = 24
  )
  $alphabet = ('ABCDEFGHJKLMNPQRSTUVWXYZ' +
               'abcdefghijkmnopqrstuvwxyz' +
               '23456789' +
               '!@#$%^&*_-+=').ToCharArray()
  $bytes = New-Object byte[] ($Length * 2)
  [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
  $sb = New-Object System.Text.StringBuilder
  for ($i=0; $i -lt $Length; $i++) {
    $idx = [int]($bytes[$i] % $alphabet.Length)
    [void]$sb.Append($alphabet[$idx])
  }
  return $sb.ToString()
}

function Get-TinySocsDataRoot {
  $root = Join-Path $env:ProgramData "TinySocs"
  if (-not (Test-Path $root)) { New-Item -ItemType Directory -Force -Path $root | Out-Null }
  return $root
}

function Get-TinySocsInstallRoot {
  # Module usually lives at: C:\Program Files\TinySocs\modules\TinySocs.Installer.psm1
  try {
    $moduleDir = Split-Path -Parent $PSCommandPath
    $root = Split-Path -Parent $moduleDir
    if (Test-Path $root) { return $root }
  } catch { }
  return "C:\Program Files\TinySocs"
}

function Ensure-FileNotEfsEncrypted {
  param([Parameter(Mandatory)][string]$Path)
  try {
    $cipher = Join-Path $env:WINDIR "System32\cipher.exe"
    if (Test-Path $cipher) {
      & $cipher /d /a $Path 2>$null | Out-Null
    }
  } catch { }
}

function Ensure-TinySocsAgentConfigReadable {
  $rootVal = (Get-TinySocsDataRoot | Select-Object -First 1)
  $root    = [string]$rootVal

  $cfg  = Join-Path -Path $root -ChildPath "Collector\agent\config.yml"
  $dir  = Split-Path -Parent $cfg

  if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }

  if (Test-Path -LiteralPath $cfg) {
    Ensure-FileNotEfsEncrypted -Path $cfg
  }

  Ensure-SystemReadAcl -Path $dir
  if (Test-Path -LiteralPath $cfg) { Ensure-SystemReadAcl -Path $cfg }

  Write-TinySocsLog "Agent config ACL/EFS hardening ensured at $cfg"
}

function Ensure-SystemReadAcl {
  [CmdletBinding()]
  param([Parameter(Mandatory)][string]$Path)

  if (-not (Test-Path -LiteralPath $Path)) { return }

  # Locale-proof SIDs (use icacls SID form with leading *)
  $sidSystem = '*S-1-5-18'       # SYSTEM
  $sidAdmins = '*S-1-5-32-544'   # BUILTIN\Administrators

  try {
    $item = Get-Item -LiteralPath $Path -ErrorAction Stop

    if ($item.PSIsContainer) {
      # SYSTEM needs RX to traverse/read; Admins full for operational fixes
      & icacls $Path /inheritance:e `
        /grant:r "$($sidSystem):(OI)(CI)(RX)" `
                 "$($sidAdmins):(OI)(CI)(F)" `
        /t /c /q 2>$null | Out-Null
    } else {
      & icacls $Path /inheritance:e `
        /grant:r "$($sidSystem):(RX)" `
                 "$($sidAdmins):(F)" `
        /c /q 2>$null | Out-Null
    }
  } catch {
    try {
      Write-TinySocsLog -Level "WARN" -Message "ACL hardening failed for ${Path}: $($_.Exception.Message)"
    } catch { }
  }
}

# ---- DPAPI helpers (LocalMachine scope) --------------------------------------
function Ensure-TinySocsProtectedDataAvailable {
  [CmdletBinding()]
  param()

  # Already available?
  if ("System.Security.Cryptography.ProtectedData" -as [type]) { return $true }

  # Try common assembly names across PS 5.1 / PS 7 hosts
  foreach ($asm in @(
    'System.Security.Cryptography.ProtectedData',
    'System.Security'
  )) {
    try { Add-Type -AssemblyName $asm -ErrorAction Stop | Out-Null } catch { }
    if ("System.Security.Cryptography.ProtectedData" -as [type]) { return $true }
  }

  # Last-ditch: Assembly.Load
  try { [void][System.Reflection.Assembly]::Load('System.Security.Cryptography.ProtectedData') } catch { }
  if ("System.Security.Cryptography.ProtectedData" -as [type]) { return $true }

  return $false
}

function Protect-TinySocsDpapiLocalMachine {
  [CmdletBinding()]
  param([Parameter(Mandatory)][string]$Plain)

  if (-not (Ensure-TinySocsProtectedDataAvailable)) {
    throw "DPAPI type System.Security.Cryptography.ProtectedData is not available in this PowerShell host."
  }

  $bytes = [System.Text.Encoding]::UTF8.GetBytes($Plain)
  $enc   = [System.Security.Cryptography.ProtectedData]::Protect(
    $bytes, $null, [System.Security.Cryptography.DataProtectionScope]::LocalMachine
  )
  return [System.Convert]::ToBase64String($enc)
}

function Unprotect-TinySocsDpapiLocalMachine {
  [CmdletBinding()]
  param([Parameter(Mandatory)][string]$B64)

  if (-not (Ensure-TinySocsProtectedDataAvailable)) {
    throw "DPAPI type System.Security.Cryptography.ProtectedData is not available in this PowerShell host."
  }

  $enc   = [System.Convert]::FromBase64String($B64)
  $bytes = [System.Security.Cryptography.ProtectedData]::Unprotect(
    $enc, $null, [System.Security.Cryptography.DataProtectionScope]::LocalMachine
  )
  return [System.Text.Encoding]::UTF8.GetString($bytes)
}

function Get-TinySocsSiemAdminPassFilePath {
  [CmdletBinding()]
  param([Parameter(Mandatory)][string]$CertsDir)
  return (Join-Path $CertsDir "siem-admin-pass.dpapi")
}

function Read-TinySocsSiemAdminPassFromDpapiFile {
  [CmdletBinding()]
  param([Parameter(Mandatory)][string]$CertsDir)

  # Primary location (OpenSearch config tree)
  $primary = $null
  try { $primary = Get-TinySocsSiemAdminPassFilePath -CertsDir $CertsDir } catch { $primary = $null }

  # Secondary location (global TinySocs secrets store; survives OpenSearch config rotation)
  $secondary = $null
  try { $secondary = Join-Path (Get-TinySocsSecretStoreDir) "siem-admin-pass.dpapi" } catch { $secondary = $null }

  $candidates = @()
  if ($primary)   { $candidates += $primary }
  if ($secondary) { $candidates += $secondary }

  foreach ($p in $candidates) {
    if (-not $p) { continue }
    if (-not (Test-Path $p -PathType Leaf)) { continue }

    try {
      $raw = (Get-Content -Path $p -Raw -ErrorAction Stop)
      $raw = ([string]$raw).Trim()
      if ([string]::IsNullOrWhiteSpace($raw)) { continue }

      $plain = Unprotect-TinySocsDpapiLocalMachine -B64 $raw
      if ([string]::IsNullOrWhiteSpace($plain)) { continue }

      # Backfill the *other* copy if missing (best-effort)
      try {
        if ($p -eq $primary -and $secondary -and -not (Test-Path $secondary -PathType Leaf)) {
          $wrapped = Protect-TinySocsDpapiLocalMachine -Plain $plain
          New-Item -ItemType Directory -Force -Path (Split-Path -Parent $secondary) | Out-Null
          Set-Content -Path $secondary -Value $wrapped -Encoding ASCII -Force
          Write-TinySocsLog "Backfilled SIEM admin DPAPI file into global secrets store ($secondary)."
        } elseif ($p -eq $secondary -and $primary -and -not (Test-Path $primary -PathType Leaf)) {
          $wrapped = Protect-TinySocsDpapiLocalMachine -Plain $plain
          New-Item -ItemType Directory -Force -Path (Split-Path -Parent $primary) | Out-Null
          Set-Content -Path $primary -Value $wrapped -Encoding ASCII -Force
          Write-TinySocsLog "Backfilled SIEM admin DPAPI file into OpenSearch certs dir ($primary)."
        }
      } catch {
        Write-TinySocsLog -Level "WARN" -Message "Recovered SIEM admin password from DPAPI file ($p) but failed backfill: $($_.Exception.Message)"
      }

      return $plain
    } catch {
      Write-TinySocsLog -Level "WARN" -Message "Failed to read/unwrap SIEM admin DPAPI file ($p): $($_.Exception.Message)"
    }
  }

  return $null
}

function Write-TinySocsSiemAdminPassToDpapiFile {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$CertsDir,
    [Parameter(Mandatory)][string]$AdminPass
  )

  $okAny   = $false
  $wrapped = $null

  try { $wrapped = Protect-TinySocsDpapiLocalMachine -Plain $AdminPass }
  catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to DPAPI-wrap SIEM admin password: $($_.Exception.Message)"
    return $false
  }

  # Primary (OpenSearch certs dir)
  $p1 = $null
  try { $p1 = Get-TinySocsSiemAdminPassFilePath -CertsDir $CertsDir } catch { $p1 = $null }

  # Secondary (global secrets store)
  $p2 = $null
  try { $p2 = Join-Path (Get-TinySocsSecretStoreDir) "siem-admin-pass.dpapi" } catch { $p2 = $null }

  foreach ($p in @($p1,$p2) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }) {
    try {
      $dir = Split-Path -Parent $p
      if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }

      Set-Content -Path $p -Value $wrapped -Encoding ASCII -Force
      $okAny = $true
      Write-TinySocsLog "Persisted SIEM admin password to DPAPI file ($p)."
    } catch {
      Write-TinySocsLog -Level "WARN" -Message "Failed to write SIEM admin DPAPI file ($p): $($_.Exception.Message)"
    }
  }

  return $okAny
}

function New-ProgramDataLayout {
  [CmdletBinding()]
  param()

  # Defensive: ensure we always treat root as a single string (avoids Join-Path/Object[] style issues elsewhere)
  $root = [string](Get-TinySocsDataRoot | Select-Object -First 1)

  $paths = @(
    "$root\logs",
    "$root\queue",
    "$root\ledger",
    "$root\rules",
    "$root\anchors\state",
    "$root\config",

    # Collector (Agent)
    "$root\Collector",
    "$root\Collector\agent",
    "$root\Collector\agent\queue",
    "$root\Collector\agent\bookmarks",
    "$root\Collector\logs",

    # OpenSearch
    "$root\OpenSearch",
    "$root\OpenSearch\config",
    "$root\OpenSearch\config\certs",
    "$root\OpenSearch\certs",
    "$root\OpenSearch\security",
    "$root\OpenSearch\data",
    "$root\OpenSearch\logs"
  )

  foreach ($p in $paths) {
    try { New-Item -ItemType Directory -Force -Path $p | Out-Null } catch { }
  }

  # ---- ACL hardening / determinism ----
  # Use SIDs so this works on non-English Windows too.
  $sidSystem = '*S-1-5-18'        # SYSTEM
  $sidAdmins = '*S-1-5-32-544'    # BUILTIN\Administrators
  $sidUsers  = '*S-1-5-32-545'    # BUILTIN\Users

  try {
    # Ensure SYSTEM + Admins can always read/write everything under ProgramData\TinySocs
    & icacls $root /inheritance:e /grant:r `
      "${sidSystem}:(OI)(CI)(F)" `
      "${sidAdmins}:(OI)(CI)(F)" `
      /t /c /q | Out-Null

    # Allow interactive users to modify the “operational” dirs (logs/queue).
    foreach ($rw in @("$root\logs", "$root\queue", "$root\OpenSearch\logs", "$root\Collector\logs")) {
      if (Test-Path -LiteralPath $rw) {
        & icacls $rw /inheritance:e /grant:r `
          "${sidSystem}:(OI)(CI)(F)" `
          "${sidAdmins}:(OI)(CI)(F)" `
          "${sidUsers}:(OI)(CI)(M)" `
          /t /c /q | Out-Null
      }
    }
  } catch {
    # If ACL adjustments fail for any reason, we still want install to continue.
  }

  # Ensure SYSTEM can traverse/read the state trees services rely on
  try { Ensure-SystemReadAcl -Path "$root\Collector" } catch { }
  try { Ensure-SystemReadAcl -Path "$root\OpenSearch" } catch { }
}

function Install-TinySocs {
  try {
    New-ProgramDataLayout
    Write-TinySocsLog "ProgramData layout ensured at $(Get-TinySocsDataRoot)."

    # OpenSearch invariants (ProgramData-owned + upgrade-safe)
    Sync-TinySocsOpenSearchConfigToProgramData

    # Canonicalize ProgramData opensearch.yml (idempotent; prevents duplicate-key boot failures)
    Ensure-OpenSearchYamlCanonical

    Register-TinySocsOpenSearchService

    # Agent invariants (ACL/EFS)
    Ensure-TinySocsAgentConfigReadable

    # Optional: template self-heal at install time (best-effort; safe if auth not wired yet)
    # If you have admin creds available as env vars, it will apply; otherwise it just logs and moves on.
    $siemUrl = [Environment]::GetEnvironmentVariable("SIEM_URL","Machine")
    if (-not $siemUrl) { $siemUrl = "https://localhost:9201" }

    $u = [Environment]::GetEnvironmentVariable("TINYSOCS_SIEM_USER","Machine")
    $p = [Environment]::GetEnvironmentVariable("TINYSOCS_SIEM_PASS","Machine")

    if ($u -and $p) {
      Ensure-TinySocsWinlogbeatTemplate -SiemUrl $siemUrl -User $u -Pass $p
    } else {
      Write-TinySocsLog -Level "DEBUG" -Message "Skipping template bootstrap (TINYSOCS_SIEM_USER/PASS not set at Machine scope)."
    }
  } catch {
    Write-TinySocsLog -Level "ERROR" -Message ("Install-TinySocs failed: " + $_.Exception.Message)
    throw
  }
}

# Helper: module version/path info for debugging
function Get-TinySocsInstallerModuleInfo {
  [CmdletBinding()]
  param()

  $p = $null
  try { $p = $MyInvocation.MyCommand.Path } catch { }
  if ([string]::IsNullOrWhiteSpace($p)) {
    try { $p = $PSCommandPath } catch { }
  }

  [pscustomobject]@{
    Version   = $script:TinySocsInstallerVersion
    Path      = $p
    PSEdition = $PSVersionTable.PSEdition
    PSVersion = $PSVersionTable.PSVersion.ToString()
  }
}

# -- Credential Manager helpers (TinySocs/Phase7) ------------------------------
# We store secrets as Generic credentials so services and tasks can read them.
# Targets we use:
#   TinySocs/Node/Secret
#   TinySocs/Master/SharedSecret
#   TinySocs/SIEM/Creds

if (-not ('TinySocs.Security.CredNative2' -as [type])) {
  Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

namespace TinySocs.Security
{
    public static class CredNative2
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct CREDENTIAL
        {
            public uint Flags;
            public uint Type;
            public IntPtr TargetName;
            public IntPtr Comment;
            public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
            public uint CredentialBlobSize;
            public IntPtr CredentialBlob;
            public uint Persist;
            public uint AttributeCount;
            public IntPtr Attributes;
            public IntPtr TargetAlias;
            public IntPtr UserName;
        }

        public static CREDENTIAL PtrToCredential(IntPtr credentialPtr)
        {
            return (CREDENTIAL)Marshal.PtrToStructure(credentialPtr, typeof(CREDENTIAL));
        }

        [DllImport("advapi32.dll", EntryPoint = "CredWriteW", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern bool CredWrite(ref CREDENTIAL userCredential, uint flags);

        [DllImport("advapi32.dll", EntryPoint = "CredReadW", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern bool CredRead(string target, uint type, uint reservedFlag, out IntPtr credentialPtr);

        [DllImport("advapi32.dll", EntryPoint = "CredFree", SetLastError = false)]
        public static extern void CredFree(IntPtr cred);

        [DllImport("advapi32.dll", EntryPoint = "CredDeleteW", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern bool CredDelete(string target, uint type, uint flags);
    }
}
"@
}

function Set-TSCredential {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$Name,
    [Parameter(Mandatory)][string]$Secret
  )
  $bytes = [System.Text.Encoding]::Unicode.GetBytes($Secret)
  $cred = New-Object TinySocs.Security.CredNative2+CREDENTIAL
  $cred.Flags = 0
  $cred.Type  = 1           # CRED_TYPE_GENERIC
  $cred.Persist = 2         # CRED_PERSIST_LOCAL_MACHINE
  $cred.AttributeCount = 0

  $targetPtr = [IntPtr]::Zero
  $userPtr   = [IntPtr]::Zero

  try {
    $targetPtr = [Runtime.InteropServices.Marshal]::StringToHGlobalUni($Name)
    $userPtr   = [Runtime.InteropServices.Marshal]::StringToHGlobalUni("TinySocs")

    $cred.TargetName = $targetPtr
    $cred.UserName   = $userPtr

    $cred.CredentialBlobSize = $bytes.Length
    $cred.CredentialBlob = [Runtime.InteropServices.Marshal]::AllocHGlobal($bytes.Length)
    [Runtime.InteropServices.Marshal]::Copy($bytes, 0, $cred.CredentialBlob, $bytes.Length)

    if (-not [TinySocs.Security.CredNative2]::CredWrite([ref]$cred, 0)) {
      $err = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
      throw "CredWrite failed for $Name (Win32 $err)"
    }
  }
  finally {
    if ($cred.CredentialBlob -ne [IntPtr]::Zero) {
      [Runtime.InteropServices.Marshal]::FreeHGlobal($cred.CredentialBlob)
    }
    if ($targetPtr -ne [IntPtr]::Zero) {
      [Runtime.InteropServices.Marshal]::FreeHGlobal($targetPtr)
    }
    if ($userPtr -ne [IntPtr]::Zero) {
      [Runtime.InteropServices.Marshal]::FreeHGlobal($userPtr)
    }
  }
}

function Get-TSCredential {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$Name
  )
  $ptr = [IntPtr]::Zero
  try {
    $ok = [TinySocs.Security.CredNative2]::CredRead($Name, 1, 0, [ref]$ptr) # CRED_TYPE_GENERIC
    if (-not $ok -or $ptr -eq [IntPtr]::Zero) { return $null }
    $raw = [TinySocs.Security.CredNative2]::PtrToCredential($ptr)
    if ($raw.CredentialBlobSize -le 0 -or $raw.CredentialBlob -eq [IntPtr]::Zero) { return $null }
    $bytes = New-Object byte[] $raw.CredentialBlobSize
    [Runtime.InteropServices.Marshal]::Copy($raw.CredentialBlob, $bytes, 0, $raw.CredentialBlobSize)
    return ([System.Text.Encoding]::Unicode.GetString($bytes)).Trim([char]0)
  }
  finally {
    if ($ptr -ne [IntPtr]::Zero) {
      [TinySocs.Security.CredNative2]::CredFree($ptr)
    }
  }
}

function Remove-TSCredential {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$Name
  )
  [TinySocs.Security.CredNative2]::CredDelete($Name, 1, 0) | Out-Null
}

function Test-TSCredentialInterop {
  [CmdletBinding()]
  param(
    [string]$Name = 'TinySocs/_selftest/CredMan',
    [string]$Secret = 'tinysocs-credman-selftest'
  )

  Set-TSCredential -Name $Name -Secret $Secret
  $got = Get-TSCredential -Name $Name
  Remove-TSCredential -Name $Name

  if ($got -ne $Secret) {
    throw "CredMan self-test failed. Expected '$Secret' but got '$got'. Imported module: $(Get-TinySocsInstallerModuleInfo | ConvertTo-Json -Compress)"
  }
  return $true
}

function Update-TinySocsInstalledModule {
  [CmdletBinding(SupportsShouldProcess)]
  param(
    [string]$InstallModulePath = 'C:\Program Files\TinySocs\modules\TinySocs.Installer.psm1',
    [string]$SourceModulePath
  )

  Assert-TinySocsAdmin

  $src = $null
  if ($SourceModulePath -and (Test-Path $SourceModulePath -PathType Leaf)) {
    $src = $SourceModulePath
  } else {
    try { $src = $MyInvocation.MyCommand.Path } catch { }
    if ([string]::IsNullOrWhiteSpace($src)) {
      try { $src = $PSCommandPath } catch { }
    }
  }

  if ([string]::IsNullOrWhiteSpace($src) -or -not (Test-Path $src -PathType Leaf)) {
    throw "Cannot resolve source module path for copying. Source='$src' SourceModulePath='$SourceModulePath'"
  }

  $dstDir = Split-Path -Parent $InstallModulePath
  if (-not (Test-Path $dstDir)) {
    New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
  }

  if ($PSCmdlet.ShouldProcess($InstallModulePath, "Copy module from '$src'")) {
    try { Ensure-TinySocsWritableFile -Path $InstallModulePath } catch { }
    Copy-Item -Force -Path $src -Destination $InstallModulePath

    Write-TinySocsLog "Updated installed TinySocs.Installer.psm1 at '$InstallModulePath' from '$src' (version=$script:TinySocsInstallerVersion)."
    Write-TinySocsLog "Restart PowerShell, then: Import-Module '$InstallModulePath' -Force; Get-TinySocsInstallerModuleInfo"
  }
}

function Set-TinySocsSiemCredential {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$SiemUrl,
    [Parameter(Mandatory)][string]$SiemUser,
    [Parameter(Mandatory)][string]$SiemPass,
    [bool]$SiemSslVerify = $true,

    # Optional: CA cert path (not secret, but useful for clients that want verify=true)
    [string]$CaCertPath,

    # If set, also mirror SIEM_USER/SIEM_PASS into machine env (secrets on machine env = optional)
    [switch]$MirrorToEnv,

    # If set, verify the supplied creds actually work against the SIEM before storing.
    # Uses curl.exe if present (and will pass --ssl-no-revoke for Windows schannel/CRL weirdness).
    [switch]$ValidateAuth
  )

  $normUrl = $SiemUrl.TrimEnd('/')

  if ($ValidateAuth.IsPresent) {
    try {
      $curl = (Get-Command curl.exe -ErrorAction SilentlyContinue)
      if (-not $curl) { throw "curl.exe not found; can't ValidateAuth on Windows reliably (PS 5.1 lacks a clean CRL bypass)." }

      $probeUrl = $normUrl
      $args = @("--silent","--show-error","--fail","--ssl-no-revoke","-u",("{0}:{1}" -f $SiemUser,$SiemPass),$probeUrl)

      # If caller asked for sslVerify=false, also skip cert verification
      if (-not [bool]$SiemSslVerify) { $args = @("--insecure") + $args }

      & $curl.Source @args | Out-Null
    } catch {
      throw ("Set-TinySocsSiemCredential ValidateAuth failed for {0} as {1}: {2}" -f $normUrl, $SiemUser, $_.Exception.Message)
    }
  }

  # Load existing payload so we preserve any extra fields we’ve stored over time
  $existingHt = @{}
  try {
    $rawExisting = Get-TSCredential -Name 'TinySocs/SIEM/Creds'
    if ($rawExisting) {
      $obj = $rawExisting | ConvertFrom-Json
      foreach ($p in $obj.PSObject.Properties) {
        $existingHt[$p.Name] = $p.Value
      }
    }
  } catch { }

  # Normalize legacy key variants -> canonical sslVerify
  try {
    if (-not $existingHt.ContainsKey('sslVerify')) {
      if ($existingHt.ContainsKey('ssl_verify')) { $existingHt['sslVerify'] = [bool]$existingHt['ssl_verify'] }
      elseif ($existingHt.ContainsKey('sslverify')) { $existingHt['sslVerify'] = [bool]$existingHt['sslverify'] }
    }
    if ($existingHt.ContainsKey('sslVerify') -and ($existingHt['sslVerify'] -is [string])) {
      $existingHt['sslVerify'] = ([string]$existingHt['sslVerify']).ToLowerInvariant() -eq 'true'
    }
  } catch { }

  # Canonical payload (also keep ssl_verify for any older readers)
  $payloadHt = @{}
  foreach ($k in $existingHt.Keys) { $payloadHt[$k] = $existingHt[$k] }

  $payloadHt['url']       = $normUrl
  $payloadHt['user']      = $SiemUser
  $payloadHt['pass']      = $SiemPass
  $payloadHt['sslVerify'] = [bool]$SiemSslVerify
  $payloadHt['ssl_verify']= [bool]$SiemSslVerify  # backward compatibility

  if (-not [string]::IsNullOrWhiteSpace($CaCertPath)) {
    $payloadHt['caCert']  = $CaCertPath
    $payloadHt['ca_cert'] = $CaCertPath  # backward compatibility
  }

  $payload = $payloadHt | ConvertTo-Json -Compress -Depth 20
  Set-TSCredential -Name 'TinySocs/SIEM/Creds' -Secret $payload

  $verifyString = if ($SiemSslVerify) { 'true' } else { 'false' }

  # Env: always safe to set URL + verify; CA cert is also non-secret
  $envBlock = @{
    SIEM_URL        = $normUrl
    SIEM_SSL_VERIFY = $verifyString
  }
  if (-not [string]::IsNullOrWhiteSpace($CaCertPath)) { $envBlock['SIEM_CA_CERT'] = $CaCertPath }

  if ($MirrorToEnv.IsPresent) {
    $envBlock['SIEM_USER'] = $SiemUser
    $envBlock['SIEM_PASS'] = $SiemPass
    Set-MachineEnv $envBlock
    Write-Host "[TinySocs] SIEM credentials stored in CredMan and env (url=$normUrl, sslVerify=$verifyString)."
  } else {
    Set-MachineEnv $envBlock
    Write-Host "[TinySocs] SIEM credentials stored in CredMan (env secrets not mirrored) (url=$normUrl, sslVerify=$verifyString)."
  }
}

function New-TinySocsBasicAuthHeader {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$User,
    [Parameter(Mandatory)][string]$Pass
  )
  $raw = "{0}:{1}" -f $User, $Pass
  $b64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($raw))
  return @{ Authorization = "Basic $b64" }
}

function Invoke-TinySocsOpenSearchApi {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][ValidateSet('GET','PUT','POST','DELETE')][string]$Method,
    [Parameter(Mandatory)][string]$Url,
    [Parameter(Mandatory)][string]$User,
    [Parameter(Mandatory)][string]$Pass,
    [string]$BodyJson,
    [switch]$SkipTlsVerify
  )

  $origCrl = $null
  try { $origCrl = [System.Net.ServicePointManager]::CheckCertificateRevocationList } catch { }
  try { [System.Net.ServicePointManager]::CheckCertificateRevocationList = $false } catch { }

  $origCallback = $null
  if ($SkipTlsVerify.IsPresent -and $Url.ToLower().StartsWith('https://')) {
    try {
      $origCallback = [System.Net.ServicePointManager]::ServerCertificateValidationCallback
      [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
    } catch { }
  }

  try {
    $headers = New-TinySocsBasicAuthHeader -User $User -Pass $Pass

    $irmParams = @{
      Method      = $Method
      Uri         = $Url
      Headers     = $headers
      ErrorAction = 'Stop'
    }

    if ($Method -in @('PUT','POST') -and $BodyJson) {
      $irmParams.ContentType = 'application/json'
      $irmParams.Body        = $BodyJson
    }

    return Invoke-RestMethod @irmParams
  }
  finally {
    if ($null -ne $origCallback) {
      try { [System.Net.ServicePointManager]::ServerCertificateValidationCallback = $origCallback } catch { }
    }
    if ($null -ne $origCrl) {
      try { [System.Net.ServicePointManager]::CheckCertificateRevocationList = $origCrl } catch { }
    }
  }
}

function Write-TinySocsCredManSecrets {
  [CmdletBinding()]
  param(
    [string]$SiemUrl = "https://127.0.0.1:9201",
    [string]$AdminUser = "admin",
    [string]$AdminPass,
    [string]$ServiceUser = "tinysocs",
    [string]$ServicePass,
    [bool]$SiemSslVerify = $true
  )

  if ([string]::IsNullOrWhiteSpace($AdminPass)) {
    try {
      $raw = Get-TSCredential -Name 'TinySocs/SIEM/Creds'
      if ($raw) {
        $j = $raw | ConvertFrom-Json
        if ($j.user) { $AdminUser = [string]$j.user }
        if ($j.pass) { $AdminPass = [string]$j.pass }

        # accept both key styles
        if ($null -ne $j.sslVerify) { $SiemSslVerify = [bool]$j.sslVerify }
        elseif ($null -ne $j.ssl_verify) { $SiemSslVerify = [bool]$j.ssl_verify }
        elseif ($null -ne $j.sslverify) { $SiemSslVerify = [bool]$j.sslverify }

        if ($j.url) { $SiemUrl = [string]$j.url }
      }
    } catch { }
  }

  if ([string]::IsNullOrWhiteSpace($AdminPass)) {
    throw "Write-TinySocsCredManSecrets: AdminPass not provided and TinySocs/SIEM/Creds was empty."
  }

  if ([string]::IsNullOrWhiteSpace($ServicePass)) {
    $ServicePass = New-TinySocsPassword -Length 32
  }

  # Canonical write (stores sslVerify + ssl_verify)
  Set-TinySocsSiemCredential -SiemUrl $SiemUrl -SiemUser $AdminUser -SiemPass $AdminPass -SiemSslVerify:$SiemSslVerify

  $svcPayload = @{
    url       = $SiemUrl.TrimEnd('/')
    user      = $ServiceUser
    pass      = $ServicePass
    sslVerify = $SiemSslVerify
  } | ConvertTo-Json -Compress

  $svcTarget = "TinySocs/OpenSearch/$ServiceUser"
  Set-TSCredential -Name $svcTarget -Secret $svcPayload

  try {
    Start-Process -FilePath "$env:WINDIR\System32\cmdkey.exe" `
      -ArgumentList @("/generic:$svcTarget", "/user:$ServiceUser", "/pass:$ServicePass") `
      -NoNewWindow -Wait | Out-Null
  } catch { }

  Write-TinySocsLog "CredMan secrets ensured: TinySocs/SIEM/Creds + $svcTarget (service user)."
  return @{
    SiemUrl       = $SiemUrl.TrimEnd('/')
    AdminUser     = $AdminUser
    ServiceUser   = $ServiceUser
    ServicePass   = $ServicePass
    SiemSslVerify = $SiemSslVerify
  }
}

function Test-TinySocsOpenSearchDataPresent {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$DataPath
  )

  if (-not (Test-Path $DataPath -PathType Container)) { return $false }

  try {
    # Typical OpenSearch layout: <data>\nodes\0\_state, indices, translog, etc.
    # "nodes" dir is common but not guaranteed to exist if something changed paths historically,
    # so we also do a cheap "any file anywhere under dataPath" probe.
    $nodes = Join-Path $DataPath "nodes"
    if (Test-Path $nodes -PathType Container) {
      $any = Get-ChildItem -Path $nodes -Recurse -Force -ErrorAction SilentlyContinue |
        Where-Object { -not $_.PSIsContainer } |
        Select-Object -First 1
      if ($any) { return $true }
    }

    $any2 = Get-ChildItem -Path $DataPath -Recurse -Force -ErrorAction SilentlyContinue |
      Where-Object { -not $_.PSIsContainer } |
      Select-Object -First 1

    return [bool]$any2
  } catch {
    # If probing fails, assume "present" to avoid destructive "fresh-init" behaviour.
    return $true
  }
}

function Initialize-TinySocsOpenSearchSecurity {
  [CmdletBinding()]
  param(
    [string]$SiemUrl = "https://127.0.0.1:9201",
    [string]$AdminUser = "admin",
    [string]$AdminPass,
    [string]$ServiceUser = "tinysocs",
    [string]$ServicePass,
    [string[]]$IndexPatterns = @("tinysocs-*","logs-*","security-auditlog-*"),
    [switch]$SkipTlsVerify,

    # New (safe defaults for first-boot slowness)
    [int]$ReadyTimeoutSeconds = 600,
    [int]$RetryCount = 30,
    [int]$RetrySleepSeconds = 3
  )

  $base = $SiemUrl.TrimEnd('/')

  if ([string]::IsNullOrWhiteSpace($AdminPass)) {
    try {
      $raw = Get-TSCredential -Name 'TinySocs/SIEM/Creds'
      if ($raw) {
        $j = $raw | ConvertFrom-Json
        if ($j.user) { $AdminUser = [string]$j.user }
        if ($j.pass) { $AdminPass = [string]$j.pass }
        if ($j.url)  { $base = ([string]$j.url).TrimEnd('/') }
      }
    } catch { }
  }
  if ([string]::IsNullOrWhiteSpace($AdminPass)) {
    throw "Initialize-TinySocsOpenSearchSecurity: AdminPass not provided and TinySocs/SIEM/Creds was empty."
  }

  if ([string]::IsNullOrWhiteSpace($ServicePass)) {
    $ServicePass = New-TinySocsPassword -Length 32
  }

  Write-TinySocsLog "Initializing OpenSearch security objects (url=$base, serviceUser=$ServiceUser)."

  # Small local helper: retry wrapper for flaky first-boot + Schannel weirdness
  $invokeWithRetry = {
    param(
      [Parameter(Mandatory=$true)][string]$Method,
      [Parameter(Mandatory=$true)][string]$Url,
      [string]$User,
      [string]$Pass,
      [string]$BodyJson
    )

    for ($i = 1; $i -le $RetryCount; $i++) {
      try {
        if ([string]::IsNullOrWhiteSpace($BodyJson)) {
          return Invoke-TinySocsOpenSearchApi -Method $Method -Url $Url -User $User -Pass $Pass -SkipTlsVerify:$SkipTlsVerify
        } else {
          return Invoke-TinySocsOpenSearchApi -Method $Method -Url $Url -User $User -Pass $Pass -BodyJson $BodyJson -SkipTlsVerify:$SkipTlsVerify
        }
      } catch {
        if ($i -ge $RetryCount) { throw }
        Write-TinySocsLog -Level "WARN" -Message ("OpenSearch API retry {0}/{1} failed: {2}" -f $i, $RetryCount, $_.Exception.Message)
        Start-Sleep -Seconds $RetrySleepSeconds
      }
    }
  }

  # 1) Readiness gate: wait until basic-auth GET to / works (not just “service started”)
  $deadline = (Get-Date).AddSeconds($ReadyTimeoutSeconds)
  $ready = $false
  while ((Get-Date) -lt $deadline) {
    try {
      $null = & $invokeWithRetry -Method GET -Url "$base/" -User $AdminUser -Pass $AdminPass
      $ready = $true
      break
    } catch {
      Write-TinySocsLog -Level "WARN" -Message ("Waiting for OpenSearch HTTP to become ready at {0}: {1}" -f $base, $_.Exception.Message)
      Start-Sleep -Seconds 5
    }
  }
  if (-not $ready) {
    throw "Initialize-TinySocsOpenSearchSecurity: OpenSearch HTTP not ready at $base within ${ReadyTimeoutSeconds}s."
  }

  # 2) Now we can sanity check cluster health (still via retry wrapper)
  try {
    $null = & $invokeWithRetry -Method GET -Url "$base/_cluster/health" -User $AdminUser -Pass $AdminPass
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Admin auth/health check failed: $($_.Exception.Message)"
    throw
  }

  $allAccess = @{
    users             = @($AdminUser)
    backend_roles     = @("admin")
    hosts             = @()
    and_backend_roles = @()
    description       = "Maps admin to all_access (TinySocs installer)"
  } | ConvertTo-Json -Depth 20 -Compress

  $null = & $invokeWithRetry -Method PUT `
    -Url "$base/_plugins/_security/api/rolesmapping/all_access" `
    -User $AdminUser -Pass $AdminPass -BodyJson $allAccess

  $roleObj = @{
    cluster_permissions = @(
      "cluster:monitor/*",
      "cluster:admin/ingest/pipeline/*",
      "cluster:admin/opensearch/ism/*",
      "cluster:admin/index_template/*"
    )
    index_permissions = @(
      @{
        index_patterns  = @($IndexPatterns)
        allowed_actions = @(
          "crud",
          "create_index",
          "indices:admin/create",
          "indices:admin/mapping/*",
          "indices:admin/settings/*",
          "indices:admin/template/*",
          "indices:data/write/*",
          "indices:data/read/*"
        )
      }
    )
    tenant_permissions = @()
    description        = "TinySocs service role (least-privilege baseline)"
  }
  $roleJson = $roleObj | ConvertTo-Json -Depth 20 -Compress

  $null = & $invokeWithRetry -Method PUT `
    -Url "$base/_plugins/_security/api/roles/tinysocs_role" `
    -User $AdminUser -Pass $AdminPass -BodyJson $roleJson

  $userObj = @{
    password      = $ServicePass
    backend_roles = @("tinysocs")
    attributes    = @{}
    description   = "TinySocs service user"
  } | ConvertTo-Json -Depth 20 -Compress

  $null = & $invokeWithRetry -Method PUT `
    -Url "$base/_plugins/_security/api/internalusers/$ServiceUser" `
    -User $AdminUser -Pass $AdminPass -BodyJson $userObj

  $mapObj = @{
    users             = @($ServiceUser)
    backend_roles     = @("tinysocs")
    hosts             = @()
    and_backend_roles = @()
  } | ConvertTo-Json -Depth 20 -Compress

  $null = & $invokeWithRetry -Method PUT `
    -Url "$base/_plugins/_security/api/rolesmapping/tinysocs_role" `
    -User $AdminUser -Pass $AdminPass -BodyJson $mapObj

  $storedVerify = (-not $SkipTlsVerify.IsPresent)
  $null = Write-TinySocsCredManSecrets -SiemUrl $base -AdminUser $AdminUser -AdminPass $AdminPass `
    -ServiceUser $ServiceUser -ServicePass $ServicePass -SiemSslVerify:$storedVerify

  $auth = & $invokeWithRetry -Method GET `
    -Url "$base/_plugins/_security/authinfo" `
    -User $ServiceUser -Pass $ServicePass

  $roles = @()
  try { $roles = @($auth.roles) } catch { }
  if ($roles -notcontains 'tinysocs_role') {
    throw "Initialize-TinySocsOpenSearchSecurity: verification failed; $ServiceUser did not receive tinysocs_role (roles=$($roles -join ','))."
  }

  Write-TinySocsLog "OpenSearch security initialized: role+user+mapping verified (service role present)."
  return @{
    SiemUrl     = $base
    AdminUser   = $AdminUser
    ServiceUser = $ServiceUser
  }
}

function Test-TinySocsOpenSearch {
  [CmdletBinding()]
  param(
    [string]$SiemUrl = "https://127.0.0.1:9201",
    [Parameter(Mandatory)][string]$User,
    [Parameter(Mandatory)][string]$Pass,
    [string]$IndexName = "tinysocs-smoketest-001",
    [switch]$Cleanup,
    [switch]$SkipTlsVerify
  )

  $base = $SiemUrl.TrimEnd('/')
  Write-TinySocsLog "Smoke test: $base as user=$User (index=$IndexName)."

  $health = Invoke-TinySocsOpenSearchApi -Method GET -Url "$base/_cluster/health" -User $User -Pass $Pass -SkipTlsVerify:$SkipTlsVerify

  try {
    $null = Invoke-TinySocsOpenSearchApi -Method PUT -Url "$base/$IndexName" -User $User -Pass $Pass -BodyJson '{}' -SkipTlsVerify:$SkipTlsVerify
  } catch {
    Write-TinySocsLog -Level "DEBUG" -Message "Index create returned: $($_.Exception.Message)"
  }

  $doc = @{ msg = "hello"; ts = (Get-Date -Format o) } | ConvertTo-Json -Compress
  $write = Invoke-TinySocsOpenSearchApi -Method POST -Url "$base/$IndexName/_doc" -User $User -Pass $Pass -BodyJson $doc -SkipTlsVerify:$SkipTlsVerify
  $search = Invoke-TinySocsOpenSearchApi -Method GET -Url "$base/$IndexName/_search" -User $User -Pass $Pass -SkipTlsVerify:$SkipTlsVerify

  if ($Cleanup.IsPresent) {
    try { $null = Invoke-TinySocsOpenSearchApi -Method DELETE -Url "$base/$IndexName" -User $User -Pass $Pass -SkipTlsVerify:$SkipTlsVerify } catch { }
  }

  return @{
    cluster_status = $health.status
    wrote_doc      = $write.result
    hits           = $search.hits.total.value
  }
}

function Assert-TinySocsOpenSearchSecurityConfigPresent {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$ConfigPath
  )

  if (-not (Test-Path $ConfigPath -PathType Leaf)) {
    throw "OpenSearch config file missing: $ConfigPath"
  }

  $raw = Get-Content -Path $ConfigPath -Raw -ErrorAction Stop

  $requiredPatterns = @(
    '(?m)^\s*plugins\.security\.disabled\s*:\s*false\s*$',
    '(?m)^\s*plugins\.security\.ssl\.http\.enabled\s*:\s*true\s*$',
    '(?m)^\s*plugins\.security\.ssl\.http\.keystore_filepath\s*:\s*\S+',
    '(?m)^\s*plugins\.security\.ssl\.http\.truststore_filepath\s*:\s*\S+',
    '(?m)^\s*plugins\.security\.ssl\.transport\.keystore_filepath\s*:\s*\S+',
    '(?m)^\s*plugins\.security\.ssl\.transport\.truststore_filepath\s*:\s*\S+'
  )

  $missing = @()
  foreach ($pat in $requiredPatterns) {
    if ($raw -notmatch $pat) { $missing += $pat }
  }

  if ($missing.Count -gt 0) {
    throw ("OpenSearch security/TLS settings were not persisted to opensearch.yml. " +
           "ConfigPath=$ConfigPath; MissingPatterns=$($missing -join '; ')")
  }

  Write-TinySocsLog "Verified OpenSearch security/TLS keys present in $ConfigPath"
}

function Get-TinySocsInstallRoot {
  $defaultRoot = "C:\Program Files\TinySocs"
  if (Test-Path $defaultRoot -PathType Container) {
    return $defaultRoot
  }

  if ($PSScriptRoot) {
    return (Split-Path -Parent $PSScriptRoot)
  }

  return $defaultRoot
}

function Invoke-TinySocsCmd {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$Command
  )
  # Run via cmd.exe so native stderr doesn't become a terminating PowerShell error
  # when $ErrorActionPreference = 'Stop'
  & cmd.exe /V:OFF /C $Command | Out-Null
}

function Repair-TinySocsProgramDataAcls {
  [CmdletBinding()]
  param()

  $root = Join-Path $env:ProgramData 'TinySocs'

  $targets = @(
    (Join-TsPath $root @('logs')),
    (Join-TsPath $root @('OpenSearch')),
    (Join-TsPath $root @('OpenSearch','config')),
    (Join-TsPath $root @('OpenSearch','config','certs')),
    (Join-TsPath $root @('OpenSearch','certs')),
    (Join-TsPath $root @('OpenSearch','data')),
    (Join-TsPath $root @('OpenSearch','security'))
  )

  foreach ($t in $targets) {
    if (-not (Test-Path $t)) { continue }

    try {
      & icacls $t /inheritance:e /grant:r `
        "SYSTEM:(OI)(CI)F" `
        "BUILTIN\Administrators:(OI)(CI)F" | Out-Null
    } catch { }
  }

  # logs dir: allow Users modify so normal reads/writes don’t explode
  $logs = Join-TsPath $root @('logs')
  if (Test-Path $logs) {
    try { & icacls $logs /grant:r "BUILTIN\Users:(OI)(CI)M" | Out-Null } catch { }
  }
}

function Repair-TinySocsOpenSearchCertAcls {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$CertsDir
  )

  if (-not (Test-Path $CertsDir -PathType Container)) { return }

  # Well-known SIDs
  $sysSid = New-Object System.Security.Principal.SecurityIdentifier('S-1-5-18')       # LocalSystem
  $admSid = New-Object System.Security.Principal.SecurityIdentifier('S-1-5-32-544')   # BUILTIN\Administrators

  function Resolve-ServiceAccountSid {
    param([string]$ServiceName)

    try {
      $svc = Get-CimInstance Win32_Service -Filter ("Name='{0}'" -f $ServiceName) -ErrorAction Stop
      $startName = ($svc.StartName | ForEach-Object { $_.Trim() })

      if (-not $startName) { return $null }

      switch -Regex ($startName) {
        '^LocalSystem$'                { return (New-Object System.Security.Principal.SecurityIdentifier('S-1-5-18')) } # SYSTEM
        '^NT AUTHORITY\\LocalService$' { return (New-Object System.Security.Principal.SecurityIdentifier('S-1-5-19')) }
        '^NT AUTHORITY\\NetworkService$' { return (New-Object System.Security.Principal.SecurityIdentifier('S-1-5-20')) }
        default {
          # Normalize .\User -> COMPUTER\User for translation
          if ($startName.StartsWith('.\')) {
            $startName = "$env:COMPUTERNAME\" + $startName.Substring(2)
          }

          $acct = New-Object System.Security.Principal.NTAccount($startName)
          return $acct.Translate([System.Security.Principal.SecurityIdentifier])
        }
      }
    } catch {
      return $null
    }
  }

  $svcSid = Resolve-ServiceAccountSid -ServiceName 'TinySocsOpenSearch'

  # If we can't resolve it, don't invent one. Keep it SYSTEM/Admins only.
  # If the service runs as LocalSystem, $svcSid == $sysSid; we dedupe later.
  try {
    # CRITICAL: ensure certs dir isn't EFS-encrypted (service account may not read user-encrypted files)
    # Also sets: "New files added to this directory will not be encrypted."
    Invoke-TinySocsCmd ('cipher /d /s:"{0}" >nul 2>&1' -f $CertsDir)

    # Clear common attributes that can block replace/propagation
    try { & attrib.exe -R -S -H "$CertsDir" /S /D 2>$null | Out-Null } catch { }

    # Build a strict ACL for the directory (no inheritance)
    $dirAcl = New-Object System.Security.AccessControl.DirectorySecurity
    $dirAcl.SetAccessRuleProtection($true, $false)  # disable inheritance, do NOT preserve inherited rules

    $inheritFlags = [System.Security.AccessControl.InheritanceFlags]::ContainerInherit `
                  -bor [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
    $propFlags    = [System.Security.AccessControl.PropagationFlags]::None

    $dirAcl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($sysSid, 'FullControl', $inheritFlags, $propFlags, 'Allow')))
    $dirAcl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($admSid, 'FullControl', $inheritFlags, $propFlags, 'Allow')))

    # Only add service rule if it resolves AND isn't redundant
    if ($svcSid -and ($svcSid.Value -ne $sysSid.Value) -and ($svcSid.Value -ne $admSid.Value)) {
      $dirAcl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($svcSid, 'ReadAndExecute', $inheritFlags, $propFlags, 'Allow')))
    }

    Set-Acl -Path $CertsDir -AclObject $dirAcl

    # File-level sanity for known cert/key file types (no inheritance, strict principals)
    Get-ChildItem -Path $CertsDir -File -Recurse -Force -ErrorAction SilentlyContinue |
      Where-Object { $_.Extension -in @('.p12','.pem','.cer','.crt','.key','.dpapi') } |
      ForEach-Object {
        $f = $_.FullName
        try { & attrib.exe -R -S -H "$f" 2>$null | Out-Null } catch { }

        $fileAcl = New-Object System.Security.AccessControl.FileSecurity
        $fileAcl.SetAccessRuleProtection($true, $false)  # disable inheritance, drop inherited rules

        $noInherit = [System.Security.AccessControl.InheritanceFlags]::None
        $noProp    = [System.Security.AccessControl.PropagationFlags]::None

        $fileAcl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($sysSid, 'FullControl', $noInherit, $noProp, 'Allow')))
        $fileAcl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($admSid, 'FullControl', $noInherit, $noProp, 'Allow')))

        # Service account needs to READ cert material; no execute permission on files.
        if ($svcSid -and ($svcSid.Value -ne $sysSid.Value) -and ($svcSid.Value -ne $admSid.Value)) {
          $fileAcl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($svcSid, 'Read', $noInherit, $noProp, 'Allow')))
        }

        Set-Acl -Path $f -AclObject $fileAcl
      }

    $svcName = if ($svcSid) { $svcSid.Value } else { "<unresolved>" }
    Write-TinySocsLog "Repaired OpenSearch cert ACLs (strict: SYSTEM/Admins + svc=$svcName) + ensured not EFS-encrypted: $CertsDir"
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Repair-TinySocsOpenSearchCertAcls failed for ${CertsDir}: $($_.Exception.Message)"
  }
}

# -- Security/ACL helpers ------------------------------------------------------
function Set-TinySocsSecureAcl {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$Path,
    [switch]$UsersRead
  )

  if (-not (Test-Path -LiteralPath $Path)) { return }

  try {
    # SIDs are locale-proof:
    $sys  = '*S-1-5-18'        # LocalSystem
    $adm  = '*S-1-5-32-544'    # BUILTIN\Administrators
    $user = '*S-1-5-32-545'    # BUILTIN\Users

    Invoke-TinySocsCmd ('takeown /F "{0}" /A /R /D Y >nul 2>&1' -f $Path)

    # Reset FIRST so you never end up with an empty DACL.
    Invoke-TinySocsCmd ('icacls "{0}" /reset /T /C >nul 2>&1' -f $Path)

    # Remove common explicit deny ACEs (these can outlive grant:r)
    Invoke-TinySocsCmd ('icacls "{0}" /remove:d "Everyone" "Users" "Authenticated Users" /T /C >nul 2>&1' -f $Path)

    $grant = @(
      ('"{0}:(OI)(CI)F"' -f $sys),
      ('"{0}:(OI)(CI)F"' -f $adm)
    )

    if ($UsersRead.IsPresent) {
      $grant += ('"{0}:(OI)(CI)RX"' -f $user)
    }

    Invoke-TinySocsCmd ('icacls "{0}" /inheritance:r /grant:r {1} /T /C >nul 2>&1' -f $Path, ($grant -join ' '))

    Write-TinySocsLog "ACL hardened: $Path (SYSTEM+Admins full$(if ($UsersRead) { ', Users RX' } else { '' }))"
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to harden ACL for ${Path}: $($_.Exception.Message)"
  }
}

function Ensure-TinySocsLogAcl {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$LogDir
  )

  if (-not (Test-Path -LiteralPath $LogDir)) { return }

  # Use SID form that icacls understands (leading *)
  $sidSystem = '*S-1-5-18'
  $sidAdmins = '*S-1-5-32-544'
  $sidUsers  = '*S-1-5-32-545'

  try {
    # Make sure the directory exists
    New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

    # IMPORTANT: avoid "$sid:(...)" parsing bug by using ${} (or string concatenation)
    & icacls $LogDir /inheritance:e /grant:r `
      "${sidSystem}:(OI)(CI)(F)" `
      "${sidAdmins}:(OI)(CI)(F)" `
      "${sidUsers}:(OI)(CI)(M)" `
      /t /c /q 2>$null | Out-Null
  } catch {
    try { Write-Warning "[TinySocs] Failed to harden log ACLs on '$LogDir': $($_.Exception.Message)" } catch { }
  }
}

function Ensure-TinySocsWritableFile {
  [CmdletBinding()]
  param([Parameter(Mandatory)][string]$Path)

  try {
    $sys = '*S-1-5-18'
    $adm = '*S-1-5-32-544'

    $dir = Split-Path -Parent $Path
    if ($dir -and (Test-Path $dir)) {
      Invoke-TinySocsCmd ('takeown /F "{0}" /A /R /D Y >nul 2>&1' -f $dir)
      Invoke-TinySocsCmd ('icacls "{0}" /reset /T /C >nul 2>&1' -f $dir)
      Invoke-TinySocsCmd ('icacls "{0}" /remove:d "Everyone" "Users" "Authenticated Users" /T /C >nul 2>&1' -f $dir)
      Invoke-TinySocsCmd ('icacls "{0}" /inheritance:r /grant:r "{1}:(OI)(CI)F" "{2}:(OI)(CI)F" /T /C >nul 2>&1' -f `
        $dir, $sys, $adm)
    }

    if (Test-Path $Path) {
      try {
        $item = Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
        if ($item) {
          $item.Attributes = ($item.Attributes -band (-bnot ([IO.FileAttributes]::ReadOnly -bor [IO.FileAttributes]::Hidden -bor [IO.FileAttributes]::System)))
        }
      } catch { }

      Invoke-TinySocsCmd ('takeown /F "{0}" /A >nul 2>&1' -f $Path)
      Invoke-TinySocsCmd ('icacls "{0}" /reset /C >nul 2>&1' -f $Path)
      Invoke-TinySocsCmd ('icacls "{0}" /remove:d "Everyone" "Users" "Authenticated Users" /C >nul 2>&1' -f $Path)
      Invoke-TinySocsCmd ('icacls "{0}" /inheritance:r /grant:r "{1}:F" "{2}:F" /C >nul 2>&1' -f `
        $Path, $sys, $adm)
    }
  } catch {
    Write-TinySocsLog -Level 'WARN' -Message "Ensure-TinySocsWritableFile failed for ${Path}: $($_.Exception.Message)"
  }
}

function Resolve-TinySocsOpenSearchSeedConfigDir {
  $rootVal = (Get-TinySocsInstallRoot | Select-Object -First 1)
  $root    = [string]$rootVal

  $candidates = @(
    (Join-Path -Path $root -ChildPath "OpenSearch\config"),
    (Join-Path -Path $root -ChildPath "OpenSearch\seed\config"),
    (Join-Path -Path $root -ChildPath "OpenSearch\seed\OpenSearch\config")
  ) | Where-Object { Test-Path -LiteralPath $_ }

  foreach ($c in $candidates) {
    if (Test-Path -LiteralPath (Join-Path -Path $c -ChildPath "opensearch.yml")) { return $c }
  }

  $osHome = Join-Path -Path $root -ChildPath "OpenSearch"
  if (Test-Path -LiteralPath $osHome) {
    $hit = Get-ChildItem -Path $osHome -Recurse -Filter "opensearch.yml" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($hit) { return (Split-Path -Parent $hit.FullName) }
  }

  return $null
}

function Ensure-OpenSearchYamlPaths {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$YamlPath,
    [int]$HttpPort = 9201
  )

  function _YamlSingleQuote {
    param([Parameter(Mandatory)][AllowEmptyString()][string]$s)
    return ("'" + ($s -replace "'","''") + "'")
  }

  function _Ensure-TinySocsReadable {
    param(
      [Parameter(Mandatory)][string]$Path,
      [switch]$IsDir
    )
    if (-not (Test-Path $Path)) { return }

    $ic = Join-Path $env:WINDIR "System32\icacls.exe"
    if (-not (Test-Path $ic -PathType Leaf)) { return }

    try {
      if ($IsDir) {
        & $ic $Path /inheritance:e 1>$null 2>$null
        & $ic $Path /grant "SYSTEM:(OI)(CI)RX" "Administrators:(OI)(CI)RX" 1>$null 2>$null
      } else {
        & $ic $Path /inheritance:e 1>$null 2>$null
        & $ic $Path /grant "SYSTEM:R" "Administrators:R" 1>$null 2>$null
      }
    } catch { }
  }

  if (-not (Test-Path $YamlPath -PathType Leaf)) {
    throw "Ensure-OpenSearchYamlPaths: YamlPath not found: $YamlPath"
  }

  $rootVal  = (Get-TinySocsDataRoot | Select-Object -First 1)
  $root     = ([string]$rootVal).Trim()

  if ([string]::IsNullOrWhiteSpace($root)) {
    throw "Ensure-OpenSearchYamlPaths: Get-TinySocsDataRoot returned empty."
  }
  if (-not (Test-Path $root -PathType Container)) {
    throw "Ensure-OpenSearchYamlPaths: Data root does not exist on disk: $root"
  }

  # Quote these so YAML doesn't misparse e.g. "C:\..." or spaces.
  $dataPath = _YamlSingleQuote -s (Join-Path -Path $root -ChildPath "OpenSearch\data")
  $logsPath = _YamlSingleQuote -s (Join-Path -Path $root -ChildPath "OpenSearch\logs")

  $raw = Get-Content -Path $YamlPath -Raw -ErrorAction Stop
  if ($null -eq $raw) { $raw = "" }

  # path.data
  if ($raw -match '(?im)^\s*path\.data\s*:') {
    $raw = [regex]::Replace(
      $raw,
      '^\s*path\.data\s*:.*$',
      ("path.data: {0}" -f $dataPath),
      [System.Text.RegularExpressions.RegexOptions]::IgnoreCase -bor
      [System.Text.RegularExpressions.RegexOptions]::Multiline
    )
  } else {
    $raw += "`r`npath.data: $dataPath`r`n"
  }

  # path.logs
  if ($raw -match '(?im)^\s*path\.logs\s*:') {
    $raw = [regex]::Replace(
      $raw,
      '^\s*path\.logs\s*:.*$',
      ("path.logs: {0}" -f $logsPath),
      [System.Text.RegularExpressions.RegexOptions]::IgnoreCase -bor
      [System.Text.RegularExpressions.RegexOptions]::Multiline
    )
  } else {
    $raw += "`r`npath.logs: $logsPath`r`n"
  }

  # network.host (loopback)
  if ($raw -match '(?im)^\s*network\.host\s*:') {
    $raw = [regex]::Replace(
      $raw,
      '^\s*network\.host\s*:.*$',
      "network.host: 127.0.0.1",
      [System.Text.RegularExpressions.RegexOptions]::IgnoreCase -bor
      [System.Text.RegularExpressions.RegexOptions]::Multiline
    )
  } else {
    $raw += "`r`nnetwork.host: 127.0.0.1`r`n"
  }

  # http.port (canonical 9201)
  if ($raw -match '(?im)^\s*http\.port\s*:') {
    $raw = [regex]::Replace(
      $raw,
      '^\s*http\.port\s*:.*$',
      ("http.port: {0}" -f $HttpPort),
      [System.Text.RegularExpressions.RegexOptions]::IgnoreCase -bor
      [System.Text.RegularExpressions.RegexOptions]::Multiline
    )
  } else {
    $raw += "`r`nhttp.port: $HttpPort`r`n"
  }

  # TLS file path sanity (relative paths expected)
  $pairs = @(
    @{ key = 'plugins.security.ssl.http.keystore_filepath';        val = 'certs/http.p12' },
    @{ key = 'plugins.security.ssl.http.truststore_filepath';      val = 'certs/trust.p12' },
    @{ key = 'plugins.security.ssl.transport.keystore_filepath';   val = 'certs/transport.p12' },
    @{ key = 'plugins.security.ssl.transport.truststore_filepath'; val = 'certs/trust.p12' }
  )

  foreach ($p in $pairs) {
    $k = [string]$p.key
    $v = [string]$p.val

    $pat = '^\s*' + [regex]::Escape($k) + '\s*:.*$'
    if ($raw -match "(?im)$pat") {
      $raw = [regex]::Replace(
        $raw,
        $pat,
        ("{0}: {1}" -f $k, $v),
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase -bor
        [System.Text.RegularExpressions.RegexOptions]::Multiline
      )
    } else {
      $raw += "`r`n${k}: $v`r`n"
    }
  }

  # Ensure trailing newline (minor, but keeps diffs sane)
  if ($raw -notmatch "(\r?\n)$") { $raw += "`r`n" }

  Set-Content -Path $YamlPath -Value $raw -Encoding UTF8 -Force

  # Ensure System can read config directory and the yaml (prevents weird "Access is denied" at boot)
  $confDir = Split-Path -Parent $YamlPath
  _Ensure-TinySocsReadable -Path $confDir -IsDir
  _Ensure-TinySocsReadable -Path $YamlPath

  Write-TinySocsLog "Ensured OpenSearch yaml paths + loopback bind + http.port=$HttpPort ($YamlPath)."
}

function Sync-TinySocsOpenSearchConfigToProgramData {
  [CmdletBinding()]
  param(
    [switch]$Force
  )

  $seed = Resolve-TinySocsOpenSearchSeedConfigDir
  if (-not $seed) {
    Write-TinySocsLog -Level "WARN" -Message "OpenSearch seed config not found under install root; skipping config seed."
    return
  }

  $root = [string](Get-TinySocsDataRoot | Select-Object -First 1)
  $dst  = Join-Path -Path $root -ChildPath "OpenSearch\config"
  $dstCerts = Join-Path -Path $dst -ChildPath "certs"

  New-Item -ItemType Directory -Force -Path $dst | Out-Null
  New-Item -ItemType Directory -Force -Path $dstCerts | Out-Null

  Write-TinySocsLog "Seeding OpenSearch config to $dst from $seed (Force=$($Force.IsPresent))"

  # Copy files from seed -> dst, but only overwrite when -Force is specified.
  $seedLen = $seed.TrimEnd('\').Length

  Get-ChildItem -LiteralPath $seed -Recurse -File -Force -ErrorAction SilentlyContinue | ForEach-Object {
    $src = $_.FullName
    $rel = $src.Substring($seedLen).TrimStart('\')
    $tgt = Join-Path -Path $dst -ChildPath $rel

    $tgtDir = Split-Path -Parent $tgt
    if (-not (Test-Path -LiteralPath $tgtDir)) {
      New-Item -ItemType Directory -Force -Path $tgtDir | Out-Null
    }

    # Never clobber existing certs unless Force
    $isCert = $rel -match '^(?i)certs\\'
    if ($isCert -and (Test-Path -LiteralPath $tgt) -and (-not $Force.IsPresent)) {
      return
    }

    if ((-not (Test-Path -LiteralPath $tgt)) -or $Force.IsPresent) {
      Copy-Item -LiteralPath $src -Destination $tgt -Force -ErrorAction SilentlyContinue
    }
  }

  $yml = Join-Path -Path $dst -ChildPath "opensearch.yml"
  if (Test-Path -LiteralPath $yml) {
    Ensure-OpenSearchYamlPaths -YamlPath $yml
  }

  Ensure-SystemReadAcl -Path $dst
  Ensure-SystemReadAcl -Path $dstCerts
}

function Set-TinySocsOpenSearchAcls {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$ServiceName,
    [Parameter(Mandatory)][string]$DataRoot,
    [Parameter(Mandatory)][string]$LogsPath,
    [Parameter(Mandatory)][string]$ConfigPath,
    [Parameter(Mandatory)][string]$RunnerPath,
    [switch]$FixBackups,
    [switch]$UsersReadConfig
  )

  $usersReadCfg = $true
  if ($PSBoundParameters.ContainsKey('UsersReadConfig')) { $usersReadCfg = $UsersReadConfig.IsPresent }

  try {
    # Well-known SIDs (stable across locales)
    $sysSid='*S-1-5-18'       # LocalSystem
    $admSid='*S-1-5-32-544'   # BUILTIN\Administrators
    $usersSid='*S-1-5-32-545' # BUILTIN\Users

    $curSid = $null
    try { $curSid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value } catch { }

    $curUser = $null
    try {
      if ($env:USERDOMAIN -and $env:USERNAME) { $curUser = "$($env:USERDOMAIN)\$($env:USERNAME)" }
      elseif ($env:USERNAME) { $curUser = "$($env:USERNAME)" }
    } catch { }

    # Detect the service start account -> SID (best-effort)
    $svcStart=$null
    try { $svcStart=([string](Get-CimInstance Win32_Service -Filter ("Name='{0}'" -f $ServiceName) -ErrorAction SilentlyContinue).StartName) } catch { }

    $svcSid=$null
    if ($svcStart) {
      if ($svcStart -match '^(LocalSystem|NT AUTHORITY\\SYSTEM)$') { $svcSid=$sysSid }
      elseif ($svcStart -match '^(LocalService|NT AUTHORITY\\LOCAL SERVICE)$') { $svcSid='*S-1-5-19' }
      elseif ($svcStart -match '^(NetworkService|NT AUTHORITY\\NETWORK SERVICE)$') { $svcSid='*S-1-5-20' }
      else {
        try {
          $nt = New-Object System.Security.Principal.NTAccount($svcStart)
          $sidVal = $nt.Translate([System.Security.Principal.SecurityIdentifier]).Value
          if ($sidVal) { $svcSid = "*$sidVal" }
        } catch { }
      }
    }

    function _AclTree {
      param(
        [string]$Path,
        [string[]]$Grant,
        [switch]$UsersRead,
        [switch]$AlsoGrantCurrentUser,
        [switch]$ResetFirst
      )
      if (-not (Test-Path $Path)) { return }

      Invoke-TinySocsCmd ('takeown /F "{0}" /A /R /D Y >nul 2>&1' -f $Path)

      if ($ResetFirst) {
        Invoke-TinySocsCmd ('icacls "{0}" /reset /T /C >nul 2>&1' -f $Path)
      }

      Invoke-TinySocsCmd ('icacls "{0}" /remove:d "Everyone" "Users" "Authenticated Users" /T /C >nul 2>&1' -f $Path)

      if ($curUser) { Invoke-TinySocsCmd ('icacls "{0}" /remove:d "{1}" /T /C >nul 2>&1' -f $Path, $curUser) }
      if ($curSid)  { Invoke-TinySocsCmd ('icacls "{0}" /remove:d "*{1}" /T /C >nul 2>&1' -f $Path, $curSid) }

      $grantArgs = @()
      foreach ($g in $Grant) { $grantArgs += ('"' + $g + '"') }

      if ($UsersRead) {
        $grantArgs += '"*S-1-5-32-545:RX"'
        $grantArgs += '"*S-1-5-32-545:(OI)(CI)RX"'
      }

      if ($AlsoGrantCurrentUser) {
        if ($curUser) {
          $grantArgs += ('"' + $curUser + ':RX"')
          $grantArgs += ('"' + $curUser + ':(OI)(CI)RX"')
        }
        if ($curSid) {
          $grantArgs += ('"*' + $curSid + ':RX"')
          $grantArgs += ('"*' + $curSid + ':(OI)(CI)RX"')
        }
      }

      $grantStr = ($grantArgs -join ' ')
      Invoke-TinySocsCmd ('icacls "{0}" /inheritance:r /grant:r {1} /T /C >nul 2>&1' -f $Path, $grantStr)
    }

    function _AclFiles {
      param(
        [string]$Root,
        [string[]]$Patterns,
        [string[]]$FileGrants
      )
      if (-not (Test-Path $Root)) { return }

      try {
        foreach ($pat in $Patterns) {
          Get-ChildItem -Path $Root -File -Recurse -Force -Filter $pat -ErrorAction SilentlyContinue |
            ForEach-Object {
              $f = $_.FullName
              Invoke-TinySocsCmd ('takeown /F "{0}" /A >nul 2>&1' -f $f)
              Invoke-TinySocsCmd ('icacls "{0}" /remove:d "Everyone" "Users" "Authenticated Users" /C >nul 2>&1' -f $f)
              foreach ($g in $FileGrants) {
                Invoke-TinySocsCmd ('icacls "{0}" /grant:r "{1}" /C >nul 2>&1' -f $f, $g)
              }
            }
        }
      } catch { }
    }

    function _FixCriticalConfigFiles {
      param([string]$Root)

      if (-not (Test-Path $Root)) { return }

      $critical = @(
        "jvm.options",
        "log4j2.properties",
        "opensearch.yml",
        "opensearch.keystore",
        "fips_java.security"
      )

      foreach ($name in $critical) {
        $p = Join-Path $Root $name
        if (-not (Test-Path $p -PathType Leaf)) { continue }

        Invoke-TinySocsCmd ('takeown /F "{0}" /A >nul 2>&1' -f $p)
        Invoke-TinySocsCmd ('icacls "{0}" /reset /C >nul 2>&1' -f $p)
        Invoke-TinySocsCmd ('icacls "{0}" /remove:d "Everyone" "Users" "Authenticated Users" /C >nul 2>&1' -f $p)
        Invoke-TinySocsCmd ('icacls "{0}" /inheritance:r /grant:r "{1}:F" "{2}:F" /C >nul 2>&1' -f $p, $sysSid, $admSid)

        if ($curUser) { Invoke-TinySocsCmd ('icacls "{0}" /grant:r "{1}:R" /C >nul 2>&1' -f $p, $curUser) }
        if ($curSid)  { Invoke-TinySocsCmd ('icacls "{0}" /grant:r "*{1}:R" /C >nul 2>&1' -f $p, $curSid) }

        if ($svcSid)  { Invoke-TinySocsCmd ('icacls "{0}" /grant:r "{1}:R" /C >nul 2>&1' -f $p, $svcSid) }
      }
    }

    $baseGrant = @(
      "${sysSid}:F",
      "${sysSid}:(OI)(CI)F",
      "${admSid}:F",
      "${admSid}:(OI)(CI)F"
    )
    if ($svcSid -and $svcSid -ne $sysSid) {
      $baseGrant += "${svcSid}:F"
      $baseGrant += "${svcSid}:(OI)(CI)F"
    }

    _AclTree -Path $DataRoot -Grant $baseGrant

    _AclTree -Path $LogsPath -Grant $baseGrant -UsersRead -AlsoGrantCurrentUser -ResetFirst

    $logFileGrants = @('BUILTIN\Users:R')
    if ($curUser) { $logFileGrants += "$curUser:R" }
    if ($curSid)  { $logFileGrants += "*$curSid:R" }

    _AclFiles -Root $LogsPath -Patterns @('*.log','*.out','*.err','*.err.log','*.out.log') -FileGrants $logFileGrants

    if (Test-Path $ConfigPath) {
      _AclTree -Path $ConfigPath -Grant $baseGrant -UsersRead:($usersReadCfg) -AlsoGrantCurrentUser -ResetFirst

      if ($svcSid) {
        Invoke-TinySocsCmd ('icacls "{0}" /grant:r "{1}:(OI)(CI)RX" /T /C >nul 2>&1' -f $ConfigPath, $svcSid)
      }

      _FixCriticalConfigFiles -Root $ConfigPath
    }

    # Runner file: file-level explicit perms
    if ($RunnerPath -and (Test-Path $RunnerPath)) {
      Invoke-TinySocsCmd ('takeown /F "{0}" /A >nul 2>&1' -f $RunnerPath)
      Invoke-TinySocsCmd ('icacls "{0}" /remove:d "Everyone" "Users" "Authenticated Users" /C >nul 2>&1' -f $RunnerPath)
      if ($curUser) { Invoke-TinySocsCmd ('icacls "{0}" /remove:d "{1}" /C >nul 2>&1' -f $RunnerPath, $curUser) }
      if ($curSid)  { Invoke-TinySocsCmd ('icacls "{0}" /remove:d "*{1}" /C >nul 2>&1' -f $RunnerPath, $curSid) }

      # IMPORTANT: keep SIDs in icacls SID form (*S-1-...) — don't TrimStart('*')
      $runnerGrant = @(
        '"SYSTEM:F"',
        '"BUILTIN\Administrators:F"',
        '"BUILTIN\Users:RX"'
      )
      if ($svcSid -and $svcSid -ne $sysSid) { $runnerGrant += ('"{0}:F"' -f $svcSid) }
      if ($curUser) { $runnerGrant += ('"{0}:RX"' -f $curUser) }
      if ($curSid)  { $runnerGrant += ('"*{0}:RX"' -f $curSid) }

      Invoke-TinySocsCmd ('icacls "{0}" /inheritance:r /grant:r {1} /C >nul 2>&1' -f $RunnerPath, ($runnerGrant -join ' '))
    }

    $doBackups = $FixBackups.IsPresent
    if (-not $PSBoundParameters.ContainsKey('FixBackups')) { $doBackups = $true }

    if ($doBackups -and (Test-Path $DataRoot)) {
      Get-ChildItem -Path $DataRoot -Directory -Force -Filter 'config.old-*' -ErrorAction SilentlyContinue |
        ForEach-Object {
          try { Set-TinySocsSecureAcl -Path $_.FullName -UsersRead } catch { }
        }
    }

    Write-TinySocsLog "OpenSearch ACLs enforced (service=$ServiceName, startName='$svcStart')."
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to enforce OpenSearch ACLs (service=$ServiceName): $($_.Exception.Message)"
  }
}

function Get-TinySocsSecretStoreDir {
  [CmdletBinding()]
  param()

  $rootVal = (Get-TinySocsDataRoot | Select-Object -First 1)
  $root    = [string]$rootVal

  $dir  = Join-Path -Path $root -ChildPath "config\secrets"
  try { New-Item -ItemType Directory -Force -Path $dir | Out-Null } catch { }
  return $dir
}

function Get-TinySocsNodeSecretDpapiFilePath {
  [CmdletBinding()]
  param()
  return (Join-Path (Get-TinySocsSecretStoreDir) "node-secret.dpapi")
}

function Read-TinySocsNodeSecretFromDpapiFile {
  [CmdletBinding()]
  param()

  $p = Get-TinySocsNodeSecretDpapiFilePath
  if (-not (Test-Path $p -PathType Leaf)) { return $null }

  try {
    $raw = (Get-Content -Path $p -Raw -ErrorAction Stop).Trim()
    if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
    $plain = Unprotect-TinySocsDpapiLocalMachine -B64 $raw
    if ([string]::IsNullOrWhiteSpace($plain)) { return $null }
    return $plain
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to read/unwrap Node secret DPAPI file ($p): $($_.Exception.Message)"
    return $null
  }
}

function Write-TinySocsNodeSecretToDpapiFile {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$Secret
  )

  $p = Get-TinySocsNodeSecretDpapiFilePath
  try {
    $wrapped = Protect-TinySocsDpapiLocalMachine -Plain $Secret
    Set-Content -Path $p -Value $wrapped -Encoding ASCII -Force
    Write-TinySocsLog "Persisted Node shared secret to DPAPI file ($p)."
    return $true
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to write Node secret DPAPI file ($p): $($_.Exception.Message)"
    return $false
  }
}

function Get-TinySocsMasterSharedSecretDpapiFilePath {
  [CmdletBinding()]
  param()
  return (Join-Path (Get-TinySocsSecretStoreDir) "master-shared-secret.dpapi")
}

function Read-TinySocsMasterSharedSecretFromDpapiFile {
  [CmdletBinding()]
  param()

  $p = Get-TinySocsMasterSharedSecretDpapiFilePath
  if (-not (Test-Path $p -PathType Leaf)) { return $null }

  try {
    $raw = (Get-Content -Path $p -Raw -ErrorAction Stop).Trim()
    if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
    $plain = Unprotect-TinySocsDpapiLocalMachine -B64 $raw
    if ([string]::IsNullOrWhiteSpace($plain)) { return $null }
    return $plain
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to read/unwrap Master secret DPAPI file ($p): $($_.Exception.Message)"
    return $null
  }
}

function Write-TinySocsMasterSharedSecretToDpapiFile {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$Secret
  )

  $p = Get-TinySocsMasterSharedSecretDpapiFilePath
  try {
    $wrapped = Protect-TinySocsDpapiLocalMachine -Plain $Secret
    Set-Content -Path $p -Value $wrapped -Encoding ASCII -Force
    Write-TinySocsLog "Persisted Master shared secret to DPAPI file ($p)."
    return $true
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to write Master secret DPAPI file ($p): $($_.Exception.Message)"
    return $false
  }
}

function Get-TinySocsNodesFilePath {
  [CmdletBinding()]
  param()

  $rootVal = (Get-TinySocsDataRoot | Select-Object -First 1)
  $root    = [string]$rootVal

  $dir  = Join-Path -Path $root -ChildPath "config"
  try { New-Item -ItemType Directory -Force -Path $dir | Out-Null } catch { }
  return (Join-Path -Path $dir -ChildPath "nodes.txt")
}

function Read-TinySocsNodesFromFile {
  [CmdletBinding()]
  param()

  $p = Get-TinySocsNodesFilePath
  if (-not (Test-Path $p -PathType Leaf)) { return $null }

  try {
    $raw = (Get-Content -Path $p -Raw -ErrorAction Stop).Trim()
    if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
    return $raw
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to read nodes file ($p): $($_.Exception.Message)"
    return $null
  }
}

function Write-TinySocsNodesToFile {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$Nodes
  )

  $p = Get-TinySocsNodesFilePath
  try {
    Set-Content -Path $p -Value $Nodes -Encoding UTF8 -Force
    Write-TinySocsLog "Persisted TINYSOCS_NODES to $p"
    return $true
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to write nodes file ($p): $($_.Exception.Message)"
    return $false
  }
}

function Test-TinySocsIsElevated {
  try {
    $typeName = 'TinySocs.TokenCheck'
    if (-not ([System.Type]::GetType($typeName, $false))) {
      Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

namespace TinySocs {
  public static class TokenCheck {
    public const UInt32 TOKEN_QUERY = 0x0008;
    public const int TokenElevation = 20;

    [DllImport("kernel32.dll")]
    public static extern IntPtr GetCurrentProcess();

    [DllImport("advapi32.dll", SetLastError=true)]
    public static extern bool OpenProcessToken(IntPtr ProcessHandle, UInt32 DesiredAccess, out IntPtr TokenHandle);

    [DllImport("advapi32.dll", SetLastError=true)]
    public static extern bool GetTokenInformation(
      IntPtr TokenHandle,
      int TokenInformationClass,
      IntPtr TokenInformation,
      int TokenInformationLength,
      out int ReturnLength
    );

    [DllImport("kernel32.dll")]
    public static extern bool CloseHandle(IntPtr hObject);
  }
}
"@ -ErrorAction SilentlyContinue | Out-Null
    }

    $tok = [IntPtr]::Zero
    $ok = [TinySocs.TokenCheck]::OpenProcessToken(
      [TinySocs.TokenCheck]::GetCurrentProcess(),
      [TinySocs.TokenCheck]::TOKEN_QUERY,
      [ref]$tok
    )
    if (-not $ok -or $tok -eq [IntPtr]::Zero) { return $false }

    $ptr = [IntPtr]::Zero
    try {
      $size = 4
      $ptr = [Runtime.InteropServices.Marshal]::AllocHGlobal($size)
      $ret = 0
      $ok2 = [TinySocs.TokenCheck]::GetTokenInformation($tok, [TinySocs.TokenCheck]::TokenElevation, $ptr, $size, [ref]$ret)
      if (-not $ok2) { return $false }

      $elevated = [Runtime.InteropServices.Marshal]::ReadInt32($ptr)
      return ($elevated -eq 1)
    }
    finally {
      if ($ptr -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::FreeHGlobal($ptr) }
      if ($tok -ne [IntPtr]::Zero) { try { [TinySocs.TokenCheck]::CloseHandle($tok) | Out-Null } catch { } }
    }
  } catch {
    return $false
  }
}

function Assert-TinySocsAdmin {
  if (-not (Test-TinySocsIsElevated)) {
    throw "TinySocs installer must be run from an elevated PowerShell (Run as Administrator)."
  }
}

function Convert-BytesToPem {
  param(
    [Parameter(Mandatory)][byte[]]$Bytes,
    [Parameter(Mandatory)][string]$Label
  )
  $b64 = [Convert]::ToBase64String($Bytes)
  $sb  = New-Object System.Text.StringBuilder
  [void]$sb.AppendLine("-----BEGIN $Label-----")
  for ($i = 0; $i -lt $b64.Length; $i += 64) {
    $len = [Math]::Min(64, $b64.Length - $i)
    [void]$sb.AppendLine($b64.Substring($i, $len))
  }
  [void]$sb.AppendLine("-----END $Label-----")
  return $sb.ToString()
}

function Export-X509CertToPemFile {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][System.Security.Cryptography.X509Certificates.X509Certificate2]$Cert,
    [Parameter(Mandatory)][string]$Path
  )
  $der = $Cert.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert)
  $pem = Convert-BytesToPem -Bytes $der -Label "CERTIFICATE"
  $dir = Split-Path -Parent $Path
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  Set-Content -Path $Path -Value $pem -Encoding ascii -Force
}

function Export-RsaPrivateKeyToPemFile {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][System.Security.Cryptography.X509Certificates.X509Certificate2]$Cert,
    [Parameter(Mandatory)][string]$Path
  )

  $rsa = $null
  try { $rsa = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($Cert) } catch { }
  if (-not $rsa -and $Cert.PrivateKey) { $rsa = $Cert.PrivateKey }

  if ($null -eq $rsa) { throw "Certificate has no RSA private key." }

  if ($rsa.PSObject.Methods.Name -notcontains 'ExportPkcs8PrivateKey') {
    throw "This PowerShell/.NET runtime cannot export PKCS#8 private keys. Use PKCS12 keystore/truststore path instead."
  }

  $pkcs8 = $rsa.ExportPkcs8PrivateKey()
  $pem = Convert-BytesToPem -Bytes $pkcs8 -Label "PRIVATE KEY"
  $dir = Split-Path -Parent $Path
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  Set-Content -Path $Path -Value $pem -Encoding ascii -Force
}

function Get-TinySocsOpenSearchTlsStorePassFilePath {
  [CmdletBinding()]
  param([Parameter(Mandatory)][string]$CertsDir)
  return (Join-Path $CertsDir "opensearch-tls-storepass.dpapi")
}

function Read-TinySocsOpenSearchTlsStorePassFromDpapiFile {
  [CmdletBinding()]
  param([Parameter(Mandatory)][string]$CertsDir)

  # Primary location (OpenSearch config tree)
  $primary = $null
  try { $primary = Get-TinySocsOpenSearchTlsStorePassFilePath -CertsDir $CertsDir } catch { $primary = $null }

  # Secondary location (global TinySocs secrets store)
  $secondary = $null
  try { $secondary = Join-Path (Get-TinySocsSecretStoreDir) "opensearch-tls-storepass.dpapi" } catch { $secondary = $null }

  $candidates = @()
  if ($primary)   { $candidates += $primary }
  if ($secondary) { $candidates += $secondary }

  foreach ($p in $candidates) {
    if (-not $p) { continue }
    if (-not (Test-Path $p -PathType Leaf)) { continue }

    try {
      $raw = (Get-Content -Path $p -Raw -ErrorAction Stop).Trim()
      if ([string]::IsNullOrWhiteSpace($raw)) { continue }

      $plain = Unprotect-TinySocsDpapiLocalMachine -B64 $raw
      if ([string]::IsNullOrWhiteSpace($plain)) { continue }

      # Backfill the other copy if missing (best-effort)
      try {
        if ($p -eq $primary -and $secondary -and -not (Test-Path $secondary -PathType Leaf)) {
          $wrapped = Protect-TinySocsDpapiLocalMachine -Plain $plain
          New-Item -ItemType Directory -Force -Path (Split-Path -Parent $secondary) | Out-Null
          Set-Content -Path $secondary -Value $wrapped -Encoding ASCII -Force
          Write-TinySocsLog "Backfilled TLS storepass DPAPI file into global secrets store ($secondary)."
        } elseif ($p -eq $secondary -and $primary -and -not (Test-Path $primary -PathType Leaf)) {
          $wrapped = Protect-TinySocsDpapiLocalMachine -Plain $plain
          New-Item -ItemType Directory -Force -Path (Split-Path -Parent $primary) | Out-Null
          Set-Content -Path $primary -Value $wrapped -Encoding ASCII -Force
          Write-TinySocsLog "Backfilled TLS storepass DPAPI file into OpenSearch certs dir ($primary)."
        }
      } catch {
        Write-TinySocsLog -Level "WARN" -Message "Recovered TLS storepass from DPAPI file ($p) but failed backfill: $($_.Exception.Message)"
      }

      return $plain
    } catch {
      Write-TinySocsLog -Level "WARN" -Message "Failed to read/unwrap TLS storepass DPAPI file ($p): $($_.Exception.Message)"
    }
  }

  return $null
}

function Write-TinySocsOpenSearchTlsStorePassToDpapiFile {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$CertsDir,
    [Parameter(Mandatory)][string]$StorePass
  )

  $okAny = $false
  $wrapped = $null

  try { $wrapped = Protect-TinySocsDpapiLocalMachine -Plain $StorePass }
  catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to DPAPI-wrap TLS store password: $($_.Exception.Message)"
    return $false
  }

  # Primary (OpenSearch certs dir)
  $p1 = $null
  try { $p1 = Get-TinySocsOpenSearchTlsStorePassFilePath -CertsDir $CertsDir } catch { $p1 = $null }

  # Secondary (global secrets store)
  $p2 = $null
  try { $p2 = Join-Path (Get-TinySocsSecretStoreDir) "opensearch-tls-storepass.dpapi" } catch { $p2 = $null }

  foreach ($p in @($p1,$p2) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }) {
    try {
      $dir = Split-Path -Parent $p
      if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }

      Set-Content -Path $p -Value $wrapped -Encoding ASCII -Force
      $okAny = $true
      Write-TinySocsLog "Persisted OpenSearch TLS store password to DPAPI file ($p)."
    } catch {
      Write-TinySocsLog -Level "WARN" -Message "Failed to write TLS storepass DPAPI file ($p): $($_.Exception.Message)"
    }
  }

  return $okAny
}

function Ensure-TinySocsLocalCaAndServerCert {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$CertsDir
  )

  $caSubject     = "CN=TinySocs-OpenSearch-CA"
  $serverSubject = "CN=TinySocs-OpenSearch"
  $adminSubject  = "CN=TinySocs-OpenSearch-Admin"

  # Ensure certs dir exists early so we can persist/restore passwords even if CredMan gets wiped.
  New-Item -ItemType Directory -Force -Path $CertsDir | Out-Null

  $tlsTarget = 'TinySocs/OpenSearch/Tls'
  $tlsPass   = $null

  # 1) Prefer CredMan
  try {
    $existing = Get-TSCredential -Name $tlsTarget
    if ($existing) {
      $j = $existing | ConvertFrom-Json
      if ($j.pass) { $tlsPass = [string]$j.pass }
    }
  } catch { }

  # 2) If missing, try DPAPI file and backfill CredMan
  if ([string]::IsNullOrWhiteSpace($tlsPass)) {
    try {
      $tlsPass = Read-TinySocsOpenSearchTlsStorePassFromDpapiFile -CertsDir $CertsDir
      if (-not [string]::IsNullOrWhiteSpace($tlsPass)) {
        try {
          $payload = @{ pass = $tlsPass } | ConvertTo-Json -Compress
          Set-TSCredential -Name $tlsTarget -Secret $payload
          Write-TinySocsLog "Restored OpenSearch TLS store password from DPAPI file and backfilled CredMan ($tlsTarget)."
        } catch {
          Write-TinySocsLog -Level "WARN" -Message "Recovered TLS store password from DPAPI file, but failed to backfill CredMan: $($_.Exception.Message)"
        }
      }
    } catch { }
  }

  # 3) If still missing, generate new and store BOTH
  if ([string]::IsNullOrWhiteSpace($tlsPass)) {
    $tlsPass = New-TinySocsPassword -Length 32

    try {
      $payload = @{ pass = $tlsPass } | ConvertTo-Json -Compress
      Set-TSCredential -Name $tlsTarget -Secret $payload
      Write-TinySocsLog "Generated and stored stable OpenSearch TLS store password in CredMan ($tlsTarget)."
    } catch {
      Write-TinySocsLog -Level "WARN" -Message "Failed to store TLS password in CredMan ($tlsTarget): $($_.Exception.Message)"
    }

    try { $null = Write-TinySocsOpenSearchTlsStorePassToDpapiFile -CertsDir $CertsDir -StorePass $tlsPass } catch { }
  } else {
    Write-TinySocsLog "Reusing stable OpenSearch TLS store password (CredMan/DPAPI)."
    # Ensure the DPAPI file exists even if we got the password from CredMan
    try {
      $p = Get-TinySocsOpenSearchTlsStorePassFilePath -CertsDir $CertsDir
      if (-not (Test-Path $p -PathType Leaf)) {
        $null = Write-TinySocsOpenSearchTlsStorePassToDpapiFile -CertsDir $CertsDir -StorePass $tlsPass
      }
    } catch { }
  }

  # ---- CA ----
  $caCert = Get-ChildItem -Path Cert:\LocalMachine\My -ErrorAction SilentlyContinue |
    Where-Object { $_.Subject -eq $caSubject } |
    Sort-Object NotAfter -Descending |
    Select-Object -First 1

  if (-not $caCert) {
    Write-TinySocsLog "Generating local TinySocs CA certificate ($caSubject)."
    $caCert = New-SelfSignedCertificate `
      -Subject $caSubject `
      -CertStoreLocation "Cert:\LocalMachine\My" `
      -KeyExportPolicy Exportable `
      -KeyAlgorithm RSA -KeyLength 4096 -HashAlgorithm SHA256 `
      -NotAfter (Get-Date).AddYears(10) `
      -KeyUsage CertSign,CRLSign,DigitalSignature `
      -TextExtension @("2.5.29.19={critical}{text}ca=true")
  } else {
    Write-TinySocsLog "Found existing TinySocs CA in LocalMachine\My (thumbprint=$($caCert.Thumbprint))."
  }

  # Trust the CA in LocalMachine\Root
  try {
    $root = New-Object System.Security.Cryptography.X509Certificates.X509Store("Root","LocalMachine")
    $root.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)
    $present = $false
    foreach ($c in $root.Certificates) {
      if ($c.Thumbprint -eq $caCert.Thumbprint) { $present = $true; break }
    }
    if (-not $present) {
      $root.Add($caCert)
      Write-TinySocsLog "Imported TinySocs CA into LocalMachine\Root (trust store)."
    } else {
      Write-TinySocsLog "TinySocs CA already present in LocalMachine\Root."
    }
    $root.Close()
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to import CA into Root store: $($_.Exception.Message)"
  }

  # ---- Server cert ----
  $serverCert = Get-ChildItem -Path Cert:\LocalMachine\My -ErrorAction SilentlyContinue |
    Where-Object { $_.Subject -eq $serverSubject } |
    Sort-Object NotAfter -Descending |
    Select-Object -First 1

  if (-not $serverCert) {
    Write-TinySocsLog "Generating OpenSearch server certificate signed by TinySocs CA ($serverSubject)."
    $serverCert = New-SelfSignedCertificate `
      -Subject $serverSubject `
      -CertStoreLocation "Cert:\LocalMachine\My" `
      -KeyExportPolicy Exportable `
      -KeyAlgorithm RSA -KeyLength 2048 -HashAlgorithm SHA256 `
      -NotAfter (Get-Date).AddYears(5) `
      -KeyUsage DigitalSignature,KeyEncipherment `
      -Signer $caCert `
      -TextExtension @(
        "2.5.29.19={critical}{text}ca=false",
        "2.5.29.17={text}DNS=localhost&IP=127.0.0.1"
      )
  } else {
    Write-TinySocsLog "Found existing OpenSearch server cert in LocalMachine\My (thumbprint=$($serverCert.Thumbprint))."
  }

  # ---- Admin client cert (for securityadmin) ----
  $adminCert = Get-ChildItem -Path Cert:\LocalMachine\My -ErrorAction SilentlyContinue |
    Where-Object { $_.Subject -eq $adminSubject } |
    Sort-Object NotAfter -Descending |
    Select-Object -First 1

  if (-not $adminCert) {
    Write-TinySocsLog "Generating OpenSearch admin client certificate signed by TinySocs CA ($adminSubject)."
    $adminCert = New-SelfSignedCertificate `
      -Subject $adminSubject `
      -CertStoreLocation "Cert:\LocalMachine\My" `
      -KeyExportPolicy Exportable `
      -KeyAlgorithm RSA -KeyLength 2048 -HashAlgorithm SHA256 `
      -NotAfter (Get-Date).AddYears(5) `
      -KeyUsage DigitalSignature,KeyEncipherment `
      -Signer $caCert `
      -TextExtension @(
        "2.5.29.19={critical}{text}ca=false",
        "2.5.29.37={text}1.3.6.1.5.5.7.3.2" # Client Auth EKU
      )
  } else {
    Write-TinySocsLog "Found existing OpenSearch admin cert in LocalMachine\My (thumbprint=$($adminCert.Thumbprint))."
  }

  $httpP12  = Join-Path $CertsDir "http.p12"
  $transP12 = Join-Path $CertsDir "transport.p12"
  $trustP12 = Join-Path $CertsDir "trust.p12"
  $caCer    = Join-Path $CertsDir "ca.cer"

  $secPass = ConvertTo-SecureString -String $tlsPass -AsPlainText -Force
  try {
    Export-PfxCertificate -Cert $serverCert -FilePath $httpP12 -Password $secPass -Force | Out-Null
    Copy-Item -Force $httpP12 $transP12
    Write-TinySocsLog "Exported OpenSearch TLS keystore PKCS12 (http+transport) to $CertsDir."
  } catch {
    throw "Failed to export server cert to PKCS12 ($httpP12): $($_.Exception.Message)"
  }

  try { Export-Certificate -Cert $caCert -FilePath $caCer -Force | Out-Null }
  catch { throw "Failed to export CA certificate to ${caCer}: $($_.Exception.Message)" }

  $installRoot    = Get-TinySocsInstallRoot
  $openSearchRoot = Join-Path $installRoot "OpenSearch"
  $keytool        = Join-Path $openSearchRoot "jdk\bin\keytool.exe"
  if (-not (Test-Path $keytool -PathType Leaf)) {
    throw "keytool.exe not found at '$keytool' (bundled JDK missing)."
  }

  try {
    if (Test-Path $trustP12) { Remove-Item -Force $trustP12 -ErrorAction SilentlyContinue }

    & $keytool -importcert -noprompt `
      -alias tinysocs-ca `
      -file "$caCer" `
      -keystore "$trustP12" `
      -storetype PKCS12 `
      -storepass "$tlsPass" | Out-Null

    Write-TinySocsLog "Created OpenSearch TLS truststore PKCS12 at $trustP12 (alias=tinysocs-ca)."
  } catch {
    throw "Failed to create truststore via keytool: $($_.Exception.Message)"
  }

  return @{
    HttpKeystoreP12      = $httpP12
    TransportKeystoreP12 = $transP12
    TruststoreP12        = $trustP12
    StorePassword        = $tlsPass
    CaCerPath            = $caCer
  }
}

function Write-TinySocsOpenSearchConfig {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$ConfigPath,
    [Parameter(Mandatory)][string]$ClusterName,
    [Parameter(Mandatory)][string]$NodeName,
    [Parameter(Mandatory)][int]$HttpPort,
    [Parameter(Mandatory)][string]$DataPath,
    [Parameter(Mandatory)][string]$LogsPath,
    [switch]$Force
  )

  $configDir = Split-Path -Parent $ConfigPath
  if (-not (Test-Path $configDir)) { New-Item -ItemType Directory -Force -Path $configDir | Out-Null }

  Ensure-TinySocsWritableFile -Path $ConfigPath

  $dataPathNormalized = $DataPath.Replace('\','/')
  $logsPathNormalized = $LogsPath.Replace('\','/')

  if (-not (Test-Path $ConfigPath -PathType Leaf)) {
    "# TinySocs-generated opensearch.yml`r`n" | Out-File -FilePath $ConfigPath -Encoding UTF8 -Force
  }

  # Read as RAW and split -> ALWAYS produces string[]
  $rawText = ""
  try { $rawText = Get-Content -Path $ConfigPath -Raw -ErrorAction Stop } catch { $rawText = "" }

  # Normalize line endings and split
  $lines = @()
  if (-not [string]::IsNullOrEmpty($rawText)) {
    $rawText = $rawText -replace "`r`n", "`n"
    $rawText = $rawText -replace "`r", "`n"
    $lines   = @($rawText -split "`n", 0, "SimpleMatch")
  } else {
    $lines = @()
  }

  # Ensure we never accidentally hold chars
  $lines = @($lines | ForEach-Object { [string]$_ })

  function _SetYamlKey {
    param(
      [Parameter(Mandatory)][string]$Key,
      [Parameter(Mandatory)][string]$Value
    )

    $kEsc = [Regex]::Escape($Key)
    $re   = '^\s*' + $kEsc + '\s*:\s*.*$'

    $idx = -1
    for ($i = 0; $i -lt $lines.Count; $i++) {
      if ([string]$lines[$i] -match $re) { $idx = $i; break }
    }

    $newline = "{0}: {1}" -f $Key, $Value

    if ($idx -ge 0) {
      $lines[$idx] = $newline
    } else {
      if ($lines.Count -gt 0 -and -not [string]::IsNullOrWhiteSpace([string]$lines[$lines.Count-1])) {
        $lines += ''
      }
      $lines += $newline
    }
  }

  _SetYamlKey -Key 'cluster.name'   -Value $ClusterName
  _SetYamlKey -Key 'node.name'      -Value $NodeName
  _SetYamlKey -Key 'network.host'   -Value '127.0.0.1'
  _SetYamlKey -Key 'http.port'      -Value ([string]$HttpPort)
  _SetYamlKey -Key 'discovery.type' -Value 'single-node'
  _SetYamlKey -Key 'path.data'      -Value $dataPathNormalized
  _SetYamlKey -Key 'path.logs'      -Value $logsPathNormalized

  Ensure-TinySocsWritableFile -Path $ConfigPath
  ($lines -join "`r`n") + "`r`n" | Out-File -FilePath $ConfigPath -Encoding UTF8 -Force

  Write-TinySocsLog "OpenSearch config ensured/merged at $ConfigPath"
}

function Ensure-TinySocsOpenSearchSecuritySettings {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$ConfigPath,
    [Parameter(Mandatory)][hashtable]$TlsPaths,
    [bool]$AllowDefaultInitSecurityIndex = $true,

    # Optional: if present, we will prefer recovering the PKCS12 storepass from DPAPI so upgrades are self-healing.
    # Expected content: either raw DPAPI-protected bytes OR base64 text of those bytes.
    [string]$StorePassDpapiPath
  )

  Ensure-TinySocsWritableFile -Path $ConfigPath
  if ($null -eq $TlsPaths) { throw "Ensure-TinySocsOpenSearchSecuritySettings: TlsPaths was null." }

  foreach ($k in @('HttpKeystoreP12','TransportKeystoreP12','TruststoreP12')) {
    if (-not $TlsPaths.ContainsKey($k) -or [string]::IsNullOrWhiteSpace([string]$TlsPaths[$k])) {
      throw "Ensure-TinySocsOpenSearchSecuritySettings: TlsPaths missing required key '$k'."
    }
  }

  foreach ($p in @($TlsPaths.HttpKeystoreP12, $TlsPaths.TransportKeystoreP12, $TlsPaths.TruststoreP12)) {
    if (-not (Test-Path $p -PathType Leaf)) {
      throw "Ensure-TinySocsOpenSearchSecuritySettings: TLS file missing on disk: $p"
    }
  }

  if (-not (Test-Path $ConfigPath -PathType Leaf)) {
    throw "Ensure-TinySocsOpenSearchSecuritySettings: ConfigPath not found: $ConfigPath"
  }

  $configDir = Split-Path -Parent $ConfigPath
  if ([string]::IsNullOrWhiteSpace($StorePassDpapiPath)) {
    $StorePassDpapiPath = Join-Path $configDir "certs\opensearch-tls-storepass.dpapi"
  }

  function _Ensure-TinySocsReadable {
    param(
      [Parameter(Mandatory)][string]$Path,
      [switch]$IsDir
    )
    if (-not (Test-Path $Path)) { return }

    $ic = Join-Path $env:WINDIR "System32\icacls.exe"
    if (-not (Test-Path $ic -PathType Leaf)) { return }

    try {
      if ($IsDir) {
        & $ic $Path /inheritance:e 1>$null 2>$null
        & $ic $Path /grant "SYSTEM:(OI)(CI)RX" "Administrators:(OI)(CI)RX" 1>$null 2>$null
      } else {
        & $ic $Path /inheritance:e 1>$null 2>$null
        & $ic $Path /grant "SYSTEM:R" "Administrators:R" 1>$null 2>$null
      }
    } catch { }
  }

  function _YamlSingleQuote {
    param([Parameter(Mandatory)][AllowEmptyString()][string]$s)
    return ("'" + ($s -replace "'","''") + "'")
  }

  function _ToYamlRelPathIfUnderConf {
    param(
      [Parameter(Mandatory)][string]$AbsPath,
      [Parameter(Mandatory)][string]$ConfDir
    )
    try {
      $confFull = [System.IO.Path]::GetFullPath($ConfDir.TrimEnd('\'))
      $pFull    = [System.IO.Path]::GetFullPath($AbsPath)
      if ($pFull.StartsWith($confFull, [System.StringComparison]::OrdinalIgnoreCase)) {
        $rel = $pFull.Substring($confFull.Length).TrimStart('\')
        return ($rel -replace '\\','/')
      }
    } catch { }
    return ([string]$AbsPath).Replace('\','/')
  }

  function _Write-TinySocsDpapiStorePass {
    param(
      [Parameter(Mandatory)][string]$Path,
      [Parameter(Mandatory)][string]$Password
    )

    try {
      Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue | Out-Null
      $plain = [Text.Encoding]::UTF8.GetBytes($Password)
      $prot  = [System.Security.Cryptography.ProtectedData]::Protect(
        $plain, $null, [System.Security.Cryptography.DataProtectionScope]::LocalMachine
      )

      $dir = Split-Path -Parent $Path
      if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }

      [System.IO.File]::WriteAllBytes($Path, $prot) | Out-Null
      _Ensure-TinySocsReadable -Path $Path
    } catch {
      Write-TinySocsLog "WARN: Failed to write DPAPI storepass file '$Path': $($_.Exception.Message)"
    }
  }

  function _TryUnprotect-TinySocsDpapiFile {
    param([Parameter(Mandatory)][string]$Path)

    if (-not (Test-Path $Path -PathType Leaf)) { return $null }

    Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue | Out-Null
    _Ensure-TinySocsReadable -Path $Path

    $tryUnprotect = {
      param([byte[]]$b)
      if (-not $b -or $b.Length -lt 1) { return $null }

      $clear = $null
      try { $clear = [System.Security.Cryptography.ProtectedData]::Unprotect($b, $null, [System.Security.Cryptography.DataProtectionScope]::LocalMachine) } catch { }
      if (-not $clear) {
        try { $clear = [System.Security.Cryptography.ProtectedData]::Unprotect($b, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser) } catch { }
      }
      if (-not $clear) { return $null }

      $s = $null
      try { $s = [Text.Encoding]::UTF8.GetString($clear).Trim([char]0).Trim() } catch { }
      if ([string]::IsNullOrWhiteSpace($s)) {
        try { $s = [Text.Encoding]::Unicode.GetString($clear).Trim([char]0).Trim() } catch { }
      }
      if ([string]::IsNullOrWhiteSpace($s)) { return $null }
      return $s
    }

    $bytesRaw = $null
    try { $bytesRaw = [System.IO.File]::ReadAllBytes($Path) } catch { $bytesRaw = $null }

    $s1 = & $tryUnprotect $bytesRaw
    if (-not [string]::IsNullOrWhiteSpace($s1)) { return $s1 }

    $raw = $null
    try { $raw = (Get-Content -Path $Path -Raw -ErrorAction Stop).Trim() } catch { $raw = $null }

    if (-not [string]::IsNullOrWhiteSpace($raw)) {
      $raw2 = ($raw -replace '\s+','')
      if (($raw2.Length % 4 -eq 0) -and ($raw2 -match '^[A-Za-z0-9+/=]+$')) {
        try {
          $bytesB64 = [Convert]::FromBase64String($raw2)
          $s2 = & $tryUnprotect $bytesB64
          if (-not [string]::IsNullOrWhiteSpace($s2)) { return $s2 }
        } catch { }
      }
    }

    return $null
  }

  function Ensure-OpenSearchYamlCanonical {
  [CmdletBinding()]
  param(
    [string]$YamlPath = "$env:ProgramData\TinySocs\OpenSearch\config\opensearch.yml"
  )

  if (-not (Test-Path -LiteralPath $YamlPath)) {
    return
  }

  $begin = '# --- BEGIN TinySocs security/TLS (minimal) ---'
  $end   = '# --- END TinySocs security/TLS (minimal) ---'

  # Keys we "own" and must never appear twice anywhere in the file
  $ownedKeyRegexes = @(
    '^\s*(?!#)\s*plugins\.security\.ssl\.http\.enabled\s*:',
    '^\s*(?!#)\s*plugins\.security\.ssl\.transport\.enabled\s*:',
    '^\s*(?!#)\s*plugins\.security\.ssl\.transport\.enforce_hostname_verification\s*:',
    '^\s*(?!#)\s*plugins\.security\.allow_default_init_securityindex\s*:'
  )

  $block = @(
    $begin
    'plugins.security.ssl.http.enabled: true'
    'plugins.security.ssl.transport.enabled: true'
    'plugins.security.ssl.transport.enforce_hostname_verification: false'
    'plugins.security.allow_default_init_securityindex: true'
    $end
  )

  $lines = Get-Content -LiteralPath $YamlPath -ErrorAction Stop

  # 1) Remove any existing TinySocs-managed block (robust even if truncated)
  $stripped = New-Object System.Collections.Generic.List[string]
  $inBlock = $false
  foreach ($l in $lines) {
    if ($l -eq $begin) { $inBlock = $true; continue }
    if ($inBlock) {
      if ($l -eq $end) { $inBlock = $false }
      continue
    }
    $stripped.Add($l)
  }

  # 2) Remove any occurrences of owned keys elsewhere (prevents duplicates across reinstalls)
  $clean = New-Object System.Collections.Generic.List[string]
  foreach ($l in $stripped) {
    $isOwnedKey = $false
    foreach ($rx in $ownedKeyRegexes) {
      if ($l -match $rx) { $isOwnedKey = $true; break }
    }
    if (-not $isOwnedKey) { $clean.Add($l) }
  }

  # 3) Insert a single canonical block.
  # Prefer to place it right after discovery.type if present, else append at end.
  $insertAt = -1
  for ($i = 0; $i -lt $clean.Count; $i++) {
    if ($clean[$i] -match '^\s*discovery\.type\s*:') { $insertAt = $i + 1; break }
  }

  if ($insertAt -ge 0) {
    # Ensure a blank line before/after for readability
    $toInsert = @()
    if ($insertAt -gt 0 -and ($clean[$insertAt - 1].Trim() -ne '')) { $toInsert += '' }
    $toInsert += $block
    $toInsert += ''

    $clean.InsertRange($insertAt, $toInsert)
  } else {
    if ($clean.Count -gt 0 -and ($clean[$clean.Count - 1].Trim() -ne '')) { $clean.Add('') }
    $block | ForEach-Object { $clean.Add($_) }
    $clean.Add('')
  }

  Set-Content -LiteralPath $YamlPath -Value $clean -Encoding UTF8
}

  function _TryGet-TinySocsYamlScalar {
    param(
      [Parameter(Mandatory)][string]$Path,
      [Parameter(Mandatory)][string]$Key
    )
    if (-not (Test-Path $Path -PathType Leaf)) { return $null }
    try {
      $raw = Get-Content -Path $Path -Raw -ErrorAction Stop
      if ($null -eq $raw) { return $null }
      $m = [regex]::Match($raw, "(?im)^\s*"+[regex]::Escape($Key)+"\s*:\s*(.+?)\s*$")
      if (-not $m.Success) { return $null }
      $v = $m.Groups[1].Value.Trim()
      if ($v.StartsWith("#")) { return $null }
      # strip simple single/double quotes
      if (($v.StartsWith("'") -and $v.EndsWith("'")) -or ($v.StartsWith('"') -and $v.EndsWith('"'))) {
        $v = $v.Substring(1, $v.Length-2)
      }
      return $v.Trim()
    } catch {
      return $null
    }
  }

  function _Invoke-TinySocsKeytoolList {
    param(
      [Parameter(Mandatory)][string]$KeytoolPath,
      [Parameter(Mandatory)][string]$KeystorePath,
      [Parameter(Mandatory)][string]$Password
    )

    $res = [pscustomobject]@{
      Ok      = $false
      Exit    = $null
      Error   = $null
      Path    = $KeystorePath
      Keytool = $KeytoolPath
    }

    if (-not (Test-Path $KeytoolPath -PathType Leaf)) {
      $res.Ok = $true
      $res.Exit = 0
      $res.Error = "keytool_missing"
      return $res
    }

    if (-not (Test-Path $KeystorePath -PathType Leaf)) {
      $res.Ok = $false
      $res.Exit = 2
      $res.Error = "keystore_missing"
      return $res
    }

    _Ensure-TinySocsReadable -Path $KeystorePath

    try {
      # Capture BOTH stdout + stderr so we can classify properly.
      $out = & $KeytoolPath @('-list','-storetype','PKCS12','-keystore',$KeystorePath,'-storepass',$Password) 2>&1
      $res.Exit = $LASTEXITCODE
      $res.Error = (($out | Out-String).Trim())
      $res.Ok = ($res.Exit -eq 0)
      return $res
    } catch {
      $res.Exit = 1
      $res.Error = ("keytool_exec_failed: " + $_.Exception.Message)
      $res.Ok = $false
      return $res
    }
  }

  function _Classify-TinySocsPkcs12Failure {
    param([Parameter(Mandatory)]$KeytoolResult)

    if ($KeytoolResult.Ok) { return $null }

    if ($KeytoolResult.Error -eq "keytool_missing") { return "KEYTOOL_MISSING" }
    if ($KeytoolResult.Error -eq "keystore_missing") { return "KEYSTORE_MISSING" }

    $e = [string]$KeytoolResult.Error

    if ($e -match '(?i)Keystore file does not exist') { return "CANNOT_READ_OR_PATH" }
    if ($e -match '(?i)Access is denied')            { return "ACCESS_DENIED" }

    # Common wrong-password indicators across JDKs / keytool variants
    if ($e -match '(?i)keystore password was incorrect' -or
        $e -match '(?i)password was incorrect' -or
        $e -match '(?i)UnrecoverableKeyException' -or
        $e -match '(?i)tampered with' -or
        $e -match '(?i)BadPaddingException') {
      return "BAD_PASSWORD"
    }

    return "KEYTOOL_FAILED"
  }

  # Self-heal readability for common OpenSearch config files we’ve seen shipped with empty DACLs.
  _Ensure-TinySocsReadable -Path $configDir -IsDir
  foreach ($p in @(
    (Join-Path $configDir "jvm.options"),
    (Join-Path $configDir "opensearch.keystore"),
    (Join-Path $configDir "log4j2.properties"),
    $ConfigPath,
    $TlsPaths.HttpKeystoreP12,
    $TlsPaths.TransportKeystoreP12,
    $TlsPaths.TruststoreP12,
    $StorePassDpapiPath
  )) {
    _Ensure-TinySocsReadable -Path $p
  }

  # Prefer DPAPI storepass so upgrades are self-healing.
  $pw = $null
  $pwSource = "TlsPaths.StorePassword"

  $dpPw = $null
  if (-not [string]::IsNullOrWhiteSpace($StorePassDpapiPath)) {
    $dpPw = _TryUnprotect-TinySocsDpapiFile -Path $StorePassDpapiPath
  }

  if (-not [string]::IsNullOrWhiteSpace($dpPw)) {
    $pw = [string]$dpPw
    $pwSource = "DPAPI:$StorePassDpapiPath"
  } elseif ($TlsPaths.ContainsKey('StorePassword') -and -not [string]::IsNullOrWhiteSpace([string]$TlsPaths.StorePassword)) {
    $pw = [string]$TlsPaths.StorePassword
  } else {
    # Fallback: try to recover from existing YAML (useful when DPAPI got lost but YAML is still correct)
    $pwYaml = _TryGet-TinySocsYamlScalar -Path $ConfigPath -Key "plugins.security.ssl.transport.keystore_password"
    if ([string]::IsNullOrWhiteSpace($pwYaml)) {
      $pwYaml = _TryGet-TinySocsYamlScalar -Path $ConfigPath -Key "plugins.security.ssl.http.keystore_password"
    }
    if (-not [string]::IsNullOrWhiteSpace($pwYaml)) {
      $pw = [string]$pwYaml
      $pwSource = "YAML:$ConfigPath"
    } else {
      throw "Ensure-TinySocsOpenSearchSecuritySettings: No PKCS12 store password available. Expected DPAPI file at '$StorePassDpapiPath' or TlsPaths.StorePassword."
    }
  }

  # Validate password against keystores if keytool is available
  $ktDefault = Join-Path $env:ProgramFiles "TinySocs\OpenSearch\jdk\bin\keytool.exe"

  $rHttp  = _Invoke-TinySocsKeytoolList -KeytoolPath $ktDefault -KeystorePath $TlsPaths.HttpKeystoreP12      -Password $pw
  $rTrans = _Invoke-TinySocsKeytoolList -KeytoolPath $ktDefault -KeystorePath $TlsPaths.TransportKeystoreP12 -Password $pw
  $rTrust = _Invoke-TinySocsKeytoolList -KeytoolPath $ktDefault -KeystorePath $TlsPaths.TruststoreP12        -Password $pw

  $failHttp  = _Classify-TinySocsPkcs12Failure -KeytoolResult $rHttp
  $failTrans = _Classify-TinySocsPkcs12Failure -KeytoolResult $rTrans
  $failTrust = _Classify-TinySocsPkcs12Failure -KeytoolResult $rTrust

  $allOk = ($rHttp.Ok -and $rTrans.Ok -and $rTrust.Ok)

  if (-not $allOk) {
    # If we used DPAPI and it didn't work, fall back to TlsPaths.StorePassword (if present).
    if ($pwSource -like "DPAPI:*" -and $TlsPaths.ContainsKey('StorePassword') -and -not [string]::IsNullOrWhiteSpace([string]$TlsPaths.StorePassword)) {
      $pw2 = [string]$TlsPaths.StorePassword

      $rHttp2  = _Invoke-TinySocsKeytoolList -KeytoolPath $ktDefault -KeystorePath $TlsPaths.HttpKeystoreP12      -Password $pw2
      $rTrans2 = _Invoke-TinySocsKeytoolList -KeytoolPath $ktDefault -KeystorePath $TlsPaths.TransportKeystoreP12 -Password $pw2
      $rTrust2 = _Invoke-TinySocsKeytoolList -KeytoolPath $ktDefault -KeystorePath $TlsPaths.TruststoreP12        -Password $pw2

      if ($rHttp2.Ok -and $rTrans2.Ok -and $rTrust2.Ok) {
        $pw = $pw2
        $pwSource = "TlsPaths.StorePassword (fallback)"
        $rHttp = $rHttp2; $rTrans = $rTrans2; $rTrust = $rTrust2
        $failHttp = $null; $failTrans = $null; $failTrust = $null
        $allOk = $true

        if (-not [string]::IsNullOrWhiteSpace($StorePassDpapiPath)) {
          _Write-TinySocsDpapiStorePass -Path $StorePassDpapiPath -Password $pw
        }
      }
    }

    if (-not $allOk) {
      $details = @()
      if (-not $rHttp.Ok)  { $details += "http.p12: $failHttp" }
      if (-not $rTrans.Ok) { $details += "transport.p12: $failTrans" }
      if (-not $rTrust.Ok) { $details += "trust.p12: $failTrust" }
      $detailText = ($details -join "; ")

      # Special: only transport fails with BAD_PASSWORD => cert bundle mismatch
      $onlyTransportBad = ($rHttp.Ok -and -not $rTrans.Ok -and $rTrust.Ok -and $failTrans -eq "BAD_PASSWORD")
      if ($onlyTransportBad) {
        throw "Ensure-TinySocsOpenSearchSecuritySettings: transport.p12 does not accept the same password as http/trust (source=$pwSource). This usually means the cert bundle was generated/copied with mismatched passwords. Regenerate/redeploy http.p12/transport.p12/trust.p12 + DPAPI storepass as a single coherent unit. Details: $detailText"
      }

      if ($detailText -match 'CANNOT_READ_OR_PATH|ACCESS_DENIED|KEYSTORE_MISSING') {
        throw "Ensure-TinySocsOpenSearchSecuritySettings: PKCS12 validation failed because keystore(s) could not be read (source=$pwSource). Likely ACL/permission issue or path mismatch. Details: $detailText"
      }

      if ($detailText -match 'BAD_PASSWORD') {
        throw "Ensure-TinySocsOpenSearchSecuritySettings: PKCS12 password appears incorrect (source=$pwSource). Details: $detailText"
      }

      throw "Ensure-TinySocsOpenSearchSecuritySettings: PKCS12 validation failed (source=$pwSource). Details: $detailText"
    }
  }

  # Prefer relative paths under OPENSEARCH_PATH_CONF when possible
  $httpKs  = _ToYamlRelPathIfUnderConf -AbsPath ([string]$TlsPaths.HttpKeystoreP12)       -ConfDir $configDir
  $transKs = _ToYamlRelPathIfUnderConf -AbsPath ([string]$TlsPaths.TransportKeystoreP12) -ConfDir $configDir
  $ts      = _ToYamlRelPathIfUnderConf -AbsPath ([string]$TlsPaths.TruststoreP12)        -ConfDir $configDir

  $pwOut   = _YamlSingleQuote -s ([string]$pw)

  $adminDn = 'CN=TinySocs-OpenSearch-Admin'
  $nodeDn  = 'CN=TinySocs-OpenSearch'

  $ownedKeys = @(
    'plugins.security.disabled',

    'plugins.security.ssl.http.enabled',
    'plugins.security.ssl.http.keystore_type',
    'plugins.security.ssl.http.keystore_filepath',
    'plugins.security.ssl.http.keystore_password',
    'plugins.security.ssl.http.keystore_keypassword',
    'plugins.security.ssl.http.truststore_type',
    'plugins.security.ssl.http.truststore_filepath',
    'plugins.security.ssl.http.truststore_password',
    'plugins.security.ssl.http.clientauth_mode',

    'plugins.security.ssl.transport.keystore_type',
    'plugins.security.ssl.transport.keystore_filepath',
    'plugins.security.ssl.transport.keystore_password',
    'plugins.security.ssl.transport.keystore_keypassword',
    'plugins.security.ssl.transport.truststore_type',
    'plugins.security.ssl.transport.truststore_filepath',
    'plugins.security.ssl.transport.truststore_password',
    'plugins.security.ssl.transport.enforce_hostname_verification',

    'plugins.security.allow_unsafe_democertificates',
    'plugins.security.allow_default_init_securityindex',

    'plugins.security.restapi.roles_enabled',
    'plugins.security.unsupported.restapi.allow_securityconfig_modification',

    'plugins.security.authcz.admin_dn',
    'plugins.security.nodes_dn'
  )

  $lines = Get-Content -Path $ConfigPath -ErrorAction Stop
  if ($null -eq $lines) { $lines = @() }

  $beginMarker = '# --- BEGIN TinySocs security/TLS ---'
  $endMarker   = '# --- END TinySocs security/TLS ---'

  $newLines = New-Object System.Collections.Generic.List[string]
  $inBlock = $false
  foreach ($ln in $lines) {
    if ($ln -eq $beginMarker) { $inBlock = $true; continue }
    if ($ln -eq $endMarker)   { $inBlock = $false; continue }
    if (-not $inBlock) { [void]$newLines.Add($ln) }
  }

  $filtered = New-Object System.Collections.Generic.List[string]
  $skipYamlList = $false

  foreach ($ln in $newLines) {
    if ($skipYamlList) {
      if ($ln -match '^\s*$') { continue }
      if ($ln -match '^\s+#') { continue }
      if ($ln -match '^\s+-\s+') { continue }

      if ($ln -match '^\S') {
        $skipYamlList = $false
      } else {
        continue
      }
    }

    $trim = $ln.TrimStart()

    if ($trim.StartsWith('#')) { [void]$filtered.Add($ln); continue }

    if ($trim -match '^plugins\.security\.(authcz\.admin_dn|nodes_dn|restapi\.roles_enabled)\s*:') {
      $skipYamlList = $true
      continue
    }

    $isOwned = $false
    foreach ($k in $ownedKeys) {
      if ($trim -match ('^' + [Regex]::Escape($k) + '\s*:')) { $isOwned = $true; break }
    }
    if (-not $isOwned) { [void]$filtered.Add($ln) }
  }

  if ($filtered.Count -gt 0 -and $filtered[$filtered.Count-1].Trim() -ne '') { [void]$filtered.Add('') }

  [void]$filtered.Add($beginMarker)

  [void]$filtered.Add("plugins.security.disabled: false")

  [void]$filtered.Add("plugins.security.authcz.admin_dn:")
  [void]$filtered.Add("  - `"$adminDn`"")
  [void]$filtered.Add("plugins.security.nodes_dn:")
  [void]$filtered.Add("  - `"$nodeDn`"")

  [void]$filtered.Add("plugins.security.restapi.roles_enabled:")
  [void]$filtered.Add("  - `"all_access`"")
  [void]$filtered.Add("  - `"security_rest_api_access`"")
  [void]$filtered.Add("plugins.security.unsupported.restapi.allow_securityconfig_modification: true")

  [void]$filtered.Add("plugins.security.ssl.http.enabled: true")
  [void]$filtered.Add("plugins.security.ssl.http.keystore_type: PKCS12")
  [void]$filtered.Add("plugins.security.ssl.http.keystore_filepath: $httpKs")
  [void]$filtered.Add("plugins.security.ssl.http.keystore_password: $pwOut")
  [void]$filtered.Add("plugins.security.ssl.http.keystore_keypassword: $pwOut")
  [void]$filtered.Add("plugins.security.ssl.http.truststore_type: PKCS12")
  [void]$filtered.Add("plugins.security.ssl.http.truststore_filepath: $ts")
  [void]$filtered.Add("plugins.security.ssl.http.truststore_password: $pwOut")

  $httpClientAuthMode = if ($env:TINYSOCS_HTTP_CLIENTAUTH_MODE) { $env:TINYSOCS_HTTP_CLIENTAUTH_MODE } else { "NONE" }
  [void]$filtered.Add("plugins.security.ssl.http.clientauth_mode: $httpClientAuthMode")

  [void]$filtered.Add("plugins.security.ssl.transport.keystore_type: PKCS12")
  [void]$filtered.Add("plugins.security.ssl.transport.keystore_filepath: $transKs")
  [void]$filtered.Add("plugins.security.ssl.transport.keystore_password: $pwOut")
  [void]$filtered.Add("plugins.security.ssl.transport.keystore_keypassword: $pwOut")
  [void]$filtered.Add("plugins.security.ssl.transport.truststore_type: PKCS12")
  [void]$filtered.Add("plugins.security.ssl.transport.truststore_filepath: $ts")
  [void]$filtered.Add("plugins.security.ssl.transport.truststore_password: $pwOut")
  [void]$filtered.Add("plugins.security.ssl.transport.enforce_hostname_verification: true")

  [void]$filtered.Add("plugins.security.allow_unsafe_democertificates: false")

  $initVal = if ($AllowDefaultInitSecurityIndex) { "true" } else { "false" }
  [void]$filtered.Add("plugins.security.allow_default_init_securityindex: $initVal")

  [void]$filtered.Add($endMarker)

  Ensure-TinySocsWritableFile -Path $ConfigPath
  Set-Content -Path $ConfigPath -Value $filtered.ToArray() -Encoding UTF8 -Force

  _Ensure-TinySocsReadable -Path $configDir -IsDir
  foreach ($p in @(
    (Join-Path $configDir "jvm.options"),
    (Join-Path $configDir "opensearch.keystore"),
    (Join-Path $configDir "log4j2.properties"),
    $ConfigPath,
    $TlsPaths.HttpKeystoreP12,
    $TlsPaths.TransportKeystoreP12,
    $TlsPaths.TruststoreP12,
    $StorePassDpapiPath
  )) {
    _Ensure-TinySocsReadable -Path $p
  }

  # If we sourced from YAML, self-heal DPAPI (so upgrades stop being haunted)
  if ($pwSource -like "YAML:*" -and -not [string]::IsNullOrWhiteSpace($StorePassDpapiPath)) {
    _Write-TinySocsDpapiStorePass -Path $StorePassDpapiPath -Password $pw
    $pwSource = "YAML->$StorePassDpapiPath"
  }

  Write-TinySocsLog "OpenSearch security/TLS settings ensured in $ConfigPath (TinySocs-managed PKCS12 block appended). allow_default_init_securityindex=$initVal; storepass_source=$pwSource"
}

function Ensure-TinySocsOpenSearchProgramDataConfig {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$OpenSearchRoot,
    [Parameter(Mandatory)][string]$ProgramDataConf,
    [switch]$Force
  )

  $src = Join-Path $OpenSearchRoot 'config'
  if (-not (Test-Path $src -PathType Container)) {
    throw "OpenSearch config directory not found at '$src'"
  }

  if (-not (Test-TinySocsIsElevated)) {
    throw "Install-TinySocsLocalSiem must be run from an elevated (Run as Administrator) PowerShell. ProgramData config seeding requires admin rights."
  }

  # We NEVER want baseline mirroring to delete TinySocs-managed files.
  # Preserve these unless Force is explicitly requested:
  $preserveDirs  = @("certs","opensearch-security")
  $preserveFiles = @("opensearch.yml","opensearch.keystore")

  $needsSeed = (-not (Test-Path $ProgramDataConf -PathType Container))
  if ($Force.IsPresent) { $needsSeed = $true }

  try {
    # Stop service if running so files aren't locked mid-copy
    try {
      $svc = Get-Service -Name 'TinySocsOpenSearch' -ErrorAction SilentlyContinue
      if ($svc -and $svc.Status -ne 'Stopped') {
        Stop-Service -Name 'TinySocsOpenSearch' -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 3
      }
    } catch { }

    $dataRoot = Split-Path -Parent $ProgramDataConf
    $stash    = Join-Path $dataRoot "_stash.conf"

    if ($needsSeed) {
      # Stash preserved dirs/files before we rotate (covers reinstall/upgrade where ProgramData exists)
      try {
        if (Test-Path $ProgramDataConf -PathType Container) {
          New-Item -ItemType Directory -Force -Path $stash | Out-Null

          foreach ($d in $preserveDirs) {
            $p = Join-Path $ProgramDataConf $d
            if (Test-Path $p -PathType Container) {
              New-Item -ItemType Directory -Force -Path (Join-Path $stash $d) | Out-Null
              Invoke-TinySocsCmd "robocopy ""$p"" ""$(Join-Path $stash $d)"" /E /COPY:DAT /DCOPY:DAT /R:1 /W:1 /NFL /NDL /NJH /NJS /NP >nul"
            }
          }

          foreach ($f in $preserveFiles) {
            $p = Join-Path $ProgramDataConf $f
            if (Test-Path $p -PathType Leaf) {
              Copy-Item -Force -Path $p -Destination (Join-Path $stash $f) -ErrorAction SilentlyContinue
            }
          }

          Set-TinySocsSecureAcl -Path $stash -UsersRead
        }
      } catch {
        Write-TinySocsLog -Level "WARN" -Message "Failed to stash existing ProgramData config prior to rotation: $($_.Exception.Message)"
      }

      if (Test-Path $ProgramDataConf -PathType Container) {
        Set-TinySocsSecureAcl -Path $ProgramDataConf -UsersRead
        $backup = "$ProgramDataConf.old-$(Get-Date -Format yyyyMMdd-HHmmss)"
        try {
          Move-Item -Force -Path $ProgramDataConf -Destination $backup -ErrorAction Stop
          Set-TinySocsSecureAcl -Path $backup -UsersRead
          Write-TinySocsLog "Moved existing ProgramData OpenSearch config aside to $backup"
        } catch {
          try {
            Remove-Item -Recurse -Force -Path $ProgramDataConf -ErrorAction Stop
            Write-TinySocsLog "Removed existing ProgramData OpenSearch config at $ProgramDataConf"
          } catch {
            throw "Unable to replace ProgramData OpenSearch config at '$ProgramDataConf' (rename+delete failed). ACL/lock issue. Details: $($_.Exception.Message)"
          }
        }
      }

      New-Item -ItemType Directory -Force -Path $ProgramDataConf | Out-Null
    } else {
      # Ensure it exists; no rotation path
      New-Item -ItemType Directory -Force -Path $ProgramDataConf | Out-Null
    }

    # Copy baseline config files WITHOUT deleting and WITHOUT overwriting TinySocs-managed pieces
    # Use /E not /MIR, exclude dirs/files we manage ourselves.
    $xd = ($preserveDirs | ForEach-Object { "/XD `"$($_)`"" }) -join " "
    $xf = ($preserveFiles | ForEach-Object { "/XF `"$($_)`"" }) -join " "

    $cmd = "robocopy ""$src"" ""$ProgramDataConf"" /E /COPY:DAT /DCOPY:DAT /R:2 /W:1 /NFL /NDL /NJH /NJS /NP $xd $xf"
    $rcOut = & cmd.exe /V:OFF /C $cmd 2>&1
    $rc = $LASTEXITCODE
    if ($rc -ge 8) { throw "robocopy failed with exit code $rc. Output: $((($rcOut | Out-String).Trim()))" }

    # Restore stashed preserved items if we rotated
    if ($needsSeed) {
      try {
        if (Test-Path $stash -PathType Container) {
          foreach ($d in $preserveDirs) {
            $p = Join-Path $stash $d
            if (Test-Path $p -PathType Container) {
              New-Item -ItemType Directory -Force -Path (Join-Path $ProgramDataConf $d) | Out-Null
              Invoke-TinySocsCmd "robocopy ""$p"" ""$(Join-Path $ProgramDataConf $d)"" /E /COPY:DAT /DCOPY:DAT /R:1 /W:1 /NFL /NDL /NJH /NJS /NP >nul"
            }
          }

          foreach ($f in $preserveFiles) {
            $p = Join-Path $stash $f
            if (Test-Path $p -PathType Leaf) {
              Copy-Item -Force -Path $p -Destination (Join-Path $ProgramDataConf $f) -ErrorAction SilentlyContinue
            }
          }
        }
      } catch {
        Write-TinySocsLog -Level "WARN" -Message "Failed to restore preserved ProgramData config after rotation: $($_.Exception.Message)"
      }
    }

    Set-TinySocsSecureAcl -Path $ProgramDataConf -UsersRead

    # Always re-harden cert ACLs if certs exist
    try {
      $certsDir = Join-Path $ProgramDataConf 'certs'
      if (Test-Path $certsDir -PathType Container) {
        Repair-TinySocsOpenSearchCertAcls -CertsDir $certsDir
      }
    } catch {
      Write-TinySocsLog -Level "WARN" -Message "Post-seed cert ACL repair failed: $($_.Exception.Message)"
    }

    Write-TinySocsLog "OpenSearch config ensured in ProgramData (non-destructive copy, rc=$rc): $ProgramDataConf"
  } catch {
    throw "Failed to seed ProgramData OpenSearch config at '$ProgramDataConf': $($_.Exception.Message)"
  }
}

function Disable-TinySocsOpenSearchSecurityPlugin {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$OpenSearchRoot
  )

  $pluginPath = Join-Path $OpenSearchRoot "plugins\opensearch-security"

  if (-not (Test-Path $pluginPath -PathType Container)) {
    Write-TinySocsLog "OpenSearch security plugin not present at $pluginPath; nothing to disable."
    return
  }

  $svc = Get-Service -Name "TinySocsOpenSearch" -ErrorAction SilentlyContinue
  if ($null -ne $svc -and $svc.Status -eq 'Running') {
    try {
      Write-TinySocsLog "Stopping TinySocsOpenSearch service to remove security plugin at $pluginPath."
      Stop-Service -Name "TinySocsOpenSearch" -Force -ErrorAction Stop
      Start-Sleep -Seconds 5
    } catch {
      Write-TinySocsLog -Level "WARN" -Message "Failed to stop TinySocsOpenSearch before removing security plugin at ${pluginPath}: $($_.Exception.Message)"
    }
  }

  try {
    Remove-Item $pluginPath -Recurse -Force -ErrorAction Stop
    Write-TinySocsLog "OpenSearch security plugin removed at $pluginPath (INSECURE mode)."
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to remove OpenSearch security plugin at ${pluginPath}: $($_.Exception.Message)"
  }
}

function Ensure-TinySocsOpenSearchRunner {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$InstallRoot,
    [Parameter(Mandatory)][string]$OpenSearchRoot,
    [Parameter(Mandatory)][string]$ProgramDataConf,
    [Parameter(Mandatory)][string]$RunnerPath
  )

  function _EscapePsSingleQuotedString {
    param([Parameter(Mandatory)][string]$s)
    return ($s -replace "'", "''")
  }

  $modulePath = Join-Path $InstallRoot "modules\TinySocs.Installer.psm1"
  $batPath    = Join-Path $OpenSearchRoot "bin\opensearch.bat"

  $modulePathQ      = _EscapePsSingleQuotedString $modulePath
  $programDataConfQ = _EscapePsSingleQuotedString $ProgramDataConf
  $batPathQ         = _EscapePsSingleQuotedString $batPath
  $osRootQ          = _EscapePsSingleQuotedString $OpenSearchRoot

  $template = @'
$ErrorActionPreference = 'Stop'
try { Import-Module '__MODULE__' -Force } catch { }

# Always force ProgramData config
$env:OPENSEARCH_PATH_CONF = '__CONF__'

# Defensive Java env (helps if service env is sparse)
try {
  $jdk = Join-Path '__OSROOT__' 'jdk'
  if (Test-Path $jdk -PathType Container) {
    $env:OPENSEARCH_JAVA_HOME = $jdk
    $env:JAVA_HOME = $jdk
    $env:Path = (Join-Path $jdk 'bin') + ';' + $env:Path
  }
} catch { }

# Prefer CredMan admin pass (TinySocs/SIEM/Creds)
try {
  $raw = Get-TSCredential -Name 'TinySocs/SIEM/Creds'
  if ($raw) {
    $j = $raw | ConvertFrom-Json
    if ($j.pass) { $env:OPENSEARCH_INITIAL_ADMIN_PASSWORD = [string]$j.pass }
  }
} catch { }

# Fallback: DPAPI-protected admin pass file (survives reinstall if CredMan is wiped)
if ([string]::IsNullOrWhiteSpace($env:OPENSEARCH_INITIAL_ADMIN_PASSWORD)) {
  try {
    $certsDir = Join-Path '__CONF__' 'certs'
    if (Get-Command Read-TinySocsSiemAdminPassFromDpapiFile -ErrorAction SilentlyContinue) {
      $p = Read-TinySocsSiemAdminPassFromDpapiFile -CertsDir $certsDir
      if ($p) { $env:OPENSEARCH_INITIAL_ADMIN_PASSWORD = [string]$p }
    } else {
      $dp = Join-Path $certsDir 'siem-admin-pass.dpapi'
      if (Test-Path $dp -PathType Leaf) {
        $b64 = (Get-Content -Path $dp -Raw).Trim()
        if (-not [string]::IsNullOrWhiteSpace($b64)) {
          Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue | Out-Null
          $enc = [Convert]::FromBase64String($b64)
          $bytes = [System.Security.Cryptography.ProtectedData]::Unprotect(
            $enc, $null, [System.Security.Cryptography.DataProtectionScope]::LocalMachine
          )
          $env:OPENSEARCH_INITIAL_ADMIN_PASSWORD = [System.Text.Encoding]::UTF8.GetString($bytes).Trim([char]0).Trim()
        }
      }
    }
  } catch { }
}

# Self-heal TLS storepass into opensearch.yml before starting, using DPAPI storepass file.
# This fixes upgrades/reinstalls where opensearch.yml might revert to a placeholder or stale password.
try {
  $confDir = '__CONF__'
  $certsDir = Join-Path $confDir 'certs'
  $dp = Join-Path $certsDir 'opensearch-tls-storepass.dpapi'
  $cfg = Join-Path $confDir 'opensearch.yml'

  if ((Test-Path $dp -PathType Leaf) -and (Test-Path $cfg -PathType Leaf)) {

    function _Read-DpapiText([string]$p) {
      $bytes = $null
      try {
        $raw = (Get-Content -Path $p -Raw -ErrorAction Stop).Trim()
        if (-not [string]::IsNullOrWhiteSpace($raw) -and $raw -match '^[A-Za-z0-9+/=\r\n]+$') {
          $bytes = [Convert]::FromBase64String($raw)
        }
      } catch { }
      if (-not $bytes) {
        try { $bytes = [System.IO.File]::ReadAllBytes($p) } catch { }
      }
      if (-not $bytes) { return $null }

      Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue | Out-Null

      $clear = $null
      try { $clear = [System.Security.Cryptography.ProtectedData]::Unprotect($bytes, $null, [System.Security.Cryptography.DataProtectionScope]::LocalMachine) } catch { }
      if (-not $clear) {
        try { $clear = [System.Security.Cryptography.ProtectedData]::Unprotect($bytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser) } catch { }
      }
      if (-not $clear) { return $null }

      $s = $null
      try { $s = [Text.Encoding]::UTF8.GetString($clear).Trim([char]0).Trim() } catch { }
      if ([string]::IsNullOrWhiteSpace($s)) {
        try { $s = [Text.Encoding]::Unicode.GetString($clear).Trim([char]0).Trim() } catch { }
      }
      if ([string]::IsNullOrWhiteSpace($s)) { return $null }
      return $s
    }

    $pw = _Read-DpapiText $dp
    if (-not [string]::IsNullOrWhiteSpace($pw)) {
      $begin = '# --- BEGIN TinySocs security/TLS ---'
      $end   = '# --- END TinySocs security/TLS ---'
      $c = Get-Content -Path $cfg -Raw

      # Patch only inside our managed block if present, otherwise do a conservative placeholder swap.
      if ($c -like "*$begin*$end*") {
        $pattern = "(?s)$([Regex]::Escape($begin)).*?$([Regex]::Escape($end))"
        $block = [Regex]::Match($c, $pattern).Value
        if (-not [string]::IsNullOrWhiteSpace($block)) {
          $block2 = $block
          $keys = @(
            'plugins.security.ssl.http.keystore_password',
            'plugins.security.ssl.http.keystore_keypassword',
            'plugins.security.ssl.http.truststore_password',
            'plugins.security.ssl.transport.keystore_password',
            'plugins.security.ssl.transport.keystore_keypassword',
            'plugins.security.ssl.transport.truststore_password'
          )
          foreach ($k in $keys) {
            $block2 = [Regex]::Replace($block2, "(?m)^($([Regex]::Escape($k))\s*:\s*).*$", "`$1$pw")
          }
          if ($block2 -ne $block) {
            $c = $c.Replace($block, $block2)
            Set-Content -Path $cfg -Value $c -Encoding UTF8 -Force
          }
        }
      } else {
        if ($c.Contains('__TINYSOCS_TLS_STOREPASS__')) {
          # Replace literal placeholder (quoted or unquoted)
          $pwYaml = '"' + ($pw.Replace('\','\\').Replace('"','\"')) + '"'
          $c = $c.Replace('__TINYSOCS_TLS_STOREPASS__', $pwYaml)
          Set-Content -Path $cfg -Value $c -Encoding UTF8 -Force
        }
      }
    }
  }
} catch { }

& '__BAT__'
'@

  $script = $template
  $script = $script.Replace('__MODULE__', $modulePathQ)
  $script = $script.Replace('__CONF__',   $programDataConfQ)
  $script = $script.Replace('__BAT__',    $batPathQ)
  $script = $script.Replace('__OSROOT__', $osRootQ)

  $dir = Split-Path -Parent $RunnerPath
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }

  try {
    try { if (Test-Path $RunnerPath) { attrib.exe -R -S -H "$RunnerPath" | Out-Null } } catch { }
    try { & takeown.exe /F $RunnerPath /A 2>$null | Out-Null } catch { }
    try { & icacls $RunnerPath /reset /C 2>$null | Out-Null } catch { }

    Ensure-TinySocsWritableFile -Path $RunnerPath
    Set-Content -Path $RunnerPath -Value $script -Encoding UTF8 -Force

    try {
      & icacls $RunnerPath /inheritance:r /grant:r "*S-1-5-18:(F)" "*S-1-5-32-544:(F)" "*S-1-5-11:(RX)" /C | Out-Null
    } catch { }

    Write-TinySocsLog "OpenSearch runner ensured at $RunnerPath (forces ProgramData config + reads CredMan/DPAPI admin pass + self-heals TLS storepass at start)."
  } catch {
    Write-TinySocsLog -Level "ERROR" -Message "Failed to write OpenSearch runner at ${RunnerPath}: $($_.Exception.Message)"
    throw
  }
}

function Test-NssmManagedService {
  param(
    [Parameter(Mandatory)] [string] $ServiceName,
    [Parameter(Mandatory)] [string] $NssmExe
  )

  if (!(Test-Path $NssmExe)) { return $false }

  try {
    # Suppress stderr so it won't become a terminating error
    $out = & $NssmExe get $ServiceName Application 2>$null
    if ($LASTEXITCODE -ne 0) { return $false }
    if ($out -match "only valid for services managed by NSSM") { return $false }
    if ([string]::IsNullOrWhiteSpace(($out | Out-String))) { return $false }
    return $true
  } catch {
    return $false
  }
}

function Register-TinySocsOpenSearchService {
  $nssm = "C:\Program Files\TinySocs\bin\nssm.exe"
  if (-not (Test-Path $nssm)) {
    Write-TinySocsLog -Level "WARN" -Message "nssm.exe missing; cannot register OpenSearch service."
    return
  }

  $installRoot = Get-TinySocsInstallRoot
  $osHome = Join-Path $installRoot "OpenSearch"
  if (-not (Test-Path $osHome)) {
    Write-TinySocsLog -Level "WARN" -Message "OpenSearch home not found at $osHome; cannot register service."
    return
  }

  # Canonical bat path (avoid recursive discovery + quoting footguns)
  $batPath = Join-Path $osHome "bin\opensearch.bat"
  if (-not (Test-Path -LiteralPath $batPath)) {
    Write-TinySocsLog -Level "WARN" -Message "opensearch.bat not found at $batPath; cannot register service."
    return
  }

  $dataRoot = Get-TinySocsDataRoot
  $conf   = Join-Path $dataRoot "OpenSearch\config"
  $osLogs = Join-Path $dataRoot "OpenSearch\logs"
  New-Item -ItemType Directory -Force -Path $conf   | Out-Null
  New-Item -ItemType Directory -Force -Path $osLogs | Out-Null

  # --- Best-effort self-heal: ensure ProgramData config is not missing critical bits (incl. SSL material) ---
  # This is intentionally conservative: copy ONLY if missing at destination.
  $seedConf = Join-Path $osHome "config"
  if (Test-Path $seedConf) {
    $mustHave = @(
      "opensearch.yml",
      "jvm.options",
      "log4j2.properties"
    )

    foreach ($name in $mustHave) {
      $dst = Join-Path $conf $name
      $src = Join-Path $seedConf $name
      if (-not (Test-Path -LiteralPath $dst) -and (Test-Path -LiteralPath $src)) {
        Copy-Item -LiteralPath $src -Destination $dst -Force
        Write-TinySocsLog -Level "INFO" -Message "Seeded missing OpenSearch config file into ProgramData: $name"
      }
    }

    # Copy cert/key/keystore-ish files (and any nested paths) if absent in ProgramData.
    $sslExts = @(".pem", ".crt", ".cer", ".key", ".p12", ".pfx", ".jks")
    $seedFiles = Get-ChildItem -LiteralPath $seedConf -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
      $sslExts -contains $_.Extension.ToLowerInvariant()
    }

    foreach ($f in $seedFiles) {
      $rel = $f.FullName.Substring($seedConf.Length).TrimStart('\','/')
      $dst = Join-Path $conf $rel
      $dstDir = Split-Path -Parent $dst
      if (-not (Test-Path -LiteralPath $dst)) {
        New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
        Copy-Item -LiteralPath $f.FullName -Destination $dst -Force
        Write-TinySocsLog -Level "INFO" -Message "Seeded missing SSL material into ProgramData: $rel"
      }
    }
  }

  # Write a stable runner script in ProgramData (service will NOT depend on Inno temp)
  $runnerDir  = Join-Path $dataRoot "OpenSearch"
  $runnerPath = Join-Path $runnerDir "Run-OpenSearch.ps1"
  New-Item -ItemType Directory -Force -Path $runnerDir | Out-Null

  $batQ  = $batPath.Replace("'", "''")
  $homeQ = $osHome.Replace("'", "''")
  $confQ = $conf.Replace("'", "''")

  $runner = @"
`$ErrorActionPreference = 'Stop'

# Hard-coded at install time to avoid dependency on module functions at service runtime
`$osHome = '$homeQ'
`$bat    = '$batQ'
`$conf   = '$confQ'

# Ensure OpenSearch uses ProgramData config
`$env:OPENSEARCH_PATH_CONF = `$conf

try {
  Set-Location -LiteralPath `$osHome
  & `$bat
} catch {
  # NSSM captures stderr -> AppStderr
  Write-Error ("Run-OpenSearch.ps1 failed: " + `$_.Exception.Message)
  throw
}
"@

  Set-Content -LiteralPath $runnerPath -Value $runner -Encoding UTF8 -Force

  # Configure NSSM service to run via PowerShell runner (avoid cmd.exe /c + space quoting issues)
  $ps = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
  $serviceName = "TinySocsOpenSearch"

  # Detect if service already exists
  $exists = $false
  try {
    & $nssm status $serviceName 1>$null 2>$null
    if ($LASTEXITCODE -eq 0) { $exists = $true }
  } catch { $exists = $false }

  # Stop if exists (so upgrades reliably take effect)
  if ($exists) {
    try { & $nssm stop $serviceName | Out-Null } catch { }
    Start-Sleep -Milliseconds 750
  }

  if (-not $exists) {
    & $nssm install $serviceName $ps | Out-Null
  }

  # Always re-apply settings (upgrade-safe)
  & $nssm set $serviceName Application        $ps | Out-Null
  & $nssm set $serviceName AppDirectory       $osHome | Out-Null
  & $nssm set $serviceName AppParameters      "-NoProfile -ExecutionPolicy Bypass -File `"$runnerPath`"" | Out-Null
  & $nssm set $serviceName Start              SERVICE_AUTO_START | Out-Null
  & $nssm set $serviceName AppStdout          (Join-Path $osLogs "opensearch.out.log") | Out-Null
  & $nssm set $serviceName AppStderr          (Join-Path $osLogs "opensearch.err.log") | Out-Null
  & $nssm set $serviceName AppNoConsole       1 | Out-Null
  & $nssm set $serviceName AppRestartDelay    2000 | Out-Null

  # Restart on “default” exit behaviour (belt + braces)
  try { & $nssm set $serviceName AppExit Default Restart | Out-Null } catch { }

  # Keep env invariant at the service layer too (belt + braces)
  $envExtra = @(
    "OPENSEARCH_PATH_CONF=$conf"
  ) -join "`r`n"
  & $nssm set $serviceName AppEnvironmentExtra $envExtra | Out-Null

  # Recovery (use only restart actions; avoid the empty-string action which is fragile)
  try {
    sc.exe failure $serviceName reset= 60 actions= restart/2000/restart/2000/restart/2000 | Out-Null
  } catch { }

  # Start (or restart) the service
  try { & $nssm start $serviceName | Out-Null } catch { }

  Write-TinySocsLog "OpenSearch service registered (TinySocsOpenSearch) via PowerShell runner with OPENSEARCH_PATH_CONF=$conf (runner=$runnerPath)"
}

# NOTE: Ensure-* should NOT start the service (Install-* decides based on -NoStart).
function Ensure-TinySocsOpenSearchService {
  [CmdletBinding()]
  param(
    [string] $ServiceName    = "TinySocsOpenSearch",
    [string] $NssmExe        = "C:\Program Files\TinySocs\bin\nssm.exe",
    [string] $Runner         = "C:\ProgramData\TinySocs\OpenSearch\run-opensearch.ps1",
    [string] $WorkDir        = "C:\ProgramData\TinySocs\OpenSearch",
    [string] $LogsDir        = "C:\ProgramData\TinySocs\OpenSearch\logs",
    [int]    $HttpPort       = 9200,
    [string] $ProgramDataConf = "C:\ProgramData\TinySocs\OpenSearch\config"
  )

  if (-not (Test-Path $NssmExe -PathType Leaf)) { throw "nssm.exe not found: $NssmExe" }

  $ps = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
  if (-not (Test-Path $Runner -PathType Leaf)) { throw "Missing runner: $Runner" }

  New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null
  New-Item -ItemType Directory -Force -Path $LogsDir | Out-Null

  $null = sc.exe query $ServiceName 2>$null
  $serviceExists = ($LASTEXITCODE -eq 0)

  $validNssm = $false
  if ($serviceExists) {
    $validNssm = (Test-NssmManagedService -ServiceName $ServiceName -NssmExe $NssmExe)
  }

  if ($serviceExists -and -not $validNssm) {
    try { Stop-Service $ServiceName -Force -ErrorAction SilentlyContinue } catch {}
    Start-Sleep 2
    try { sc.exe stop   $ServiceName | Out-Null } catch { }
    Start-Sleep 2
    try { sc.exe delete $ServiceName | Out-Null } catch { }

    for ($i=0; $i -lt 20; $i++) {
      $null = sc.exe query $ServiceName 2>$null
      if ($LASTEXITCODE -ne 0) { break }
      Start-Sleep 1
    }
    $serviceExists = $false
  }

  if (-not (Test-NssmManagedService -ServiceName $ServiceName -NssmExe $NssmExe)) {
    & $NssmExe install $ServiceName $ps 2>$null | Out-Null
  }

  & $NssmExe set $ServiceName Application   $ps      | Out-Null
  & $NssmExe set $ServiceName AppDirectory  $WorkDir | Out-Null
  & $NssmExe set $ServiceName AppParameters "-NoProfile -ExecutionPolicy Bypass -File `"$Runner`"" | Out-Null
  & $NssmExe set $ServiceName AppStdout     "$LogsDir\TinySocsOpenSearch.out.log" | Out-Null
  & $NssmExe set $ServiceName AppStderr     "$LogsDir\TinySocsOpenSearch.err.log" | Out-Null

  try { & $NssmExe set $ServiceName AppNoConsole     1     | Out-Null } catch { }
  try { & $NssmExe set $ServiceName AppThrottle      15000 | Out-Null } catch { }
  try { & $NssmExe set $ServiceName AppRestartDelay  5000  | Out-Null } catch { }

  & $NssmExe set $ServiceName AppStopMethodSkip 1        | Out-Null
  & $NssmExe set $ServiceName AppExit Default Restart    | Out-Null

  # Ensure identity + delayed-auto via BOTH NSSM + sc.exe
  try { & $NssmExe set $ServiceName ObjectName "LocalSystem" | Out-Null } catch { }
  try { & $NssmExe set $ServiceName Start "SERVICE_DELAYED_AUTO_START" | Out-Null } catch { }

  try { sc.exe config $ServiceName start= delayed-auto | Out-Null } catch { }
  try { sc.exe config $ServiceName obj= LocalSystem    | Out-Null } catch { }

  try {
    sc.exe failure $ServiceName reset= 86400 actions= restart/5000/restart/5000/restart/5000 | Out-Null
    sc.exe failureflag $ServiceName 1 | Out-Null
  } catch { }

  # Merge OPENSEARCH_PATH_CONF into existing AppEnvironmentExtra (don’t clobber)
  try {
    if (-not [string]::IsNullOrWhiteSpace($ProgramDataConf)) {
      $current = @()
      try {
        $out = & $NssmExe get $ServiceName AppEnvironmentExtra 2>$null
        $txt = ($out | Out-String)
        if (-not [string]::IsNullOrWhiteSpace($txt)) {
          $current = ($txt -split "(`r`n|`n|`r)") | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
        }
      } catch { $current = @() }

      $kv = @{}
      $passthru = New-Object System.Collections.Generic.List[string]

      foreach ($ln in $current) {
        if ($ln -match '^\s*([^=]+)=(.*)$') {
          $k = $matches[1].Trim()
          $v = $matches[2]
          if (-not [string]::IsNullOrWhiteSpace($k)) { $kv[$k] = $v }
        } else {
          [void]$passthru.Add($ln)
        }
      }

      $kv["OPENSEARCH_PATH_CONF"] = $ProgramDataConf

      $merged = New-Object System.Collections.Generic.List[string]
      foreach ($k in $kv.Keys) { [void]$merged.Add("$k=$($kv[$k])") }
      foreach ($x in $passthru) { [void]$merged.Add($x) }

      $envExtra = ($merged.ToArray() -join "`n")
      & $NssmExe set $ServiceName AppEnvironmentExtra $envExtra | Out-Null
    }
  } catch { }

  Write-TinySocsLog "OpenSearch service ensured via NSSM (not started here). (runner=$Runner, workdir=$WorkDir, conf=$ProgramDataConf)"
}

# Helper: Ensure TinySocs Agent service via NSSM
function Ensure-TinySocsAgentService {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$AgentExePath,
    [Parameter(Mandatory)][string]$NssmPath,
    [Parameter(Mandatory)][string]$ServiceName,
    [Parameter(Mandatory)][string]$DisplayName,
    [Parameter(Mandatory)][string]$Description
  )

  if (-not (Test-Path $NssmPath -PathType Leaf)) {
    throw "nssm.exe not found at '$NssmPath'. Ensure the TinySocs installer copies nssm.exe before installing the agent."
  }

  if (-not (Test-Path $AgentExePath -PathType Leaf)) {
    Write-TinySocsLog -Level "WARN" -Message "TinySocs.Agent.exe not found at '$AgentExePath'. Agent service '$ServiceName' will not be installed."
    return
  }

  $agentRoot = Split-Path -Parent $AgentExePath
  $service   = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue

  if ($null -eq $service) {
    Write-TinySocsLog "Creating NSSM service '$ServiceName' for TinySocs Collector Agent"
    & $NssmPath install $ServiceName $AgentExePath | Out-Null
  } else {
    Write-TinySocsLog "Service '$ServiceName' already exists; updating NSSM configuration"
  }

  & $NssmPath set $ServiceName DisplayName  $DisplayName | Out-Null
  & $NssmPath set $ServiceName Description  $Description | Out-Null
  & $NssmPath set $ServiceName AppDirectory $agentRoot   | Out-Null

  & $NssmPath set $ServiceName ObjectName "LocalSystem"           | Out-Null
  & $NssmPath set $ServiceName Start "SERVICE_DELAYED_AUTO_START" | Out-Null
  & $NssmPath set $ServiceName AppExit Default Restart            | Out-Null
  & $NssmPath set $ServiceName AppStdout "C:\ProgramData\TinySocs\Collector\logs\TinySocsAgent.out.log" | Out-Null
  & $NssmPath set $ServiceName AppStderr "C:\ProgramData\TinySocs\Collector\logs\TinySocsAgent.err.log" | Out-Null

  Write-TinySocsLog "Service '$ServiceName' ensured via NSSM (TinySocs Agent)."
}

function Wait-TinySocsLocalSiemReady {
  [CmdletBinding()]
  param(
    [string]$Url = "https://127.0.0.1:9200",
    [int]$TimeoutSeconds = 60,
    [int]$IntervalSeconds = 3,
    [switch]$SkipTlsVerify
  )

  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
  Write-TinySocsLog "Waiting for local SIEM HTTP to become ready at $Url (timeout=${TimeoutSeconds}s)."

  $origCallback = $null
  if ($SkipTlsVerify.IsPresent -and $Url.ToLower().StartsWith('https://')) {
    try {
      $origCallback = [System.Net.ServicePointManager]::ServerCertificateValidationCallback
      [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
    } catch { }
  }

  try {
    while ((Get-Date) -lt $deadline) {
      try {
        $resp = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 5 -ErrorAction Stop
        if (($resp.StatusCode -ge 200 -and $resp.StatusCode -lt 300) -or $resp.StatusCode -eq 401) {
          Write-TinySocsLog "Local SIEM HTTP ready at $Url (status=$($resp.StatusCode))."
          return $true
        }
      } catch {
        # When auth is enabled, OpenSearch may return 401; treat that as “HTTP is up”.
        try {
          if ($_.Exception -and $_.Exception.Response) {
            $status = [int]$_.Exception.Response.StatusCode
            if ($status -eq 401) {
              Write-TinySocsLog "Local SIEM HTTP ready at $Url (status=401 Unauthorized)."
              return $true
            }
          }
        } catch { }
      }

      Start-Sleep -Seconds $IntervalSeconds
    }
  }
  finally {
    if ($null -ne $origCallback) {
      try { [System.Net.ServicePointManager]::ServerCertificateValidationCallback = $origCallback } catch { }
    }
  }

  Write-TinySocsLog -Level "WARN" -Message "Local SIEM HTTP did not become ready at $Url within ${TimeoutSeconds}s."
  return $false
}

function Ensure-TinySocsTrustedCaPem {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$CaPemPath
  )

  if (-not (Test-Path $CaPemPath -PathType Leaf)) {
    Write-TinySocsLog -Level "WARN" -Message "CA PEM not found at $CaPemPath; skipping trust import."
    return $false
  }

  try {
    & certutil.exe -addstore -f Root "$CaPemPath" | Out-Null
    Write-TinySocsLog "Imported CA PEM into LocalMachine\Root (certutil): $CaPemPath"
    return $true
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to import CA PEM into Root store: $($_.Exception.Message)"
    return $false
  }
}

function Set-TinySocsOpenSearchAdminPasswordInConfig {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$OpenSearchRoot,
    [Parameter(Mandatory)][string]$ConfigRoot,
    [Parameter(Mandatory)][string]$AdminPassword
  )

  $hashTool = Join-Path $OpenSearchRoot "plugins\opensearch-security\tools\hash.bat"
  if (-not (Test-Path $hashTool -PathType Leaf)) {
    throw "OpenSearch hash tool not found at '$hashTool'"
  }

  $env:OPENSEARCH_JAVA_HOME = Join-Path $OpenSearchRoot "jdk"
  $env:JAVA_HOME            = $env:OPENSEARCH_JAVA_HOME
  $env:Path                 = (Join-Path $env:JAVA_HOME "bin") + ";" + $env:Path

  $hashOut = & $hashTool -p $AdminPassword
  $hash = ($hashOut | Select-Object -Last 1).Trim()
  if ([string]::IsNullOrWhiteSpace($hash) -or ($hash -notmatch '^\$2')) {
    throw "Failed to generate bcrypt hash for admin password (hash='$hash')"
  }

  $iu = Join-Path $ConfigRoot "opensearch-security\internal_users.yml"
  if (-not (Test-Path $iu -PathType Leaf)) {
    throw "internal_users.yml not found at '$iu'"
  }

  Ensure-TinySocsWritableFile -Path $iu
  $text = Get-Content -Path $iu -Raw -ErrorAction Stop

  $adminBlock = @"
admin:
  hash: "$hash"
  reserved: true
  backend_roles:
    - "admin"
  opendistro_security_roles:
    - "all_access"
    - "security_rest_api_access"
  description: "TinySocs local admin"
"@

  if ($text -match '(?ms)^\s*admin\s*:\s*\r?\n') {
    $text = [regex]::Replace(
      $text,
      '(?ms)^\s*admin\s*:\s*\r?\n.*?(?=^\S|\z)',
      $adminBlock + "`r`n",
      1
    )
  } else {
    $text = $adminBlock + "`r`n`r`n" + $text
  }

  Ensure-TinySocsWritableFile -Path $iu
  Set-Content -Path $iu -Value $text -Encoding UTF8 -Force

  Write-TinySocsLog "Updated ProgramData internal_users.yml admin block + hash (config=$iu)."
}

function Get-TinySocsOpenSearchSecurityTemplatePath {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$InstallRoot,
    [Parameter(Mandatory)][string]$OpenSearchRoot
  )

  # Search order (first hit wins):
  # 1) OpenSearchRoot\config\opensearch-security   (if you ship it there)
  # 2) InstallRoot\assets\opensearch-security      (recommended)
  # 3) Module folder\assets\opensearch-security    (dev convenience)
  $candidates = @(
    (Join-Path $OpenSearchRoot "config\opensearch-security"),
    (Join-Path $InstallRoot   "assets\opensearch-security"),
    (Join-Path $PSScriptRoot  "assets\opensearch-security")
  ) | Where-Object { $_ -and (Test-Path $_ -PathType Container) }

  $first = $candidates | Select-Object -First 1
  if ($first) { return [string]$first }

  throw ("TinySocs OpenSearch security templates not found. " +
         "Expected one of: " +
         "'{0}', '{1}', '{2}'" -f `
         (Join-Path $OpenSearchRoot "config\opensearch-security"),
         (Join-Path $InstallRoot   "assets\opensearch-security"),
         (Join-Path $PSScriptRoot  "assets\opensearch-security"))
}

function Ensure-TinySocsOpenSearchSecurityConfigTree {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$InstallRoot,
    [Parameter(Mandatory)][string]$OpenSearchRoot,
    [Parameter(Mandatory)][string]$ProgramDataConf,
    [switch]$Force
  )

  $dst = Join-Path $ProgramDataConf "opensearch-security"
  $needed = @(
    "config.yml",
    "internal_users.yml",
    "roles.yml",
    "roles_mapping.yml",
    "action_groups.yml",
    "tenants.yml",
    "nodes_dn.yml"
  )

  $haveAll = $true
  if (-not (Test-Path $dst -PathType Container)) { $haveAll = $false }
  foreach ($f in $needed) {
    if (-not (Test-Path (Join-Path $dst $f) -PathType Leaf)) { $haveAll = $false; break }
  }

  if ($haveAll -and -not $Force.IsPresent) {
    Write-TinySocsLog "OpenSearch security config already present in ProgramData; leaving as-is: $dst"
    return $dst
  }

  $src = Get-TinySocsOpenSearchSecurityTemplatePath -InstallRoot $InstallRoot -OpenSearchRoot $OpenSearchRoot

  Write-TinySocsLog ("Seeding ProgramData OpenSearch security config from template: src={0} dst={1} force={2}" -f $src, $dst, $Force.IsPresent)

  New-Item -ItemType Directory -Force -Path $dst | Out-Null

  foreach ($f in $needed) {
    $s = Join-Path $src $f
    $d = Join-Path $dst $f
    if (-not (Test-Path $s -PathType Leaf)) { throw "Missing required security template file: $s" }
    Ensure-TinySocsWritableFile -Path $d
    Copy-Item -Force -Path $s -Destination $d
  }

  foreach ($extra in @("audit.yml","allowlist.yml")) {
    $s = Join-Path $src $extra
    if (Test-Path $s -PathType Leaf) {
      $d = Join-Path $dst $extra
      Ensure-TinySocsWritableFile -Path $d
      Copy-Item -Force -Path $s -Destination $d
    }
  }

  Write-TinySocsLog "ProgramData OpenSearch security config ensured: $dst"
  return $dst
}

function Ensure-TinySocsOpenSearchAdminKeyStores {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$OpenSearchRoot,
    [Parameter(Mandatory)][string]$CertsDir,
    [Parameter(Mandatory)][string]$StorePass,
    [string]$CaSubject    = "CN=TinySocs-OpenSearch-CA",
    [string]$AdminSubject = "CN=TinySocs-OpenSearch-Admin"
  )

  New-Item -ItemType Directory -Force -Path $CertsDir | Out-Null

  $caCert = Get-ChildItem Cert:\LocalMachine\My -ErrorAction SilentlyContinue |
    Where-Object { $_.Subject -eq $CaSubject } |
    Sort-Object NotAfter -Descending |
    Select-Object -First 1
  if (-not $caCert) { throw "CA cert not found in Cert:\LocalMachine\My (Subject=$CaSubject)" }

  $adminCert = Get-ChildItem Cert:\LocalMachine\My -ErrorAction SilentlyContinue |
    Where-Object { $_.Subject -eq $AdminSubject } |
    Sort-Object NotAfter -Descending |
    Select-Object -First 1
  if (-not $adminCert) { throw "Admin cert not found in Cert:\LocalMachine\My (Subject=$AdminSubject)" }

  $caCer      = Join-Path $CertsDir "ca.cer"
  $truststore = Join-Path $CertsDir "admin-truststore.p12"
  $keystore   = Join-Path $CertsDir "admin-keystore.p12"

  Export-Certificate -Cert $caCert -FilePath $caCer -Force | Out-Null

  $keytool = @(
    (Join-Path $OpenSearchRoot "jdk\bin\keytool.exe"),
    (Join-Path $OpenSearchRoot "jre\bin\keytool.exe")
  ) | Where-Object { Test-Path $_ } | Select-Object -First 1

  if (-not $keytool) {
    $keytool = Get-ChildItem -Path $OpenSearchRoot -Recurse -Filter keytool.exe -ErrorAction SilentlyContinue |
      Select-Object -First 1 -ExpandProperty FullName
  }
  if (-not $keytool) { throw "keytool.exe not found under $OpenSearchRoot" }

  # Recreate truststore deterministically
  if (Test-Path $truststore) { Remove-Item $truststore -Force -ErrorAction SilentlyContinue }
  & $keytool -importcert -noprompt `
    -alias tinysocs-ca `
    -file $caCer `
    -keystore $truststore `
    -storetype PKCS12 `
    -storepass $StorePass | Out-Null

  # Recreate admin keystore deterministically
  if (Test-Path $keystore) { Remove-Item $keystore -Force -ErrorAction SilentlyContinue }
  $ksSecure = ConvertTo-SecureString -String $StorePass -AsPlainText -Force
  Export-PfxCertificate -Cert $adminCert -FilePath $keystore -Password $ksSecure -Force | Out-Null

  Write-TinySocsLog "Admin keystore/truststore ensured in ProgramData certs dir (keystore=$keystore truststore=$truststore)."

  return @{
    AdminKeystoreP12   = $keystore
    AdminTruststoreP12 = $truststore
    StorePassword      = $StorePass
    CaCerPath          = $caCer
  }
}

function Invoke-TinySocsOpenSearchSecurityAdminSync {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$OpenSearchRoot,
    [Parameter(Mandatory)][string]$ProgramDataConf,
    [Parameter(Mandatory)][hashtable]$AdminStores,
    [int]$HttpPort = 9200,
    [int]$TimeoutSeconds = 120
  )

  $securityTool = Join-Path $OpenSearchRoot "plugins\opensearch-security\tools\securityadmin.bat"
  if (-not (Test-Path $securityTool -PathType Leaf)) { throw "securityadmin.bat not found: $securityTool" }

  $secDir = Join-Path $ProgramDataConf "opensearch-security"
  if (-not (Test-Path $secDir -PathType Container)) { throw "security config dir not found: $secDir" }

  $ks = [string]$AdminStores.AdminKeystoreP12
  $ts = [string]$AdminStores.AdminTruststoreP12
  $pw = [string]$AdminStores.StorePassword

  foreach ($p in @($ks,$ts)) {
    if (-not (Test-Path $p -PathType Leaf)) { throw "Admin store missing on disk: $p" }
  }

  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
  $lastErr  = $null

  Write-TinySocsLog "Running securityadmin sync (timeout=${TimeoutSeconds}s) against 127.0.0.1:$HttpPort using ProgramData security config."

  while ((Get-Date) -lt $deadline) {
    # Cheap TCP check first (avoids false negatives on TLS handshake timing)
    $tcpOk = $false
    try {
      $client = New-Object System.Net.Sockets.TcpClient
      $iar = $client.BeginConnect("127.0.0.1", $HttpPort, $null, $null)
      $tcpOk = $iar.AsyncWaitHandle.WaitOne(1500)
      try { $client.EndConnect($iar) } catch { }
      $client.Close()
    } catch { $tcpOk = $false }

    if (-not $tcpOk) {
      Start-Sleep -Seconds 2
      continue
    }

    try {
      $out = & $securityTool `
        -cd $secDir `
        -icl -nhnv `
        -h 127.0.0.1 -p $HttpPort `
        -ks $ks -kspass $pw `
        -ts $ts -tspass $pw 2>&1

      $txt = ($out | Out-String)
      if ($txt -match 'Done with success') {
        Write-TinySocsLog "securityadmin sync completed successfully."
        return $true
      }

      $lastErr = $txt.Trim()
      Write-TinySocsLog -Level "WARN" -Message "securityadmin did not report success; will retry. Output: $($lastErr -replace '\s+',' ')"
    } catch {
      $lastErr = $_.Exception.Message
      Write-TinySocsLog -Level "WARN" -Message "securityadmin invocation failed; will retry: $lastErr"
    }

    Start-Sleep -Seconds 3
  }

  Write-TinySocsLog -Level "WARN" -Message "securityadmin sync did not succeed within timeout. Last error/output: $lastErr"
  return $false
}

# -- Local SIEM (OpenSearch via NSSM service) ----------------------------------
function Install-TinySocsLocalSiem {
  [CmdletBinding()]
  param(
    [string]$SiemUser = "admin",
    [string]$SiemPass = "",
    [int]$ApiPort = 9200,
    [int]$DashboardsPort = 5602,
    [switch]$NoStart,

    [string]$ClusterName = "tinysocs-local",
    [string]$NodeName    = "tinysocs-node-1",
    [switch]$ForceConfig,

    [switch]$TrustLocalCA
  )
  Assert-TinySocsAdmin
  Install-TinySocs

  $null = $DashboardsPort

  function _GetTlsVal {
    param(
      [Parameter(Mandatory=$true)] $Obj,
      [Parameter(Mandatory=$true)] [string[]] $Keys
    )
    foreach ($k in $Keys) {
      try {
        if ($Obj -is [hashtable] -and $Obj.ContainsKey($k) -and $Obj[$k]) { return [string]$Obj[$k] }
        $v = $Obj.$k
        if ($v) { return [string]$v }
      } catch { }
    }
    return $null
  }

  function _FindFirst {
    param(
      [Parameter(Mandatory=$true)] [string] $Dir,
      [Parameter(Mandatory=$true)] [string[]] $Patterns
    )
    foreach ($p in $Patterns) {
      try {
        $hit = Get-ChildItem -Path $Dir -File -Recurse -Force -ErrorAction SilentlyContinue |
          Where-Object { $_.Name -like $p } |
          Select-Object -First 1
        if ($hit) { return $hit.FullName }
      } catch { }
    }
    return $null
  }

  function _TryImportLocalCA {
    param([Parameter(Mandatory=$true)] [string] $CaCertPath)

    $ext = [IO.Path]::GetExtension($CaCertPath).ToLowerInvariant()
    if ($ext -notin @(".cer", ".crt")) {
      Write-TinySocsLog -Level "WARN" -Message "CA cert '$CaCertPath' is not .cer/.crt; skipping Windows trust import."
      return $false
    }

    try {
      $certObj = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($CaCertPath)
      $thumb   = $certObj.Thumbprint

      try {
        $alreadyLM = Get-ChildItem -Path "Cert:\LocalMachine\Root" -ErrorAction SilentlyContinue |
          Where-Object { $_.Thumbprint -eq $thumb } | Select-Object -First 1
        if (-not $alreadyLM) {
          Import-Certificate -FilePath $CaCertPath -CertStoreLocation "Cert:\LocalMachine\Root" | Out-Null
          Write-TinySocsLog "Imported TinySocs local CA into LocalMachine\Root (Thumbprint=$thumb)."
        }
      } catch {
        Write-TinySocsLog -Level "WARN" -Message "Failed importing CA into LocalMachine\Root: $($_.Exception.Message)"
      }

      try {
        $alreadyCU = Get-ChildItem -Path "Cert:\CurrentUser\Root" -ErrorAction SilentlyContinue |
          Where-Object { $_.Thumbprint -eq $thumb } | Select-Object -First 1
        if (-not $alreadyCU) {
          Import-Certificate -FilePath $CaCertPath -CertStoreLocation "Cert:\CurrentUser\Root" | Out-Null
          Write-TinySocsLog "Imported TinySocs local CA into CurrentUser\Root (Thumbprint=$thumb)."
        }
      } catch {
        Write-TinySocsLog -Level "WARN" -Message "Failed importing CA into CurrentUser\Root: $($_.Exception.Message)"
      }

      $checkLM = Get-ChildItem -Path "Cert:\LocalMachine\Root" -ErrorAction SilentlyContinue |
        Where-Object { $_.Thumbprint -eq $thumb } | Select-Object -First 1
      $checkCU = Get-ChildItem -Path "Cert:\CurrentUser\Root" -ErrorAction SilentlyContinue |
        Where-Object { $_.Thumbprint -eq $thumb } | Select-Object -First 1

      return [bool]($checkLM -or $checkCU)
    } catch {
      Write-TinySocsLog -Level "WARN" -Message "Failed loading CA cert for trust import ($CaCertPath): $($_.Exception.Message)"
      return $false
    }
  }

  # ---- HARDEN ROOT GETTERS (prevents Join-Path receiving System.Object[]) ----
  $installRootVal = (Get-TinySocsInstallRoot | Select-Object -First 1)
  $dataRootBase   = (Get-TinySocsDataRoot    | Select-Object -First 1)

  $installRoot    = [string]$installRootVal
  $openSearchRoot = Join-Path -Path $installRoot -ChildPath "OpenSearch"

  $dataRoot       = Join-Path -Path ([string]$dataRootBase) -ChildPath "OpenSearch"
  $dataPath       = Join-Path -Path $dataRoot -ChildPath "data"
  $logsPath       = Join-Path -Path $dataRoot -ChildPath "logs"
  $pdConf         = Join-Path -Path $dataRoot -ChildPath "config"
  $certsDir       = Join-Path -Path $pdConf  -ChildPath "certs"
  $nssmPath       = Join-Path -Path $installRoot -ChildPath "bin\nssm.exe"
  # ---- END HARDEN ROOT GETTERS ----

  $insecureLocalSiem = ($env:TINYSOCS_INSECURE_LOCAL_SIEM -eq 'true')

  Write-TinySocsLog "Local SIEM install starting (OpenSearchRoot=$openSearchRoot, DataRoot=$dataRoot, HttpPort=$ApiPort)."

  New-Item -ItemType Directory -Force -Path $dataPath | Out-Null
  New-Item -ItemType Directory -Force -Path $logsPath | Out-Null
  New-Item -ItemType Directory -Force -Path $certsDir | Out-Null

  Ensure-TinySocsOpenSearchProgramDataConfig -OpenSearchRoot $openSearchRoot -ProgramDataConf $pdConf -Force:$ForceConfig
  Ensure-TinySocsOpenSearchSecurityConfigTree -InstallRoot $installRoot -OpenSearchRoot $openSearchRoot -ProgramDataConf $pdConf -Force:$ForceConfig | Out-Null

  $tls = Ensure-TinySocsLocalCaAndServerCert -CertsDir $certsDir
  Repair-TinySocsOpenSearchCertAcls -CertsDir $certsDir

  $caCertPath = _GetTlsVal -Obj $tls -Keys @("CaCerPath","CaCertPath","ca","caCert","cacert","CaCert","RootCa","rootCa","ca_path")
  if (-not $caCertPath) {
    $caCertPath = _FindFirst -Dir $certsDir -Patterns @("*ca*.crt", "*ca*.cer", "*root*.crt", "*root*.cer", "*ca*.pem", "*root*.pem")
  }

  try {
    Set-MachineEnv @{ OPENSEARCH_PATH_CONF = $pdConf }
    $env:OPENSEARCH_PATH_CONF = $pdConf
    Write-TinySocsLog "Set OPENSEARCH_PATH_CONF=$pdConf (machine + session) to ensure persistent ProgramData config is always used."
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to set OPENSEARCH_PATH_CONF machine env var: $($_.Exception.Message)"
  }

  $configFile = Join-Path -Path $pdConf -ChildPath "opensearch.yml"
  Write-TinySocsOpenSearchConfig -ConfigPath $configFile `
    -ClusterName $ClusterName `
    -NodeName    $NodeName `
    -HttpPort    $ApiPort `
    -DataPath    $dataPath `
    -LogsPath    $logsPath `
    -Force:$ForceConfig

  $initMarker = Join-Path -Path $dataRoot -ChildPath ".tinysocs_security_initialized"

  # --- PATCHED LOGIC: robust existing-data detection ---
  $dataPresent = $false
  try { $dataPresent = Test-TinySocsOpenSearchDataPresent -DataPath $dataPath } catch { $dataPresent = $true }

  $hasMarker = $false
  try { $hasMarker = (Test-Path $initMarker -PathType Leaf) } catch { $hasMarker = $false }

  $allowInit = ((-not $dataPresent) -and (-not $hasMarker))
  # --- END PATCHED LOGIC ---

  Ensure-TinySocsOpenSearchSecuritySettings -ConfigPath $configFile -TlsPaths $tls -AllowDefaultInitSecurityIndex:$allowInit
  Assert-TinySocsOpenSearchSecurityConfigPresent -ConfigPath $configFile

  if ($insecureLocalSiem) {
    Write-TinySocsLog -Level "WARN" -Message "TINYSOCS_INSECURE_LOCAL_SIEM=true - disabling OpenSearch security plugin (DEV ONLY)."
    Disable-TinySocsOpenSearchSecurityPlugin -OpenSearchRoot $openSearchRoot
  }

  $scheme  = if ($insecureLocalSiem) { "http" } else { "https" }
  $siemUrl = "${scheme}://127.0.0.1:$ApiPort"

  $wantTrustLocalCA =
    (-not $insecureLocalSiem) -and (
      $TrustLocalCA.IsPresent -or
      ($env:TINYSOCS_TRUST_LOCAL_CA -eq 'true')
    )

  $trustedLocalCA = $false
  if ($wantTrustLocalCA -and $caCertPath) {
    try { $trustedLocalCA = _TryImportLocalCA -CaCertPath $caCertPath } catch { $trustedLocalCA = $false }
  }

  $siemSslVerify = $false
  if ($scheme -eq 'https') {
    $siemSslVerify = [bool]$trustedLocalCA
    if (-not $siemSslVerify) {
      Write-TinySocsLog -Level "WARN" -Message "Local SIEM is https but local CA is not trusted; SIEM_SSL_VERIFY will be set to false."
    }
  }

  $skipTlsForLocal = ($scheme -eq 'https' -and -not $siemSslVerify)

  if ([string]::IsNullOrWhiteSpace($SiemUser)) { $SiemUser = "admin" }

  $callerProvided = (-not [string]::IsNullOrWhiteSpace($SiemPass) -and $SiemPass -ne "ChangeMe123!")

  if (-not $callerProvided) {
    try {
      $existing = Get-TSCredential -Name 'TinySocs/SIEM/Creds'
      if ($existing) {
        $j = $existing | ConvertFrom-Json
        if ($j.user) { $SiemUser = [string]$j.user }
        if ($j.pass) {
          $SiemPass = [string]$j.pass
          Write-TinySocsLog "Reusing existing SIEM/OpenSearch admin password from CredMan (TinySocs/SIEM/Creds)."
        }
      }
    } catch { }

    if ([string]::IsNullOrWhiteSpace($SiemPass) -or $SiemPass -eq "ChangeMe123!") {
      $dpapiPass = Read-TinySocsSiemAdminPassFromDpapiFile -CertsDir $certsDir
      if ($dpapiPass) {
        $SiemPass = $dpapiPass
        Write-TinySocsLog "Restored SIEM/OpenSearch admin password from DPAPI file (stable across reinstalls)."
      }
    }
  }

  if ([string]::IsNullOrWhiteSpace($SiemPass) -or $SiemPass -eq "ChangeMe123!") {
    if ($dataPresent -or -not $allowInit) {
      throw "SIEM/OpenSearch admin password missing, but data appears to already exist. Refusing to generate a new password (would lock you out)."
    }
    $SiemPass = New-TinySocsPassword -Length 28
    Write-TinySocsLog -Level "WARN" -Message "Generated a new strong SIEM/OpenSearch admin password (fresh init)."
  }

  try { $null = Write-TinySocsSiemAdminPassToDpapiFile -CertsDir $certsDir -AdminPass $SiemPass } catch { }

  Set-TinySocsSiemCredential -SiemUrl $siemUrl -SiemUser $SiemUser -SiemPass $SiemPass -SiemSslVerify:$siemSslVerify -CaCertPath $caCertPath

  try {
    Set-TinySocsOpenSearchAdminPasswordInConfig -OpenSearchRoot $openSearchRoot -ConfigRoot $pdConf -AdminPassword $SiemPass
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to update internal_users.yml admin hash: $($_.Exception.Message)"
  }

  $runnerPath = Join-Path -Path $dataRoot -ChildPath "run-opensearch.ps1"
  Ensure-TinySocsOpenSearchRunner -InstallRoot $installRoot -OpenSearchRoot $openSearchRoot -ProgramDataConf $pdConf -RunnerPath $runnerPath

  $serviceName = "TinySocsOpenSearch"
  Ensure-TinySocsOpenSearchService `
    -ServiceName $serviceName `
    -NssmExe $nssmPath `
    -Runner $runnerPath `
    -WorkDir $dataRoot `
    -LogsDir $logsPath `
    -HttpPort $ApiPort `
    -ProgramDataConf $pdConf

  Set-TinySocsOpenSearchAcls -ServiceName $serviceName -DataRoot $dataRoot -LogsPath $logsPath -ConfigPath $pdConf -RunnerPath $runnerPath
  Repair-TinySocsOpenSearchCertAcls -CertsDir $certsDir

  if (-not $NoStart) {
    try {
      # --- PATCH: handle PAUSED explicitly before Start-Service ---
      try {
        $svc = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -eq 'Paused') {
          Write-TinySocsLog -Level "WARN" -Message "Local SIEM service '$serviceName' is PAUSED; attempting Resume-Service before Start-Service."
          try { Resume-Service -Name $serviceName -ErrorAction Stop } catch { }
        }
      } catch { }
      # --- END PATCH ---

      Start-Service -Name $serviceName -ErrorAction Stop
      Write-TinySocsLog "Local SIEM service '$serviceName' started."

      try { Set-TinySocsOpenSearchAcls -ServiceName $serviceName -DataRoot $dataRoot -LogsPath $logsPath -ConfigPath $pdConf -RunnerPath $runnerPath } catch { }
      try { Repair-TinySocsOpenSearchCertAcls -CertsDir $certsDir } catch { }

      $ready = Wait-TinySocsLocalSiemReady -Url $siemUrl -TimeoutSeconds 90 -IntervalSeconds 3 -SkipTlsVerify:($skipTlsForLocal)
      if (-not $ready) {
        Write-TinySocsLog -Level "WARN" -Message "Local SIEM started but HTTP not responding at $siemUrl; check logs under $logsPath."
      } else {
        if ($scheme -eq 'https' -and -not $insecureLocalSiem) {

          try {
            $adminStores = Ensure-TinySocsOpenSearchAdminKeyStores `
              -OpenSearchRoot $openSearchRoot `
              -CertsDir $certsDir `
              -StorePass ([string]$tls.StorePassword)

            $ok = Invoke-TinySocsOpenSearchSecurityAdminSync `
              -OpenSearchRoot $openSearchRoot `
              -ProgramDataConf $pdConf `
              -AdminStores $adminStores `
              -HttpPort $ApiPort `
              -TimeoutSeconds 120

            if (-not $ok) {
              Write-TinySocsLog -Level "WARN" -Message "securityadmin sync did not succeed; continuing (REST init may still work), but security config may not be applied."
            }
          } catch {
            Write-TinySocsLog -Level "WARN" -Message "securityadmin sync step failed: $($_.Exception.Message)"
          }

          try {
            $null = Initialize-TinySocsOpenSearchSecurity -SiemUrl $siemUrl -AdminUser $SiemUser -AdminPass $SiemPass -ServiceUser "tinysocs" -SkipTlsVerify:($skipTlsForLocal)
            Write-TinySocsLog "OpenSearch security initialized via REST (service user + role + mapping)."

            try {
              New-Item -ItemType File -Force -Path $initMarker | Out-Null
              Write-TinySocsLog "Wrote security init marker ($initMarker)."
            } catch {
              Write-TinySocsLog -Level "WARN" -Message "Security init succeeded but failed to write marker ($initMarker): $($_.Exception.Message)"
            }
          } catch {
            Write-TinySocsLog -Level "WARN" -Message "OpenSearch REST security initialization failed: $($_.Exception.Message)"
          }
        }
      }
    } catch {
      Write-TinySocsLog -Level "WARN" -Message "Failed to start local SIEM service '$serviceName': $($_.Exception.Message)"
    }
  } else {
    Write-TinySocsLog -Level "WARN" -Message "NoStart specified; service '$serviceName' configured but not started."
  }

  $verifyString = if ([bool]$siemSslVerify) { "true" } else { "false" }
  $envBlock = @{ SIEM_URL = $siemUrl; SIEM_SSL_VERIFY = $verifyString }
  if ($caCertPath) { $envBlock["SIEM_CA_CERT"] = $caCertPath }
  Set-MachineEnv $envBlock

  if ($scheme -eq "http") {
    Write-TinySocsLog -Level "WARN" -Message "Local SIEM configured at $siemUrl (INSECURE mode: no auth/TLS)."
  } else {
    $msg = "Local SIEM configured at $siemUrl (SECURE mode: TLS+auth, local-only bind)."
    if (-not $siemSslVerify) {
      $msg += " Note: SSL verify is disabled unless the local CA is trusted or clients use SIEM_CA_CERT."
      Write-TinySocsLog -Level "WARN" -Message $msg
    } else {
      Write-TinySocsLog $msg
    }
  }
}

function Install-TinySocsAgentService {
  [CmdletBinding()]
  param(
    [switch]$NoStart,
    [string]$ConfigPath
  )

  Assert-TinySocsAdmin
  Install-TinySocs

  $installRoot = Get-TinySocsInstallRoot
  $agentExe    = Join-Path $installRoot "bin\TinySocs.Agent.exe"
  $nssmPath    = Join-Path $installRoot "bin\nssm.exe"

  if (-not (Test-Path $agentExe -PathType Leaf)) {
    Write-TinySocsLog -Level "WARN" -Message "TinySocs.Agent.exe not found at '$agentExe'. Skipping agent service installation."
    return
  }

  if (-not (Test-Path $nssmPath -PathType Leaf)) {
    Write-TinySocsLog -Level "WARN" -Message "nssm.exe not found at '$nssmPath'. Skipping agent service installation."
    return
  }

  if (-not $ConfigPath) { $ConfigPath = "C:\ProgramData\TinySocs\Collector\agent\config.yml" }

  $dataRoot    = Join-Path (Get-TinySocsDataRoot) "Collector"
  $agentRoot   = Join-Path $dataRoot "agent"
  $queueDir    = Join-Path $agentRoot "queue"
  $bookmarkDir = Join-Path $agentRoot "bookmarks"
  $logsDir     = Join-Path $dataRoot "logs"

  New-Item -ItemType Directory -Force -Path $agentRoot   | Out-Null
  New-Item -ItemType Directory -Force -Path $queueDir    | Out-Null
  New-Item -ItemType Directory -Force -Path $bookmarkDir | Out-Null
  New-Item -ItemType Directory -Force -Path $logsDir     | Out-Null

  Set-MachineEnv @{ TINYSOCS_AGENT_CONFIG = $ConfigPath }

  $serviceName = "TinySocsAgent"
  $displayName = "TinySocs Collector Agent"
  $description = "TinySocs-native Windows Event Log collector with local queue and OpenSearch output"

  Ensure-TinySocsAgentService -AgentExePath $agentExe `
    -NssmPath $nssmPath `
    -ServiceName $serviceName `
    -DisplayName $displayName `
    -Description $description

  $agentService = Get-Service -Name $serviceName -ErrorAction SilentlyContinue

  if (-not $NoStart) {
    if ($null -ne $agentService) {
      try { Start-Service -Name $serviceName -ErrorAction Stop; Write-TinySocsLog "Agent service '$serviceName' started." }
      catch { Write-TinySocsLog -Level "WARN" -Message "Failed to start agent service '$serviceName': $($_.Exception.Message)" }
    } else {
      Write-TinySocsLog -Level "WARN" -Message "Agent service '$serviceName' is not installed; nothing to start."
    }
  } else {
    Write-TinySocsLog -Level "WARN" -Message "NoStart specified; agent service '$serviceName' configured but not started."
  }

  Write-TinySocsLog "TinySocs Agent configured (config='$ConfigPath')."
}

# -- Service via NSSM ----------------------------------------------------------
function Register-TinySocsNodeService {
  [CmdletBinding()]
  param(
    [string]$ServiceName = 'TinySocsNode',
    [int]$Port = 8081
  )

  Assert-TinySocsAdmin

  # Persist node port to machine env so service restarts keep the same bind
  try {
    Set-MachineEnv @{ PORT = ([string]$Port) }
  } catch {
    Write-TinySocsLog -Level "WARN" -Message "Failed to persist PORT to machine env: $($_.Exception.Message)"
  }

  $installRoot = Get-TinySocsInstallRoot
  $binDir      = Join-Path $installRoot 'bin'
  $nssmExe      = Join-Path $binDir 'nssm.exe'
  $dataRoot     = Get-TinySocsDataRoot
  $workDir      = $dataRoot
  $logsDir      = Join-Path $dataRoot 'logs'

  if (-not (Test-Path $nssmExe -PathType Leaf)) {
    Write-Warning "[TinySocs] nssm.exe missing at '$nssmExe'; skipping node service."
    return
  }

  New-Item -ItemType Directory -Force -Path $logsDir | Out-Null

  $runner = Ensure-TinySocsNodeRunner
  $ps     = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
  $args   = "-NoProfile -ExecutionPolicy Bypass -File `"$runner`""

  $null = sc.exe query $ServiceName 2>$null
  $serviceExists = ($LASTEXITCODE -eq 0)

  $validNssm = $false
  if ($serviceExists) {
    try { $validNssm = Test-NssmManagedService -ServiceName $ServiceName -NssmExe $nssmExe } catch { $validNssm = $false }
  }

  if ($serviceExists -and -not $validNssm) {
    try { Stop-Service $ServiceName -Force -ErrorAction SilentlyContinue } catch { }
    Start-Sleep -Seconds 2
    try { sc.exe stop $ServiceName | Out-Null } catch { }
    Start-Sleep -Seconds 2
    try { sc.exe delete $ServiceName | Out-Null } catch { }

    for ($i=0; $i -lt 20; $i++) {
      $null = sc.exe query $ServiceName 2>$null
      if ($LASTEXITCODE -ne 0) { break }
      Start-Sleep -Seconds 1
    }
  }

  if (-not (Test-NssmManagedService -ServiceName $ServiceName -NssmExe $nssmExe)) {
    & $nssmExe install $ServiceName $ps | Out-Null
  }

  & $nssmExe set $ServiceName Application   $ps      | Out-Null
  & $nssmExe set $ServiceName AppParameters $args    | Out-Null
  & $nssmExe set $ServiceName AppDirectory  $workDir | Out-Null

  & $nssmExe set $ServiceName AppStdout     (Join-Path $logsDir 'TinySocsNode.out.log') | Out-Null
  & $nssmExe set $ServiceName AppStderr     (Join-Path $logsDir 'TinySocsNode.err.log') | Out-Null
  & $nssmExe set $ServiceName AppNoConsole  1 | Out-Null
  & $nssmExe set $ServiceName AppRestartDelay 2000 | Out-Null
  & $nssmExe set $ServiceName AppExit Default Restart | Out-Null

  try { sc.exe config $ServiceName start= delayed-auto | Out-Null } catch { }
  try { sc.exe config $ServiceName obj= LocalSystem | Out-Null } catch { }

  # --- Patch B: dependency ordering (ONLY when TinyBox/OpenSearch is present) ---
  try {
    $null = sc.exe query TinySocsOpenSearch 2>$null
    if ($LASTEXITCODE -eq 0) {
      # Yes, the space after depend= matters.
      sc.exe config $ServiceName depend= TinySocsOpenSearch | Out-Null
    }
  } catch { }

  try { Start-Service $ServiceName -ErrorAction Stop } catch { }

  Write-TinySocsLog ("Node service ensured via NSSM: name={0} runner={1} workdir={2} port={3}" -f $ServiceName, $runner, $workDir, $Port)
}

function Register-TinySocsServices {
  $n = "C:\Program Files\TinySocs\bin\nssm.exe"
  $e = "C:\Program Files\TinySocs\bin\TinySocsNode.exe"
  $w = Join-Path (Get-TinySocsDataRoot) ""

  if (!(Test-Path $n)) {
    Write-Warning "[TinySocs] nssm.exe missing; skipping service."
    return
  }

  # Defaults (but allow Pair-TinySocs / Machine env to override)
  $port = [Environment]::GetEnvironmentVariable("PORT","Machine"); if (-not $port) { $port = "8081" }
  $siem = [Environment]::GetEnvironmentVariable("SIEM_URL","Machine"); if (-not $siem) { $siem = "https://localhost:9201" }
  $ssl  = [Environment]::GetEnvironmentVariable("SIEM_SSL_VERIFY","Machine"); if (-not $ssl) { $ssl = "false" }
  $priv = [Environment]::GetEnvironmentVariable("PRIVACY_MODE","Machine"); if (-not $priv) { $priv = "abstract" }

  & $n install TinySocsNode $e | Out-Null
  & $n set TinySocsNode AppDirectory    $w                             | Out-Null
  & $n set TinySocsNode Start           SERVICE_AUTO_START             | Out-Null
  & $n set TinySocsNode AppStdout       "$w\logs\TinySocsNode.out.log" | Out-Null
  & $n set TinySocsNode AppStderr       "$w\logs\TinySocsNode.err.log" | Out-Null
  & $n set TinySocsNode AppNoConsole    1                              | Out-Null
  & $n set TinySocsNode AppRestartDelay 2000                           | Out-Null

  & $n set TinySocsNode AppEnvironmentExtra ("PORT={0};SIEM_URL={1};SIEM_SSL_VERIFY={2};PRIVACY_MODE={3}" -f $port,$siem,$ssl,$priv) | Out-Null

  sc.exe failure TinySocsNode reset= 60 actions= restart/2000/restart/2000/""/0 | Out-Null

  try { & $n start TinySocsNode | Out-Null } catch { }

  Write-Host "[TinySocs] Service installed/updated and started."
}

# -- Scheduled task helpers (PowerShell ScheduledTasks API) ---------------------
function Ensure-TaskFolder {
  param([string]$FolderPath = "\TinySocs")

  $svc  = New-Object -ComObject "Schedule.Service"
  $svc.Connect()
  $root = $svc.GetFolder("\")

  $folderName = $FolderPath.Trim('\')
  if ([string]::IsNullOrWhiteSpace($folderName)) { throw "Invalid task folder name '$FolderPath'" }

  try { $null = $root.GetFolder("\$folderName"); return } catch { }

  try { $null = $root.CreateFolder($folderName) }
  catch {
    $hr = $_.Exception.HResult
    if ($hr -ne -2147024713) { throw }  # 0x800700B7
  }
}

function New-TinySocsTaskAction {
  param([Parameter(Mandatory)][string]$ScriptPath,[string]$Args = "")
  $ps  = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
  $arg = "-NoProfile -ExecutionPolicy Bypass -File `"$ScriptPath`" $Args".Trim()
  New-ScheduledTaskAction -Execute $ps -Argument $arg
}

function New-TinySocsExeAction {
  param([Parameter(Mandatory)][string]$ExePath,[string]$Args = "")
  New-ScheduledTaskAction -Execute $ExePath -Argument $Args
}

function New-TinySocsRepeatTrigger {
  param([Parameter(Mandatory)][int]$EveryMinutes)
  $start = (Get-Date).AddMinutes(1)
  $dur = New-TimeSpan -Days 3650
  New-ScheduledTaskTrigger -Once -At $start `
    -RepetitionInterval (New-TimeSpan -Minutes $EveryMinutes) `
    -RepetitionDuration $dur
}

function New-TinySocsDailyTrigger {
  param([Parameter(Mandatory)][string]$At)
  $time = [DateTime]::Today.Add([TimeSpan]::Parse($At))
  New-ScheduledTaskTrigger -Daily -At $time
}

function Register-TinySocsTasks {
  $taskPath  = "\TinySocs\"
  $modDir    = "C:\Program Files\TinySocs\modules"
  $binDir    = "C:\Program Files\TinySocs\bin"

  Ensure-TaskFolder -FolderPath $taskPath

  $hb = 15
  if ($env:HEARTBEAT_MINUTES) { [int]::TryParse($env:HEARTBEAT_MINUTES, [ref]$hb) | Out-Null }

  $retention = 45
  if ($env:ANCHORS_RETENTION_DAYS) { [int]::TryParse($env:ANCHORS_RETENTION_DAYS, [ref]$retention) | Out-Null }

  function _RegisterIdempotent {
    param([string]$TaskName,[scriptblock]$ActionFactory,$Trigger)

    try {
      $existing = Get-ScheduledTask -TaskPath $taskPath -TaskName $TaskName -ErrorAction SilentlyContinue
      if ($existing) {
        Unregister-ScheduledTask -TaskName $TaskName -TaskPath $taskPath -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
      }
    } catch { }

    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -RunLevel Highest
    $settings  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 60)

    $action = & $ActionFactory
    $task   = New-ScheduledTask -Action $action -Trigger $Trigger -Principal $principal -Settings $settings
    Register-ScheduledTask -TaskName $TaskName -TaskPath $taskPath -InputObject $task -Force | Out-Null
  }

  $masterRunner = Ensure-TinySocsMasterRunner
  $masterArgs   = ("-window {0}m -deadline 30 -rules 'auth_failed_burst,ps_script_block'" -f $hb)
  $masterTrigger = New-TinySocsRepeatTrigger -EveryMinutes $hb

  _RegisterIdempotent -TaskName "TinySocsHeartbeat" -ActionFactory {
    New-TinySocsTaskAction -ScriptPath $masterRunner -Args ("-Args `"$masterArgs`"")
  } -Trigger $masterTrigger

  $anchorsExe     = Join-Path $binDir "TinySocsAnchors.exe"
  $ensureTrigger  = New-TinySocsDailyTrigger -At "03:10"
  _RegisterIdempotent -TaskName "TinySocsAnchorsEnsure" -ActionFactory {
    New-TinySocsExeAction -ExePath $anchorsExe -Args "--ensure"
  } -Trigger $ensureTrigger

  $pruneTrigger = New-TinySocsDailyTrigger -At "03:15"
  _RegisterIdempotent -TaskName "TinySocsAnchorsPrune" -ActionFactory {
    New-TinySocsExeAction -ExePath $anchorsExe -Args ("--prune --retention-days {0}" -f $retention)
  } -Trigger $pruneTrigger

  $rotateScript  = Join-Path $modDir "TinySocs.RotateQueue.ps1"
  $rotateTrigger = New-TinySocsRepeatTrigger -EveryMinutes 60
  _RegisterIdempotent -TaskName "TinySocsRotateQueue" -ActionFactory {
    New-TinySocsTaskAction -ScriptPath $rotateScript -Args ""
  } -Trigger $rotateTrigger

  Write-Host "[TinySocs] Scheduled tasks registered."
}

function Resolve-TinySocsLocalCaCertPath {
  [CmdletBinding()]
  param(
    [string]$DataRoot = (Get-TinySocsDataRoot)
  )

  # Prefer the canonical TinyBox ProgramData path (per Quickstart.iss [Dirs]/seed).
  $candidates = @(
    (Join-Path $DataRoot 'OpenSearch\certs\root-ca.pem'),
    (Join-Path $DataRoot 'OpenSearch\certs\ca.crt'),
    (Join-Path $DataRoot 'OpenSearch\certs\ca.pem'),
    (Join-Path $DataRoot 'OpenSearch\certs\ca.cer'),

    # Back-compat / older conventions (harmless to probe)
    (Join-Path $DataRoot 'siem\certs\ca.crt'),
    (Join-Path $DataRoot 'siem\certs\root-ca.pem')
  )

  foreach ($p in $candidates) {
    try {
      if ($p -and (Test-Path $p -PathType Leaf)) { return $p }
    } catch { }
  }

  return $null
}

# -- Environment + pairing ------------------------------------------------------
function Set-MachineEnv([hashtable]$Vars){
  foreach($k in $Vars.Keys){
    $v = [string]$Vars[$k]
    [Environment]::SetEnvironmentVariable($k, $v, 'Machine')
    [Environment]::SetEnvironmentVariable($k, $v, 'Process')
  }

  try {
    if (-not ('U.W' -as [type])) {
      $md='[DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h,int m,IntPtr w,string l,int f,int t,out IntPtr r);'
      Add-Type -MemberDefinition $md -Name 'W' -Namespace 'U' -ErrorAction SilentlyContinue | Out-Null
    }
    $z=[intptr]::Zero
    [U.W]::SendMessageTimeout([intptr]0xffff,0x1A,[intptr]0,'Environment',2,5000,[ref]$z) | Out-Null
  } catch { }
}

function Set-ProcessEnv([hashtable]$Vars){
  foreach($k in $Vars.Keys){
    $v = [string]$Vars[$k]
    [Environment]::SetEnvironmentVariable($k, $v, 'Process')
  }
}

function Ensure-TinySocsNodeRunner {
  [CmdletBinding()]
  param(
    [string]$RunnerPath = (Join-Path (Get-TinySocsDataRoot) "run-node.ps1")
  )

  $installRoot = Get-TinySocsInstallRoot
  $modulePath  = Join-Path $installRoot "modules\TinySocs.Installer.psm1"
  $exePath     = Join-Path $installRoot "bin\TinySocsNode.exe"

  $script = @"
`$ErrorActionPreference = 'Stop'

# Fail loudly if the module isn't present/importable (otherwise services "die silently").
Import-Module '$modulePath' -Force -ErrorAction Stop

`$port = [Environment]::GetEnvironmentVariable('PORT','Machine')
if ([string]::IsNullOrWhiteSpace(`$port)) { `$port = '8081' }

# --- SIEM settings: Machine env preferred; CredMan fallback; backfill Machine env ---
`$siemUrl = [Environment]::GetEnvironmentVariable('SIEM_URL','Machine')
if (-not [string]::IsNullOrWhiteSpace(`$siemUrl)) { `$siemUrl = `$siemUrl.TrimEnd('/') } else { `$siemUrl = '' }

`$sslVerify = [Environment]::GetEnvironmentVariable('SIEM_SSL_VERIFY','Machine')
if ([string]::IsNullOrWhiteSpace(`$sslVerify)) { `$sslVerify = '' }  # defer default until after CredMan fallback

`$caCert = [Environment]::GetEnvironmentVariable('SIEM_CA_CERT','Machine')
if ([string]::IsNullOrWhiteSpace(`$caCert)) { `$caCert = '' }

if ([string]::IsNullOrWhiteSpace(`$siemUrl) -or [string]::IsNullOrWhiteSpace(`$sslVerify) -or [string]::IsNullOrWhiteSpace(`$caCert)) {
  try {
    `$raw = Get-TSCredential -Name 'TinySocs/SIEM/Creds'
    if (-not [string]::IsNullOrWhiteSpace(`$raw)) {
      `$j = `$raw | ConvertFrom-Json

      if ([string]::IsNullOrWhiteSpace(`$siemUrl)) {
        if (`$j.url) { `$siemUrl = [string]`$j.url } elseif (`$j.siemUrl) { `$siemUrl = [string]`$j.siemUrl }
        if (-not [string]::IsNullOrWhiteSpace(`$siemUrl)) { `$siemUrl = `$siemUrl.TrimEnd('/') }
      }

      if ([string]::IsNullOrWhiteSpace(`$sslVerify)) {
        if (`$null -ne `$j.sslVerify) { `$sslVerify = (if ([bool]`$j.sslVerify) { 'true' } else { 'false' }) }
        elseif (`$null -ne `$j.siemSslVerify) { `$sslVerify = (if ([bool]`$j.siemSslVerify) { 'true' } else { 'false' }) }
      }

      if ([string]::IsNullOrWhiteSpace(`$caCert)) {
        if (`$j.caCert) { `$caCert = [string]`$j.caCert }
        elseif (`$j.ca_cert) { `$caCert = [string]`$j.ca_cert }
      }

      # Backfill Machine env so subsequent starts don't require CredMan fallback.
      `$bf = @{}
      if (-not [string]::IsNullOrWhiteSpace(`$siemUrl))   { `$bf.SIEM_URL = `$siemUrl }
      if (-not [string]::IsNullOrWhiteSpace(`$sslVerify)) { `$bf.SIEM_SSL_VERIFY = `$sslVerify }
      if (-not [string]::IsNullOrWhiteSpace(`$caCert))    { `$bf.SIEM_CA_CERT = `$caCert }
      if (`$bf.Count -gt 0) { try { Set-MachineEnv `$bf } catch { } }
    }
  } catch { }
}

# --- Patch A: deterministic CA derivation if still missing (TinyBox upgrades/repairs) ---
if ([string]::IsNullOrWhiteSpace(`$caCert)) {
  try {
    `$p = Resolve-TinySocsLocalCaCertPath
    if (-not [string]::IsNullOrWhiteSpace(`$p)) {
      `$caCert = `$p
      try { Set-MachineEnv @{ SIEM_CA_CERT = `$caCert } } catch { }
    }
  } catch { }
}

# Apply defaults after fallback attempt
if ([string]::IsNullOrWhiteSpace(`$sslVerify)) { `$sslVerify = 'true' }

`$privacy = [Environment]::GetEnvironmentVariable('PRIVACY_MODE','Machine')
if ([string]::IsNullOrWhiteSpace(`$privacy)) { `$privacy = 'abstract' }

# --- Shared secret (CredMan preferred, DPAPI fallback, backfill both ways) ---
`$secret = `$null
try { `$secret = Get-TSCredential -Name 'TinySocs/Node/Secret' } catch { }

if ([string]::IsNullOrWhiteSpace(`$secret)) {
  try {
    `$secret = Read-TinySocsNodeSecretFromDpapiFile
    if (-not [string]::IsNullOrWhiteSpace(`$secret)) {
      try { Set-TSCredential -Name 'TinySocs/Node/Secret' -Secret `$secret } catch { }
    }
  } catch { }
}

if (-not [string]::IsNullOrWhiteSpace(`$secret)) {
  try {
    `$dp = Get-TinySocsNodeSecretDpapiFilePath
    if (-not (Test-Path `$dp -PathType Leaf)) {
      Write-TinySocsNodeSecretToDpapiFile -Secret `$secret | Out-Null
    }
  } catch { }
}

if ([string]::IsNullOrWhiteSpace(`$secret)) { throw "TinySocs/Node/Secret missing in CredMan and no DPAPI fallback present." }

Set-ProcessEnv @{
  MASTER_SHARED_SECRET = `$secret
  PORT                 = `$port
  SIEM_URL             = `$siemUrl
  SIEM_SSL_VERIFY      = `$sslVerify
  SIEM_CA_CERT         = `$caCert
  PRIVACY_MODE         = `$privacy
}

& '$exePath'
"@

  $dir = Split-Path -Parent $RunnerPath
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }

  Ensure-TinySocsWritableFile -Path $RunnerPath
  Set-Content -Path $RunnerPath -Value $script -Encoding UTF8 -Force
  Write-TinySocsLog "Node runner ensured at $RunnerPath (CredMan preferred; DPAPI fallback; auto-backfill)."
  return $RunnerPath
}

function Ensure-TinySocsMasterRunner {
  [CmdletBinding()]
  param(
    [string]$RunnerPath = (Join-Path (Get-TinySocsDataRoot) "run-master.ps1"),
    [string]$LaunchScriptPath = "C:\Program Files\TinySocs\modules\Launch-Master.ps1"
  )

  $installRoot = Get-TinySocsInstallRoot
  $modulePath  = Join-Path $installRoot "modules\TinySocs.Installer.psm1"

  $script = @"
param([string]`$Args = "")
`$ErrorActionPreference = 'Stop'

# Fail loudly if the module isn't present/importable.
Import-Module '$modulePath' -Force -ErrorAction Stop

# --- Nodes list (Machine env preferred; file fallback; backfill machine env) ---
`$nodes = [Environment]::GetEnvironmentVariable('TINYSOCS_NODES','Machine')
if ([string]::IsNullOrWhiteSpace(`$nodes)) {
  try { `$nodes = Read-TinySocsNodesFromFile } catch { }
  if (-not [string]::IsNullOrWhiteSpace(`$nodes)) {
    try { Set-MachineEnv @{ TINYSOCS_NODES = `$nodes } } catch { }
  }
} else {
  try { Write-TinySocsNodesToFile -Nodes `$nodes | Out-Null } catch { }
}

# --- SIEM settings: Machine env preferred; CredMan fallback; backfill Machine env ---
`$siemUrl = [Environment]::GetEnvironmentVariable('SIEM_URL','Machine')
if (-not [string]::IsNullOrWhiteSpace(`$siemUrl)) { `$siemUrl = `$siemUrl.TrimEnd('/') } else { `$siemUrl = '' }

`$sslVerify = [Environment]::GetEnvironmentVariable('SIEM_SSL_VERIFY','Machine')
if ([string]::IsNullOrWhiteSpace(`$sslVerify)) { `$sslVerify = '' }  # defer default until after CredMan fallback

`$caCert = [Environment]::GetEnvironmentVariable('SIEM_CA_CERT','Machine')
if ([string]::IsNullOrWhiteSpace(`$caCert)) { `$caCert = '' }

if ([string]::IsNullOrWhiteSpace(`$siemUrl) -or [string]::IsNullOrWhiteSpace(`$sslVerify) -or [string]::IsNullOrWhiteSpace(`$caCert)) {
  try {
    `$raw = Get-TSCredential -Name 'TinySocs/SIEM/Creds'
    if (-not [string]::IsNullOrWhiteSpace(`$raw)) {
      `$j = `$raw | ConvertFrom-Json

      if ([string]::IsNullOrWhiteSpace(`$siemUrl)) {
        if (`$j.url) { `$siemUrl = [string]`$j.url } elseif (`$j.siemUrl) { `$siemUrl = [string]`$j.siemUrl }
        if (-not [string]::IsNullOrWhiteSpace(`$siemUrl)) { `$siemUrl = `$siemUrl.TrimEnd('/') }
      }

      if ([string]::IsNullOrWhiteSpace(`$sslVerify)) {
        if (`$null -ne `$j.sslVerify) { `$sslVerify = (if ([bool]`$j.sslVerify) { 'true' } else { 'false' }) }
        elseif (`$null -ne `$j.siemSslVerify) { `$sslVerify = (if ([bool]`$j.siemSslVerify) { 'true' } else { 'false' }) }
      }

      if ([string]::IsNullOrWhiteSpace(`$caCert)) {
        if (`$j.caCert) { `$caCert = [string]`$j.caCert }
        elseif (`$j.ca_cert) { `$caCert = [string]`$j.ca_cert }
      }

      # Backfill Machine env so subsequent starts don't require CredMan fallback.
      `$bf = @{}
      if (-not [string]::IsNullOrWhiteSpace(`$siemUrl))   { `$bf.SIEM_URL = `$siemUrl }
      if (-not [string]::IsNullOrWhiteSpace(`$sslVerify)) { `$bf.SIEM_SSL_VERIFY = `$sslVerify }
      if (-not [string]::IsNullOrWhiteSpace(`$caCert))    { `$bf.SIEM_CA_CERT = `$caCert }
      if (`$bf.Count -gt 0) { try { Set-MachineEnv `$bf } catch { } }
    }
  } catch { }
}

# --- Patch A: deterministic CA derivation if still missing (TinyBox upgrades/repairs) ---
if ([string]::IsNullOrWhiteSpace(`$caCert)) {
  try {
    `$p = Resolve-TinySocsLocalCaCertPath
    if (-not [string]::IsNullOrWhiteSpace(`$p)) {
      `$caCert = `$p
      try { Set-MachineEnv @{ SIEM_CA_CERT = `$caCert } } catch { }
    }
  } catch { }
}

# Apply defaults after fallback attempt
if ([string]::IsNullOrWhiteSpace(`$sslVerify)) { `$sslVerify = 'true' }

# --- Shared secret (CredMan preferred, DPAPI fallback, backfill both ways) ---
`$secret = `$null
try { `$secret = Get-TSCredential -Name 'TinySocs/Master/SharedSecret' } catch { }

if ([string]::IsNullOrWhiteSpace(`$secret)) {
  try {
    `$secret = Read-TinySocsMasterSharedSecretFromDpapiFile
    if (-not [string]::IsNullOrWhiteSpace(`$secret)) {
      try { Set-TSCredential -Name 'TinySocs/Master/SharedSecret' -Secret `$secret } catch { }
    }
  } catch { }
}

if (-not [string]::IsNullOrWhiteSpace(`$secret)) {
  try {
    `$dp = Get-TinySocsMasterSharedSecretDpapiFilePath
    if (-not (Test-Path `$dp -PathType Leaf)) {
      Write-TinySocsMasterSharedSecretToDpapiFile -Secret `$secret | Out-Null
    }
  } catch { }
}

if ([string]::IsNullOrWhiteSpace(`$secret)) { throw "TinySocs/Master/SharedSecret missing in CredMan and no DPAPI fallback present." }

Set-ProcessEnv @{
  MASTER_SHARED_SECRET = `$secret
  TINYSOCS_NODES       = `$nodes
  SIEM_URL             = `$siemUrl
  SIEM_SSL_VERIFY      = `$sslVerify
  SIEM_CA_CERT         = `$caCert
}

if ([string]::IsNullOrWhiteSpace(`$Args)) {
  & '$LaunchScriptPath'
} else {
  Invoke-Expression ("& `"$LaunchScriptPath`" {0}" -f `$Args)
}
"@

  $dir = Split-Path -Parent $RunnerPath
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }

  Ensure-TinySocsWritableFile -Path $RunnerPath
  Set-Content -Path $RunnerPath -Value $script -Encoding UTF8 -Force
  Write-TinySocsLog "Master runner ensured at $RunnerPath (CredMan preferred; DPAPI fallback; nodes env<->file backfill)."
  return $RunnerPath
}

function Pair-TinySocs{
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][ValidateSet('Node','Master')]$Role,
    [Parameter(Mandatory)][string]$SharedSecret,

    [string]$NodePort='8081',

    # PATCH: canonical TinyBox default is 9201 (not 9200)
    [string]$SiemUrl='https://127.0.0.1:9201',
    [string]$SiemUser,
    [string]$SiemPass,
    [bool]  $SiemSslVerify = $true,

    [string]$Nodes,
    [int]$AnchorsRetentionDays=45,
    [int]$HeartbeatMinutes=15
  )
  Install-TinySocs

  $normSiemUrl = ''
  try {
    if (-not [string]::IsNullOrWhiteSpace($SiemUrl)) { $normSiemUrl = $SiemUrl.TrimEnd('/') }
  } catch { $normSiemUrl = $SiemUrl }

  # PATCH: if TinyBox appears installed and URL still points at :9200, rewrite to :9201
  # (opt-out via TINYSOCS_ALLOW_9200=true)
  try {
    $allow9200 = ($env:TINYSOCS_ALLOW_9200 -eq 'true')
    $tinyBoxYml = "C:\ProgramData\TinySocs\OpenSearch\config\opensearch.yml"
    $hasTinyBox = (Test-Path -LiteralPath $tinyBoxYml -PathType Leaf)

    if (-not $allow9200 -and $hasTinyBox -and -not [string]::IsNullOrWhiteSpace($normSiemUrl)) {
      $u = $normSiemUrl
      if ($u -match ':(9200)(/|$)') {
        $normSiemUrl = ($u -replace ':(9200)(/|$)', ':9201$2')
        Write-TinySocsLog -Level "WARN" -Message "Pair-TinySocs: SiemUrl was $u; TinyBox canonical port is 9201. Rewriting to $normSiemUrl."
      }
    }
  } catch { }

  $verifyString = if ([bool]$SiemSslVerify) { 'true' } else { 'false' }

  # If SIEM creds are provided, store them canonically (CredMan + safe env vars).
  # If omitted, DO NOT wipe existing SIEM creds.
  $providedSiemCreds = (-not [string]::IsNullOrWhiteSpace($SiemUser) -and -not [string]::IsNullOrWhiteSpace($SiemPass))
  if ($providedSiemCreds) {
    try {
      Set-TinySocsSiemCredential -SiemUrl $normSiemUrl -SiemUser $SiemUser -SiemPass $SiemPass -SiemSslVerify:$SiemSslVerify
      Write-TinySocsLog "Pair-TinySocs: SIEM credentials were provided and stored (TinySocs/SIEM/Creds)."
    } catch {
      Write-TinySocsLog -Level "WARN" -Message "Pair-TinySocs: Failed to store SIEM creds: $($_.Exception.Message)"
    }
  }

  if($Role -eq 'Node'){
    Set-TSCredential -Name 'TinySocs/Node/Secret' -Secret $SharedSecret

    # Machine env needed for runner/service
    Set-MachineEnv @{
      PORT            = $NodePort
      SIEM_URL        = $normSiemUrl
      SIEM_SSL_VERIFY = $verifyString
      PRIVACY_MODE    = 'abstract'
    }

    # If we already have a CA path stored (from local SIEM install), keep it in env for the node.
    try {
      $raw = Get-TSCredential -Name 'TinySocs/SIEM/Creds'
      if ($raw) {
        $j = $raw | ConvertFrom-Json
        if ($j.caCert -and -not [string]::IsNullOrWhiteSpace([string]$j.caCert)) {
          Set-MachineEnv @{ SIEM_CA_CERT = [string]$j.caCert }
        } elseif ($j.ca_cert -and -not [string]::IsNullOrWhiteSpace([string]$j.ca_cert)) {
          Set-MachineEnv @{ SIEM_CA_CERT = [string]$j.ca_cert }
        }
      }
    } catch { }

    # --- Patch A: if still missing, derive CA deterministically from ProgramData ---
    try {
      $existing = [Environment]::GetEnvironmentVariable('SIEM_CA_CERT','Machine')
      if ([string]::IsNullOrWhiteSpace($existing)) {
        $p = Resolve-TinySocsLocalCaCertPath
        if ($p) { Set-MachineEnv @{ SIEM_CA_CERT = [string]$p } }
      }
    } catch { }

    # Ensure runner + service (idempotent)
    try { $null = Ensure-TinySocsNodeRunner } catch { }
    try { Register-TinySocsNodeService -Port ([int]$NodePort) } catch { }

    Write-TinySocsLog "Paired as Node. CredMan: TinySocs/Node/Secret set. Env: PORT, SIEM_URL, SIEM_SSL_VERIFY, (optional SIEM_CA_CERT)."
    return @{
      Role          = "Node"
      Port          = $NodePort
      SiemUrl       = $normSiemUrl
      SiemSslVerify = [bool]$SiemSslVerify
    }
  }

  if($Role -eq 'Master'){
    Set-TSCredential -Name 'TinySocs/Master/SharedSecret' -Secret $SharedSecret

    # Preserve existing nodes if caller didn't supply new ones
    $finalNodes = $Nodes
    if ([string]::IsNullOrWhiteSpace($finalNodes)) {
      try { $finalNodes = [Environment]::GetEnvironmentVariable('TINYSOCS_NODES','Machine') } catch { }
    }

    Set-MachineEnv @{
      TINYSOCS_NODES          = $finalNodes
      SIEM_URL                = $normSiemUrl
      SIEM_SSL_VERIFY         = $verifyString
      HEARTBEAT_MINUTES       = ([string]$HeartbeatMinutes)
      ANCHORS_RETENTION_DAYS  = ([string]$AnchorsRetentionDays)
    }

    # Carry SIEM_CA_CERT forward if present in CredMan payload
    try {
      $raw = Get-TSCredential -Name 'TinySocs/SIEM/Creds'
      if ($raw) {
        $j = $raw | ConvertFrom-Json
        if ($j.caCert -and -not [string]::IsNullOrWhiteSpace([string]$j.caCert)) {
          Set-MachineEnv @{ SIEM_CA_CERT = [string]$j.caCert }
        } elseif ($j.ca_cert -and -not [string]::IsNullOrWhiteSpace([string]$j.ca_cert)) {
          Set-MachineEnv @{ SIEM_CA_CERT = [string]$j.ca_cert }
        }
      }
    } catch { }

    # --- Patch A: if still missing, derive CA deterministically from ProgramData ---
    try {
      $existing = [Environment]::GetEnvironmentVariable('SIEM_CA_CERT','Machine')
      if ([string]::IsNullOrWhiteSpace($existing)) {
        $p = Resolve-TinySocsLocalCaCertPath
        if ($p) { Set-MachineEnv @{ SIEM_CA_CERT = [string]$p } }
      }
    } catch { }

    # Ensure runner + scheduled tasks (idempotent)
    try { $null = Ensure-TinySocsMasterRunner } catch { }
    try { Register-TinySocsTasks } catch {
      Write-TinySocsLog -Level "WARN" -Message "Pair-TinySocs: Failed to register scheduled tasks: $($_.Exception.Message)"
    }

    Write-TinySocsLog "Paired as Master. CredMan: TinySocs/Master/SharedSecret set. Env: TINYSOCS_NODES, SIEM_*, HEARTBEAT_MINUTES, ANCHORS_RETENTION_DAYS."
    return @{
      Role                 = "Master"
      Nodes                = $finalNodes
      SiemUrl              = $normSiemUrl
      SiemSslVerify         = [bool]$SiemSslVerify
      HeartbeatMinutes     = $HeartbeatMinutes
      AnchorsRetentionDays = $AnchorsRetentionDays
    }
  }
}

function Rotate-TinySocsSecrets([Parameter(Mandatory)][string]$SharedSecret){
  Set-TSCredential -Name 'TinySocs/Node/Secret'         -Secret $SharedSecret
  Set-TSCredential -Name 'TinySocs/Master/SharedSecret' -Secret $SharedSecret

  $n = "C:\Program Files\TinySocs\bin\nssm.exe"
  if (Test-Path $n) { try { & $n restart TinySocsNode 2>$null | Out-Null } catch { } }

  Write-Host "[TinySocs] Secrets rotated (CredMan)."
}

# -- Uninstall -----------------------------------------------------------------
function Uninstall-TinySocs {
  [CmdletBinding()]
  param([switch]$KeepData)

  Assert-TinySocsAdmin
  $svcNames = @("TinySocsNode","TinySocsOpenSearch","TinySocsAgent")
  $taskPath = "\TinySocs\"
  $binDir  = "C:\Program Files\TinySocs\bin"
  $appData = "$env:ProgramData\TinySocs"

  Write-Host "[TinySocs] Uninstall starting (KeepData=$KeepData)..."

  if (-not $KeepData) {
    try {
      Remove-TSCredential -Name 'TinySocs/Node/Secret'
      Remove-TSCredential -Name 'TinySocs/Master/SharedSecret'
      Remove-TSCredential -Name 'TinySocs/SIEM/Creds'
    } catch { }
  }

  try {
    Get-ScheduledTask -TaskPath $taskPath -ErrorAction SilentlyContinue |
      Unregister-ScheduledTask -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
  } catch { }

  $n = Join-Path $binDir "nssm.exe"
  foreach ($svcName in $svcNames) {
    try { Stop-Service $svcName -ErrorAction SilentlyContinue } catch { }

    if (Test-Path $n) {
      try { & $n remove $svcName confirm | Out-Null } catch { }
    } else {
      try { sc.exe delete $svcName | Out-Null } catch { }
    }
  }

  $procNames = @("TinySocsNode","TinySocsMaster","TinySocsAnchors","TinySocs.Agent","opensearch-service-x64","opensearch-service-mgr")
  foreach ($p in $procNames) {
    try { Get-Process $p -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue } catch { }
  }

  # --- Patch C: preserve Machine env on KeepData (upgrade/repair path) ---
  if (-not $KeepData) {
    $vars = @(
      "PORT","NODE_PORT","SIEM_URL","SIEM_SSL_VERIFY",
      "SIEM_USER","SIEM_PASS",
      "PRIVACY_MODE","NODE_SECRET","MASTER_SHARED_SECRET",
      "TINYSOCS_NODES","HEARTBEAT_MINUTES","ANCHORS_RETENTION_DAYS",
      "ALWAYS_ANCHOR","MASTER_DEADLINE_SEC",
      "TINYSOCS_AGENT_CONFIG","TINYSOCS_INSECURE_LOCAL_SIEM",
      "SIEM_CA_CERT"
    )
    foreach ($v in $vars) { [Environment]::SetEnvironmentVariable($v, $null, 'Machine') }
  }

  if (-not $KeepData) {
    try { Remove-Item -Recurse -Force $appData -ErrorAction SilentlyContinue } catch { }
  }

  try {
    $installRoot = Get-TinySocsInstallRoot
    if ($installRoot -and (Test-Path $installRoot -PathType Container)) {
      Write-TinySocsLog "Removing TinySocs install root at $installRoot"
      Remove-Item -Recurse -Force $installRoot -ErrorAction SilentlyContinue
    }
  } catch {
    Write-TinySocsLog -Level "WARN" -Message ("Failed to remove TinySocs install root: {0}" -f $_.Exception.Message)
  }

  Write-Host "[TinySocs] Uninstall complete."
}

Export-ModuleMember -Function * -Alias *